package ni.dmp.service_client;

public class Constants {

	enum sequenceCodeEnum {
		InitialValue(0),
		validateNIAudienceFile(1),
		loadNIAudienceFile(2),
		syncAdobeUUIDwithSocialId(3),
		exportAdobeUUIDtoGCS(4),
		createInboundAudienceFile(5),
		uploadInboundFileToS3(6),
		Exit(7);

	    private int numVal;

	    sequenceCodeEnum(int numVal) {
	        this.numVal = numVal;
	    }

	    public int getNumVal() {
	        return numVal;
	    }
				
	}
}
