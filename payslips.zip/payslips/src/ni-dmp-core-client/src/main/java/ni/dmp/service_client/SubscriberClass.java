package ni.dmp.service_client;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ni.dmp.service_client.Constants;
import com.google.cloud.datastore.Datastore;
import com.google.cloud.datastore.DatastoreOptions;
import com.google.cloud.datastore.Entity;
import com.google.cloud.datastore.Key;
import com.google.cloud.datastore.Query;
import com.google.cloud.datastore.QueryResults;
import com.google.cloud.datastore.StructuredQuery.PropertyFilter;
import com.google.cloud.pubsub.v1.stub.GrpcSubscriberStub;
import com.google.cloud.pubsub.v1.stub.SubscriberStub;
import com.google.cloud.pubsub.v1.stub.SubscriberStubSettings;

//import com.google.gson.JsonSyntaxException;
import com.google.pubsub.v1.AcknowledgeRequest;
import com.google.pubsub.v1.ProjectSubscriptionName;
import com.google.pubsub.v1.PubsubMessage;
import com.google.pubsub.v1.PullRequest;
import com.google.pubsub.v1.PullResponse;
import com.google.pubsub.v1.ReceivedMessage;

import java.net.URL;
import java.time.Instant;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;

public class SubscriberClass {
	private static final String PROJECT_ID = System.getenv("projectname");
	private static final String SUBSCRIPTIONID = System.getenv("subscriptionname");
	private static final Logger LOGGER = LoggerFactory.getLogger(SubscriberClass.class);
	public static void main(String[] args) {
		try{
			SubscriberClass subscriberClassObject = new SubscriberClass();
			//call processMessage function after every 10 seconds delay
			System.out.println("Before WHile loop");
			while(true)
			{
				subscriberClassObject.processMessage();
				Thread.sleep(10000);
			}
		}catch (Exception exp) {
			System.out.println("SubscriberClass.main: {}"+exp);
	    	LOGGER.error("SubscriberClass.main: {}",exp);
	    }
	}

	/**
	 * Check for message in pub/sub topic, If it finds any message call processNIAudienceFile function
	 * @throws Exception
	 */
	public void processMessage() throws Exception
	{
		System.out.println("Inside Process Message function");
		LOGGER.info("Inside Process Message function");
		//Variable that defines how many message to pull at once
		int numOfMessages = 1;
		//Build an SubscriberStubSettings object that would help in pulling the message
		SubscriberStubSettings subscriberStubSettings =SubscriberStubSettings.newBuilder().build();
		//Create a SubscriberStub which would send the pull request
		System.out.println("subscriberStubSettings:"+subscriberStubSettings);
		try (SubscriberStub subscriber = GrpcSubscriberStub.create(subscriberStubSettings))
		{
			//Fetch pub/sub subscription name from project
			System.out.println("Inside try block SUbscriber:"+subscriber);
			String subscriptionName = ProjectSubscriptionName.format(PROJECT_ID, SUBSCRIPTIONID);
			//Build a pull request
			System.out.println("subscriptionName:"+subscriptionName);
			PullRequest pullRequest =PullRequest.newBuilder()
					              	.setMaxMessages(numOfMessages)
					              	.setReturnImmediately(true)
					              	.setSubscription(subscriptionName)
					              	.build();
			// Send Synchronous Pull request and get the pull response
			System.out.println("pullRequest:"+pullRequest);
			PullResponse pullResponse = subscriber.pullCallable().call(pullRequest);
			//Get message count in pull response
			System.out.println("pullResponse:"+pullResponse);
			int getReceivedMessagesCount = pullResponse.getReceivedMessagesCount();
			LOGGER.info("pull response data: {} ", getReceivedMessagesCount);
			System.out.println("getReceivedMessagesCount:"+getReceivedMessagesCount);
			//Condition will be true if any message retrieved from subscription
			if(getReceivedMessagesCount!=0)
			{
				processNIAudienceFile(pullResponse);
			}
		}catch(Exception exp){
			LOGGER.error("Error from processMessage function: {}",exp);
		}
	}
					
	/**
	 * Process message retrieved from pub/sub subscription - extract file path and start time stamp
	 * Get sequence code from cloud datastore, based on the retrieved sequence code call the appropriate Rest API
	 * @param pullResponse - parameter containing response from pub/sub subscription
	 * @throws Exception
	 */
	public static void processNIAudienceFile(PullResponse pullResponse) throws Exception
	{
		//Variable that will contain the file path retrieved from Pub/sub message
		String filePath = "";
		//Variable that will contain the start time stamp retrieved from Pub/sub message
		long startTimeStamp=0;
		System.out.println("processNIAudienceFile called");
		//Variable that will contain the sequence code value. Initialized to 0 (coming from enum)
		int sequenceCode = Constants.sequenceCodeEnum.InitialValue.getNumVal();
		//Variable that will contain the Cluster IP service IP address
		String host = System.getenv("NI_DMP_CORE_SVC_SERVICE_HOST");
		//Variable that will contain the Cluster IP service port
		String port = System.getenv("NI_DMP_CORE_SVC_SERVICE_PORT");
		System.out.println("Host: "+host+" port: "+port);
		//pull out message list from pull response (list will contain 1 message)
		List<ReceivedMessage> msgList =  pullResponse.getReceivedMessagesList();
		System.out.println("msgList:"+msgList.size());
		//Iterate over list containing messages (1 iteration will happen)
		for(ReceivedMessage msg : msgList)
		{
			//Get the actual message from pub/sub
		    PubsubMessage message = msg.getMessage();
		    System.out.println("message"+message.toString());
		    //Get the message data in JSON format
		    JSONObject messageData=new JSONObject(message.getData().toStringUtf8());
		    System.out.println("messageData"+messageData.toString());
		    //retrieve value of json key - filepath and put it in filePath variable
		    filePath = messageData.getString("filepath");
		    //retrieve value of json key - starttimestamp and put it in startTimeStamp variable
		    startTimeStamp = messageData.getLong("starttimestamp");
		    System.out.println("filepath:"+filePath);
		    System.out.println("startTimeStamp:"+startTimeStamp);
		    LOGGER.info("FROM JSON OBJECT: file path: {} ", filePath);
		    LOGGER.info("FROM JSON OBJECT: start time stamp: {} ",startTimeStamp);
		}
		//Iterate till value of sequence code retrieved from data store is 7 (enum exit value)
		while(sequenceCode!=Constants.sequenceCodeEnum.Exit.getNumVal())
		{
			LOGGER.info("Sequence code value at start of this iteration: {}",sequenceCode);
			System.out.println("sequenceCode:"+sequenceCode);
			//Variable to create basic URL for Rest API
			String url="http://"+host+":"+port+"/core/v1/file/";
			//get Sequence Code from cloud datastore entity for particular start time stamp
			sequenceCode = getSequenceCode(startTimeStamp);
			System.out.println("getSequenceCode sequenceCode:"+sequenceCode);
			//get sequenceCodeEnum integer value based on sequence code from getSequenceCodeEnum function
			Constants.sequenceCodeEnum sequenceCodeEnum = getSequenceCodeEnum(sequenceCode);
			System.out.println("sequenceCodeEnum:"+sequenceCodeEnum);
			LOGGER.info("Sequence code value from datastore: {}",sequenceCode);
			//Based on the sequence code value call appropriate case (containing enum values) 
			switch(sequenceCodeEnum)
			{
				case validateNIAudienceFile:
					//Form url to call validate Rest API
					url=url+"validate";
					LOGGER.info("URL: {}",url);
					System.out.println("URL: "+url);
					//Call callRestAPI function giving URL, file path and start time stamp
					callRestAPI(url,filePath,startTimeStamp);
				break;
				case loadNIAudienceFile :
					//Form url to call load social id Rest API
					url=url+"load_social_id";
					LOGGER.info("URL: {}",url);
					System.out.println("URL: "+url);
					//Call callRestAPI function giving URL, file path and start time stamp
					callRestAPI(url,filePath,startTimeStamp);
				break;
				case syncAdobeUUIDwithSocialId :
					//Form url to call adobe uuid Rest API
					url=url+"adobeuuid";
					LOGGER.info("URL: {}",url);
					System.out.println("URL: "+url);
					//Call callRestAPI function giving URL, file path and start time stamp
					callRestAPI(url,filePath,startTimeStamp);
				break;
				case exportAdobeUUIDtoGCS :
					//Form url to call upload outbound gcs Rest API
					url=url+"upload_outbound_gcs";
					LOGGER.info("URL: {}",url);
					System.out.println("URL: "+url);
					//Call callRestAPI function giving URL, file path and start time stamp
					callRestAPI(url,filePath,startTimeStamp);
				break;
				case createInboundAudienceFile :
					//Form url to call intermediate gcs Rest API
					url=url+"intermediate_gcs";
					LOGGER.info("URL: {}",url);
					System.out.println("URL: "+url);
					//Call callRestAPI function giving URL, file path and start time stamp
					callRestAPI(url,filePath,startTimeStamp);
				break;
				case uploadInboundFileToS3 :
					//Form url to call upload S3 Rest API
					url=url+"upload_S3";
					LOGGER.info("URL: {}",url);
					System.out.println("URL: "+url);
					//Call callRestAPI function giving URL, file path and start time stamp
					callRestAPI(url,filePath,startTimeStamp);
				break;
				case Exit :
					System.out.println("Exit case");
					//acknowledge the message
					acknowledgeSubscribedMessage(pullResponse);
					//call setEndTimeStamp function to set end time stamp in cloud datastore entity
					setEndTimeStamp(startTimeStamp);
				break;
				default : 
					System.out.println(" value of sequence code does not match");
					LOGGER.info("value of sequence code does not match");
			}	
		}
	}
	
	/**
	 * Retrieve value of sequence code from Cloud datastore
	 * @param StartTimeStamp - Based on this variable
	 * @return
	 */
	public static int getSequenceCode(long startTimeStamp)
	{
		System.out.println("getSequenceCode");
		//Variable that will contain sequence code value
		int sequenceCode=0;
		//Create Datastore instance, to access datastore java API
		Datastore datastore = DatastoreOptions.getDefaultInstance().getService();
		//Build the Query - get entity in kind 'Task' where StartTimeStamp column matches startTimeStamp variable value 
		Query<Entity> query = Query.newEntityQueryBuilder()
		        .setKind("Task")                                     
		        .setFilter(PropertyFilter.eq("StartTimeStamp",startTimeStamp))                      
		        .build();
		//run the query and fetch query results
		QueryResults<Entity> result= datastore.run(query);
		//Check whether result contains any entity
		if(result.hasNext())
		{
			System.out.println("getSequenceCode inside IF");
			//Retrieve entity key (auto generated by datastore)
			Key entityKey = result.next().getKey();
			//Retrieve entity from key
			Entity retrieved = datastore.get(entityKey);
			//Retrieve sequence code from entity
			sequenceCode = (int)retrieved.getLong("SequenceCode");
			LOGGER.info("Sequence Code from datastore: {}",sequenceCode);
			System.out.println("getSequenceCode sequenceCode:"+sequenceCode);
		}
	  return sequenceCode; 
	}
	
	/**
	 * Return integer values from enum
	 * @param SequenceCode - Based on this sequence code value
	 * @return
	 */
	public static Constants.sequenceCodeEnum getSequenceCodeEnum(int SequenceCode)
	{
		switch(SequenceCode)
		{
		case 1 :
			return Constants.sequenceCodeEnum.validateNIAudienceFile;
		case 2 :
			return Constants.sequenceCodeEnum.loadNIAudienceFile;
		case 3 :
			return Constants.sequenceCodeEnum.syncAdobeUUIDwithSocialId;
		case 4 :
			return Constants.sequenceCodeEnum.exportAdobeUUIDtoGCS;	
		case 5 :
			return Constants.sequenceCodeEnum.createInboundAudienceFile;
		case 6 :
			return Constants.sequenceCodeEnum.uploadInboundFileToS3;
		case 7 :
			return Constants.sequenceCodeEnum.Exit;
		default : 
			return Constants.sequenceCodeEnum.InitialValue;
		}
	}

	/**
	 * Set end time stamp in cloud datastore
	 * @param StartTimeStamp - Based on this parameter
	 */
	public static void setEndTimeStamp(long StartTimeStamp)
	{
		System.out.println("setEndTimeStamp");
		//Create Datastore instance, to acess datastore java API
		Datastore datastore = DatastoreOptions.getDefaultInstance().getService(); //Create Datastore object
		//Build the Query - get entity in kind 'Task' where StartTimeStamp column matches startTimeStamp variable value
		Query<Entity> query = Query.newEntityQueryBuilder()
		        .setKind("Task")                              
		        .setFilter(PropertyFilter.eq("StartTimeStamp",StartTimeStamp))                    
		        .build();
		//run the query and fetch query results
		System.out.println("before fetch");
		QueryResults<Entity> result= datastore.run(query);
		//Check whether result contains any entity
		if(result.hasNext())
	    {
			System.out.println("inside setEndTimeStamp IF");
			//Retrieve entity key (auto generated by datastore)
		    Key entityKey= result.next().getKey();
		    //get current instance epoch time stamp
		    long endTimeStamp = Instant.now().toEpochMilli();
		    //Set value of EndTimeStamp column with endTimeStamp vairable value
		    Entity entity=Entity.newBuilder(datastore.get(entityKey))
		                  .set("EndTimeStamp", endTimeStamp)
		                  .build();
		    //put the value of entity with correct end time stamp value
		    datastore.put(entity);
		    
		    System.out.println("setEndTimeStamp completed");
	  }	
	}
	
	/**
	 * Call Rest API
	 * @param url
	 * @param filePath
	 * @param timestamp
	 */
	public static void callRestAPI(String url, String filePath, Long timestamp){
		try {
			//Create URL object based on url parameter
			System.out.println("callRestAPI");
			URL restAPIEndpoint = new URL(url);
			//open HttpURLConnection
			HttpURLConnection conn = (HttpURLConnection) restAPIEndpoint.openConnection();
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			
			System.out.println("HttpURLConnection conn");
			//pass file path and start time stamp as request variables
			String input = "{\"filePath\": \""+filePath+"\", \"timestamp\": \""+timestamp+"\"}";
			conn.setDoOutput(true);
			System.out.println("input String:"+input);
			DataOutputStream wr = new DataOutputStream(conn.getOutputStream());
			wr.writeBytes(input);
			wr.flush();
			wr.close();
			System.out.println("after write");
			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream())));
			String output;
			while ((output = br.readLine()) != null) {
				System.out.println("Output: "+output);
			}
			conn.disconnect();
		} catch (MalformedURLException exp) {
			LOGGER.error("MalformedURLException from callRestAPI function: {}",exp);
		} catch (IOException exp) {
			LOGGER.error("IOException from callRestAPI function: {}",exp);
		}
	}
	/**
	 * Acknowledge message to pub/sub 
	 * @param pullResponse
	 * @throws Exception
	 */
	public static void acknowledgeSubscribedMessage(PullResponse pullResponse) throws Exception
	{
		//Build an SubscriberStubSettings object that would help in pulling the message
		SubscriberStubSettings subscriberStubSettings =SubscriberStubSettings.newBuilder().build();
		System.out.println("subscriberStubSettings:"+subscriberStubSettings);
		//Create a SubscriberStub which would send the pull request
		try (SubscriberStub subscriber = GrpcSubscriberStub.create(subscriberStubSettings))
		{
			System.out.println("subscriber:"+subscriber);
			//Fetch pub/sub subscription name from project
			String subscriptionName = ProjectSubscriptionName.format(PROJECT_ID, SUBSCRIPTIONID);
			System.out.println("subscriptionName:"+subscriptionName);
			//Define a new list that will contain acknowledgement ID of message
			List<String> ackIds = new ArrayList<>();
			//iterate over message list retrieved in pull response
			for (ReceivedMessage message : pullResponse.getReceivedMessagesList()) {
				//Add message acknowledgement ID in ackIds list
				ackIds.add(message.getAckId());
			}
			System.out.println("after for loop 370");
			// acknowledge received messages
			AcknowledgeRequest acknowledgeRequest =AcknowledgeRequest.newBuilder()
													.setSubscription(subscriptionName)
													.addAllAckIds(ackIds)
													.build();
			System.out.println("acknowledgeRequest:"+acknowledgeRequest);
			//send the request to pub/sub to acknowledge the message
			subscriber.acknowledgeCallable().call(acknowledgeRequest);
		}catch(Exception exp){
		LOGGER.error("Exception in acknowledgeSubscribedMessage function: {}",exp);
		}
	}
}
