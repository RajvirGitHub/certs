/**
 * 
 */
package com.networkedinsights;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.networkedinsights.controller.FileProcessController;
import com.networkedinsights.dto.FileDetailDto;
import com.networkedinsights.dto.FileTraitDto;
import com.networkedinsights.service.IFileService;
import org.junit.Ignore;
/**
 * @author rajvirs
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class FileProcessControllerTest {

	private MockMvc mockMvc;

	@Mock
	private IFileService fileService;

	@InjectMocks
	private FileProcessController fileProcessController;

	@Autowired
	private WebApplicationContext webApplicationContext;
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders
				.standaloneSetup(fileProcessController)
				// .addFilters(new CORSFilter())
				.build();
	}

	@Test
	@Ignore
	public void testFileUpload() throws Exception {
		// Mock Request
		MockMultipartFile firstFile = new MockMultipartFile("file", "filename.txt", "text/plain", "some xml".getBytes());
		// MockMultipartFile jsonFile = new MockMultipartFile("json", "", "application/json", "{\"json\": \"someValue\"}".getBytes());

		MockMvc mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
		mockMvc.perform(MockMvcRequestBuilders.multipart("/core/v1/"
				+ "file/upload?traitId=14887030")
				.file(firstFile)
				// .file(jsonFile)
				.param("some-random", "4"))
		.andExpect(status().is(200));

	}

	@Test
	public void testMakeEntryInDataStoreCallPubSub() 
			throws Exception {

		FileTraitDto dto = new FileTraitDto();
		dto.setFileName("food_eaters_test_1556518878_1556519014.csv");
		dto.setTraitId(14887030);

		mockMvc.perform(
				post("/core/v1/dataStore_pubsub/adobe/type/append")
				.contentType(MediaType.APPLICATION_JSON)
				.content(asJsonString(dto)))
		.andExpect(status().is2xxSuccessful());

	}

	@Test
	public void test1ValidateFile() throws Exception
	{

		FileDetailDto dto = new FileDetailDto();
		dto.setFilePath("ni_dmp_audience_inbound_ui/food_eaters_test_1556518878_1556519014.csv");
		dto.setTimestamp(1555657234838L);

		mockMvc.perform(
				post("/core/v1/file/validate")
				.contentType(MediaType.APPLICATION_JSON)
				.content(asJsonString(dto)))
		.andExpect(status().is2xxSuccessful());
	}

	@Test
	public void test2LoadSocialIdToFile() throws Exception
	{

		FileDetailDto dto = new FileDetailDto();
		dto.setFilePath("ni_dmp_audience_inbound_ui/food_eaters_test_1556518878_1556519014.csv");
		dto.setTimestamp(1555657234838L);

		mockMvc.perform(
				post("/core/v1/file/load_social_id")
				.contentType(MediaType.APPLICATION_JSON)
				.content(asJsonString(dto)))
		.andExpect(status().is2xxSuccessful());

	}

	@Test
	public void test3SyncAdobeUUIdWithSocialId() throws Exception
	{
		FileDetailDto dto = new FileDetailDto();
		dto.setFilePath("ni_dmp_audience_inbound_ui/food_eaters_test_1556518878_1556519014.csv");
		dto.setTimestamp(1555657234838L);

		mockMvc.perform(
				post("/core/v1/file/adobeuuid")
				.contentType(MediaType.APPLICATION_JSON)
				.content(asJsonString(dto)))
		.andExpect(status().is2xxSuccessful());
	}

	@Test
	public void test4UploadOutboundFileGCS() throws Exception
	{
		FileDetailDto dto = new FileDetailDto();
		dto.setFilePath("ni_dmp_audience_inbound_ui/food_eaters_test_1556518878_1556519014.csv");
		dto.setTimestamp(1555657234838L);

		mockMvc.perform(
				post("/core/v1/file/upload_outbound_gcs")
				.contentType(MediaType.APPLICATION_JSON)
				.content(asJsonString(dto)))
		.andExpect(status().is2xxSuccessful());

	}

	@Test
	public void test5CreateIntermediateFileForGCS() throws Exception
	{
		FileDetailDto dto = new FileDetailDto();
		dto.setFilePath("ni_dmp_audience_inbound_ui/food_eaters_test_1556518878_1556519014.csv");
		dto.setTimestamp(1555657234838L);

		mockMvc.perform(
				post("/core/v1/file/intermediate_gcs")
				.contentType(MediaType.APPLICATION_JSON)
				.content(asJsonString(dto)))
		.andExpect(status().is2xxSuccessful());
	}

	@Test
	public void test6UploadInboundFileToS3Bucket() throws Exception
	{
		FileDetailDto dto = new FileDetailDto();
		dto.setFilePath("ni_dmp_audience_inbound_ui/food_eaters_test_1556518878_1556519014.csv");
		dto.setTimestamp(1555657234838L);

		mockMvc.perform(
				post("/core/v1/file/upload_S3")
				.contentType(MediaType.APPLICATION_JSON)
				.content(asJsonString(dto)))
		.andExpect(status().is2xxSuccessful());

	}

	public static String asJsonString(final Object obj) {
		try {
			final ObjectMapper mapper = new ObjectMapper();
			return mapper.writeValueAsString(obj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
