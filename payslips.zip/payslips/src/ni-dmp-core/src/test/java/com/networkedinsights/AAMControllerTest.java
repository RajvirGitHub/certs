/**
 * 
 */
package com.networkedinsights;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.networkedinsights.controller.AAMController;
import com.networkedinsights.dto.TraitDto;
import com.networkedinsights.service.IAAMService;

/**
 * @author rajvirs
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class AAMControllerTest {

	private MockMvc mvc;

	@Mock
	private IAAMService aamService;

	@InjectMocks
	private AAMController aamController;

	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
		mvc = MockMvcBuilders
				.standaloneSetup(aamController)
				// .addFilters(new CORSFilter())
				.build();
	}

	@Test
	public void testFetchTraitList() throws Exception {

		mvc.perform(get("/core/v1/trait"))
		.andExpect(status().is2xxSuccessful());
	}

	@Test
	public void testFetchTraitById() throws Exception
	{
		String traitId = "14887030";
		mvc.perform(get("/core/v1/trait/"+traitId))
		.andExpect(status().is2xxSuccessful());

	}

	@Test
	public void testReloadTraitList() throws Exception
	{
		mvc.perform(get("/core/v1/reload/trait"))
		.andExpect(status().is2xxSuccessful());
	}

	@Test
	public void testCreateTrait() throws Exception {
		TraitDto dto = new TraitDto();
		dto.setName("name JUNIT");
		dto.setDescription("descr JUNIT test case");
		dto.setTtl(33);

		mvc.perform(
				post("/core/v1/trait")
				.contentType(MediaType.APPLICATION_JSON)
				.content(asJsonString(dto)))
		.andExpect(status().is2xxSuccessful());
	}

	public static String asJsonString(final Object obj) {
		try {
			final ObjectMapper mapper = new ObjectMapper();
			return mapper.writeValueAsString(obj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
