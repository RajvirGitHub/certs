/**
 * 
 */
package com.networkedinsights.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.cloud.datastore.Datastore;
import com.google.cloud.datastore.Entity;
import com.google.cloud.datastore.Query;
import com.google.cloud.datastore.QueryResults;
import com.google.cloud.datastore.StructuredQuery.PropertyFilter;
import com.networkedinsights.dto.DistributionsDto;
import com.networkedinsights.dto.JobStatsDto;
import com.networkedinsights.exception.NIDmpException;
import com.networkedinsights.service.IAAMService;
import com.networkedinsights.service.IDistributionsService;
import com.networkedinsights.util.ConstantsUtil;
import com.networkedinsights.util.DateUtility;

/**
 * @author rajvirs
 * created on - 13/08/2019
 * modified on - 13/08/2019
 */
@Service
public class DistributionsServiceImpl implements IDistributionsService{

	private static final Logger LOGGER = LoggerFactory.getLogger(DistributionsServiceImpl.class);

	@Autowired
	private Datastore datastore;

	@Autowired
	private IAAMService aamServiceImpl;

	@Override
	public List<DistributionsDto> getDistributionsHistory(String filename) {

		List<DistributionsDto> distributionsList = new ArrayList<>();
		try {
			QueryResults<Entity> result = fetchDHByFilename(filename);
			while (result.hasNext()) {
				Entity entity = result.next();
				DistributionsDto distributionsDto = new DistributionsDto();

				populateDistributionsDto(entity, distributionsDto);

				populateStatus(entity, distributionsDto);
				populateMatchRate(entity, distributionsDto);

				distributionsList.add(distributionsDto);
			}

			// Sorting list using lambda function Java8 Desc order
			distributionsList.sort((DistributionsDto t1, 
					DistributionsDto t2)->t2.getDistributions().compareTo(t1.getDistributions()));

		} catch (Exception e) {
			LOGGER.error(
					"DistributionsServiceImpl.getDistributionsHistory(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"DistributionsServiceImpl.getDistributionsHistory(): {} , Error MEssage: {}", e);
		}
		return distributionsList;
	}


	/**
	 * Populate DistributionsDto object
	 * @param entity
	 * @param distributionsDto
	 */
	private void populateDistributionsDto(Entity entity, DistributionsDto distributionsDto) {
		distributionsDto.setDestination(entity.getString(
				ConstantsUtil.DESTINATION));
		distributionsDto.setDistributionDate(entity.getString(
				ConstantsUtil.DISTRIBUTION_DATE));
		distributionsDto.setFileName(entity.getString(
				ConstantsUtil.FILENAME));
		distributionsDto.setInboundRecords(entity.getString(
				ConstantsUtil.INBOUND_CNT));
		distributionsDto.setMatchedRecords(entity.getString(
				ConstantsUtil.MATCHED_CNT));
		int distributionNo = (int) entity.getLong(
				ConstantsUtil.DISTRIBUTIONS);
		distributionsDto.setDistributions(distributionNo);
		distributionsDto.setDhTimeStamp(entity.getLong(
				ConstantsUtil.DIST_TIMESTAMP));		// Added to keep track of unique records

		if (entity.contains(ConstantsUtil.DISTRIBUTION_TYPE)) {
			distributionsDto.setDistributionType(entity.
					getString(ConstantsUtil.DISTRIBUTION_TYPE));
		}

		// Setting Adobe Inbound Aud Filename
		if (entity.contains(ConstantsUtil.INBOUND_AUD_FILENAME)) {
			distributionsDto.setAdobeInboundAudFile(entity
					.getString(ConstantsUtil.INBOUND_AUD_FILENAME));
		}
		// Setting jobIdName | Changes for CYBG-310 |
		// fetch job stats for distribution type=email, all_email in ni-leads distribution.
		if (entity.contains(ConstantsUtil.JOB_ID_NAME)) {
			distributionsDto.setJobIdName(entity.
					getString(ConstantsUtil.JOB_ID_NAME));
		}
	}

	/**
	 * Fetch Distribution History by filename
	 * @param filename
	 * @return
	 */
	private QueryResults<Entity> fetchDHByFilename(String filename) {
		// Build the Query
		Query<Entity> query = Query.newEntityQueryBuilder()
				.setKind(ConstantsUtil.DISTRIBUTION_HISTORY)                                
				.setFilter(PropertyFilter.eq(ConstantsUtil.FILENAME, filename))
				.build();
		return datastore.run(query);
	}
	
	


	/** Set IngestedRecords, matchedRecords and MatchRate
	 * @param result
	 * @param dto
	 */
	private void populateMatchRate(Entity result, DistributionsDto dto) {
		String ingestedRecords = result.getString(ConstantsUtil.INBOUND_CNT);

		String matchedRecords = result.getString(ConstantsUtil.MATCHED_CNT);

		if(null != ingestedRecords && 
				ingestedRecords.trim().matches(ConstantsUtil.DIGIT_PATTERN_REGEX)
				&& null != matchedRecords && 
				matchedRecords.trim().matches(ConstantsUtil.DIGIT_PATTERN_REGEX)) {

			Integer matchRate = (int)Math.round((Double.parseDouble(matchedRecords.trim())
					/Double.parseDouble(ingestedRecords.trim()))*100);
			dto.setMatchRate(matchRate + "%");
		}
	}


	/**
	 * This method sets the Status as per file 
	 * current status from Datastore
	 * @param result
	 * @param dto
	 * @param fileNameList
	 */
	private void populateStatus(Entity entity, DistributionsDto 
			distributionsDto) {

		List<String> fileNameList = aamServiceImpl.fetchFileNameList();

		if (ConstantsUtil.FILE_DISTRIBUTED.equalsIgnoreCase(entity.getString(
				ConstantsUtil.STATUS)) && fileNameList.contains(entity.getString(
						ConstantsUtil.INBOUND_AUD_FILENAME))) {
			// File distributed to Adobe for processing OR Error at some stage
			distributionsDto.setStatus(ConstantsUtil.PROCESSING_COMPLETED);

		} else {
			distributionsDto.setStatus(entity.getString(ConstantsUtil.STATUS));
		}

	}

	//@Cacheable(value = "jobStats", cacheManager="timeoutCacheManager")
	//@Cacheable(value = "jobStats")
	@Override
	public JobStatsDto getJobStats(String adobeFilename) {
		LOGGER.info("getJobSTats called");
		JobStatsDto jobStatsDto = null;
		try {

			QueryResults<Entity> result = fetchJobStatsByFilename(adobeFilename);
			if (result.hasNext()) {
				Entity entity = result.next();

				// Set JobStatsDto
				jobStatsDto = new JobStatsDto();
				jobStatsDto.setDataFileName(entity.getString(
						ConstantsUtil.DATA_FILENAME));
				Long processingStartTime =
						entity.getLong(ConstantsUtil.STARTTIME);
				jobStatsDto.setProcessingStartTime(DateUtility.getFormattedDateStringUtc(processingStartTime));
				Long processingEndTime = entity.getLong(
						ConstantsUtil.ENDTIME);
				jobStatsDto.setProcessingEndTime(DateUtility.getFormattedDateStringUtc(processingEndTime));
				
				jobStatsDto.setStartTime(entity.getLong(ConstantsUtil.STARTTIME));
				jobStatsDto.setEndTime(entity.getLong(
						ConstantsUtil.ENDTIME));
				jobStatsDto.setFailedInvalidDemdexUUID(
						(int)entity.getLong(ConstantsUtil.FAILED_INVALID_DEMDEX));
				jobStatsDto.setFailedNoRealizedTrait(
						(int)entity.getLong(ConstantsUtil.FAILED_NO_REALIZED_TRAITS));
				jobStatsDto.setFailedParseCheck(
						(int)entity.getLong(ConstantsUtil.FAILED_PARSE_CHECK));
				jobStatsDto.setFailedPCSTimeoutTraitsLookup(
						(int)entity.getLong(ConstantsUtil.FAILED_PCS_TIMEOUT_TRAITS));
				jobStatsDto.setFailedPCSTimeoutUUIDLookup(
						(int)entity.getLong(ConstantsUtil.FAILED_PCS_TIMEOUT_UUID));
				jobStatsDto.setFailedUUIDLookup(
						(int)entity.getLong(ConstantsUtil.FAILED_UUID_LOOKUP));
				jobStatsDto.setIdSyncDpid(
						(int)entity.getLong(ConstantsUtil.ID_SYNC_DPID));
				jobStatsDto.setPercentageSuccess(
						(int)entity.getLong(ConstantsUtil.PERCENTAGE_SUCCESS));
				jobStatsDto.setPercentageUsedSignals(
						(int)entity.getLong(ConstantsUtil.PERCENTAGE_USED_SIGNALS));
				jobStatsDto.setRecordsReceived(
						(int)entity.getLong(ConstantsUtil.RECORDS_RCVD));
				jobStatsDto.setRecordsSuccess(
						(int)entity.getLong(ConstantsUtil.RECORDS_SUCCESS));
				jobStatsDto.setSamplingAvailable(
						entity.getBoolean(ConstantsUtil.SAMPLING_AVAILABLE));
				
				jobStatsDto.setTotalInvalidGlobalDeviceIds(
						(int)entity.getLong(ConstantsUtil.TOTAL_INVALID_GLOBAL_DEVICE_IDS));
				jobStatsDto.setTotalNewTraits(
						(int)entity.getLong(ConstantsUtil.TOTAL_NEW_TRAITS));
				jobStatsDto.setTotalrealizedtraits(
						(int)entity.getLong(ConstantsUtil.TOTAL_REALIZED_TRAITS));
				jobStatsDto.setTotalRemovedTraits(
						(int)entity.getLong(ConstantsUtil.TOTAL_REMOVED_TRAITS));
				jobStatsDto.setTotalSignals(
						(int)entity.getLong(ConstantsUtil.TOTAL_SIGNALS));
				jobStatsDto.setTotalUnusedSignals(
						(int)entity.getLong(ConstantsUtil.TOTAL_UNUSED_SIGNALS));
			}
		} catch (Exception e) {
			LOGGER.error(
					"DistributionsServiceImpl.getJobStats(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"DistributionsServiceImpl.getJobStats(): {} , Error MEssage: {}", e);
		}

		return jobStatsDto; 
	}

	/**
	 * Fetch Job Stats by filename
	 * @param filename
	 * @return
	 */
	private QueryResults<Entity> fetchJobStatsByFilename(String adobeFilename) {
		// Build the Query
		Query<Entity> query = Query.newEntityQueryBuilder()
				.setKind(ConstantsUtil.JOBSTATS)  
				.setFilter(PropertyFilter.eq(ConstantsUtil.DATA_FILENAME, adobeFilename))
				.build();
		return datastore.run(query);
	}




}
