package com.networkedinsights.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * @author rajvirs
 * created on - 13/02/2018
 * modified on - 14/02/2018
 */
@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR, reason = "Exception occured")
public class NIDmpException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private String errCode;

	private String errMsg;

	public String getErrCode() {
		return errCode;
	}

	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}

	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}

	// get, set..
	public NIDmpException(String errMsg) {
		super(errMsg);
		this.errMsg = errMsg;
	}

	public NIDmpException(String message, Throwable cause, String errCode) {
		super(message, cause);
		this.errCode = errCode;
	}

	public NIDmpException(String message, Throwable cause) {
		super(message, cause);
	}

	@Override
	public String getMessage() {
		return super.getMessage();
	}

}
