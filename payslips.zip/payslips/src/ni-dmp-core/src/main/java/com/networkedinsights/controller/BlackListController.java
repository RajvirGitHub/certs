package com.networkedinsights.controller;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.networkedinsights.service.IBlackListService;


@RestController
@RequestMapping("/core/v1")
public class BlackListController extends AbstractBaseController{

	@Autowired
	private IBlackListService blackListService;
	public static final Logger LOGGER = LoggerFactory.getLogger(BlackListController.class);

	/**
	 * This method For insert records to the global black list table
	 * @param file
	 * @param username
	 * @return
	 * @throws IOException
	 */
	@PostMapping(value = "/upload_blacklist/{username}", headers = ("content-type=multipart/*"))
	public ResponseEntity<Integer> uploadBlackListFile(@RequestParam("file") MultipartFile file,
			@PathVariable String username) throws IOException {

		LOGGER.info("Upload BlackList file");
		return ResponseEntity.ok(blackListService.uploadBlackListFile(file, username));

	}
	/**
	 * This method For count records from the global black list table
	 * @return
	 */

	@GetMapping(value = "/blacklist")
	public  ResponseEntity<Long> uploadFileInBlacklist() {
		LOGGER.info("Upload file in blacklist");
		return ResponseEntity.ok(blackListService.fetchAllBlackList());

	}

	/**
	 * This method For email verification on global black list table
	 * @param email
	 * @return
	 */
	@GetMapping(value = "/blacklist_verification/{email}")
	public  ResponseEntity<Boolean> verificationInBlacklist(@PathVariable String email) {
		LOGGER.info("Upload file in blacklist");
		return ResponseEntity.ok(blackListService.checkEmailInBlacklist(email));

	}


}

