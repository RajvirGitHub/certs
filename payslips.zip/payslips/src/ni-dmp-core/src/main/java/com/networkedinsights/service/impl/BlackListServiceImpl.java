package com.networkedinsights.service.impl;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.google.api.client.util.Charsets;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.BigQueryOptions;
import com.google.cloud.bigquery.FieldValueList;
import com.google.cloud.bigquery.FormatOptions;
import com.google.cloud.bigquery.Job;
import com.google.cloud.bigquery.JobId;
import com.google.cloud.bigquery.JobInfo;
import com.google.cloud.bigquery.JobStatistics.LoadStatistics;
import com.google.cloud.bigquery.QueryJobConfiguration;
import com.google.cloud.bigquery.TableDataWriteChannel;
import com.google.cloud.bigquery.TableId;
import com.google.cloud.bigquery.TableResult;
import com.google.cloud.bigquery.WriteChannelConfiguration;
import com.networkedinsights.exception.NIDmpException;
import com.networkedinsights.service.IBlackListService;
import com.networkedinsights.util.ConstantsUtil;

@Service
public class BlackListServiceImpl implements IBlackListService{

	private static final Logger LOGGER = LoggerFactory.getLogger(BlackListServiceImpl.class);

	@Value("${pathto.credkey.datum}")
	private String pathToJsonKey;

	@Value("${project.name}")
	private String projectName;

	@Value("${datum.blacklist.table}")
	private String blacklistTable;

	@Value("${datum.project.name}")
	private String datumProjectName;

	@Value("${datum.dataset.name.dev}")
	private String datumDatasetNameDev;

	@Value("${datum.dataset.name.prod}")
	private String datumDatasetNameProd;

	@Value("${gbl.maxbatch.rowcount}")
	private Integer maxBatch;
	

	private BigQueryOptions getOptions() throws IOException {
		LOGGER.info("before creating options");

		BigQueryOptions options = null;
		options = BigQueryOptions.newBuilder()
				.setProjectId(datumProjectName)	
				.setCredentials(GoogleCredentials.fromStream(
						new FileInputStream(pathToJsonKey)))
				.build();
		LOGGER.info("after options");
		return options;
	}

	/**
	 * This method For count records from the global black list table
	 */

	@Override
	public Long fetchAllBlackList() {

		// Distributing (1st time for a qtl) 
		BigQueryOptions options = null;
		long totalRows=0;
		try {

			options = getOptions();
			BigQuery bigQuery2 = options.getService();

			// Make changes here to take table name from Datastore
			// Modified query to include trait Id and delimeter in Select
			String countRecordsQuery = "SELECT count( DISTINCT md5) "
					+ "FROM "
					+"`"+datumProjectName+ConstantsUtil.POINT+
					findDatasetName()+ConstantsUtil.POINT+
					blacklistTable+"`;"; 
			
			TableResult result = fetchRowsFromBlacklist(countRecordsQuery, bigQuery2);
			
			totalRows = findCountOfBlacklistedEmails(result);

			LOGGER.info("Blacklisted emails count is:{}", totalRows);

		}

		catch (Exception e) {
			LOGGER.error(
					"BlackListService.fetchAllBlackList():{} , Error Message : {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"BlackListService.fetchAllBlackList(): {} , Error MEssage: {}", e);

		}
		return totalRows ;
	}
	/**
	 * This method For hash email using MD5 
	 * @param input
	 * @return
	 * @throws NoSuchAlgorithmException
	 */
	// MD5 logic
	private String md5Encryption(String input) throws NoSuchAlgorithmException 
	{ 

		StringBuilder sb = new StringBuilder();

		// Static getInstance method is called with hashing MD5 
		MessageDigest md = MessageDigest.getInstance("MD5"); 

		// digest() method is called to calculate message digest 
		//  of an input digest() return array of byte 
		byte[] messageDigest = md.digest(input.getBytes()); 

		for (byte b : messageDigest) {
			sb.append(String.format("%02x", b));
		}

		return sb.toString();


	}

	/**
	 * Fetch result from Blacklist table
	 * @param query
	 * @param bigQuery2
	 * @return
	 * @throws InterruptedException
	 */

	private TableResult fetchRowsFromBlacklist(String query,
			BigQuery bigQuery2) throws InterruptedException
	{
		LOGGER.info("fetchRowsFromBlacklist called");
		QueryJobConfiguration queryConfig = QueryJobConfiguration.newBuilder(query)
				// Save the results of the query to a permanent table.
				.setUseLegacySql(false)
				.build();
		LOGGER.info("Blacklist queryConfig created");
		JobId jobId = JobId.of(UUID.randomUUID().toString());
		LOGGER.info("Blacklist jobId: {}", jobId);
		Job queryJob = bigQuery2.create(JobInfo.newBuilder(queryConfig).setJobId(jobId).build());
		LOGGER.info("Blacklist queryJob: {}", queryJob);
		queryJob = queryJob.waitFor();
		LOGGER.info("Blacklist queryJob.waitFor ");
		return queryJob.getQueryResults();
	}

	/**
	 * Example of creating a channel with which to write to a table.
	 * @param datasetName
	 * @param tableName
	 * @param csvData
	 * @param bigQuery2
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private long writeToTable(String datasetName, String tableName, 
			String csvData, BigQuery bigQuery2)
					throws IOException, InterruptedException {
		// [START writeToTable]
		TableId tableId = TableId.of(datasetName, tableName);
		LOGGER.info("tableId getProject() is: {}", tableId.getProject());
		WriteChannelConfiguration writeChannelConfiguration =
				WriteChannelConfiguration.newBuilder(tableId)
				.setFormatOptions(FormatOptions.csv())
				.build();
		LOGGER.info("writer channel config:{}",writeChannelConfiguration);
		TableDataWriteChannel writer = bigQuery2.writer(writeChannelConfiguration);
		LOGGER.info("writer channel created:{}", writer);
		// Write data to writer
		try {
			writer.write(ByteBuffer.wrap(csvData.getBytes(Charsets.UTF_8)));
			LOGGER.info("After writer.write");
		} finally {
			writer.close();
		}
		// Get load job
		Job job = writer.getJob();
		job = job.waitFor();
		LoadStatistics stats = job.getStatistics();
		return stats.getOutputRows();
		// [END writeToTable]
	}

	/**
	 * This method For insert records to the global black list table
	 */

	@Override
	public Integer uploadBlackListFile(MultipartFile file, String username) throws IOException {

		SimpleDateFormat sdf = new SimpleDateFormat(ConstantsUtil.DATE_IN_YYMMDD_TIME);
		sdf.setTimeZone(TimeZone.getTimeZone(ConstantsUtil.UTC));
		int totalCount = 0;
		BigQueryOptions options = null;
		try {
			String dateTime = sdf.format(new Date());


			long startTime = System.currentTimeMillis();
			LOGGER.info("Start Time: {}", startTime);
			if (!file.isEmpty()) {

				byte[] fileBytes = file.getBytes();
				String completeData = new String(fileBytes);
				String[] allRows = completeData.split("(\\r\\n|\\n|\\r)");
				List<String> list = Arrays.asList(allRows);

				username = getTrimUsername(username);	// trims the username

				StringBuilder tableRecords = new StringBuilder(ConstantsUtil.BLANK_SPACE);
				int rowCount = 0;

				Iterator<String> itr = list.iterator();

				while (itr.hasNext()) {
					String obj = itr.next();
					String [] objArr = obj.split(",");
					if (null != objArr && objArr.length > 0 &&
							objArr[0].contains("@")) {
						// To skip the header row
						String email = objArr[0];
						// Call MD5 logic to Encrypt Email

						tableRecords.append(md5Encryption(email.toLowerCase()))
						.append(ConstantsUtil.COMMA_DEL).append(dateTime)
						.append(ConstantsUtil.COMMA_DEL).append(username)
						.append(ConstantsUtil.NEWLINE_SEPARATOR);

						rowCount++;

						if (!itr.hasNext() || rowCount == maxBatch) {
							LOGGER.info(" ** writeToTable called");
							// For inserting in Dev
							options = getOptions();
							BigQuery bigQuery2 = options.getService();


							String datasetName = findDatasetName();
							LOGGER.info("Datasetname is: {}", datasetName);


							writeToTable( datasetName, blacklistTable, 
									tableRecords.toString(), bigQuery2);
							
							

							totalCount += rowCount;
							tableRecords = new StringBuilder(ConstantsUtil.BLANK_SPACE);
							rowCount = 0;
						}
					}
				}
				LOGGER.info("After For totalCount: {}", totalCount);
				// Insert queries

				LOGGER.info("Total Time: {}", (System.currentTimeMillis() -startTime));
			}
		} catch (Exception e) {
			LOGGER.error(
					"BlackListServiceImpl.uploadBlackListFile(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());

			throw new NIDmpException(
					"BlackListServiceImpl.uploadBlackListFile(): {} , Error MEssage: {}", e);
		}

		return totalCount;

	}

	/**
	 * This method helps to find data set name
	 * @return
	 */
	private String findDatasetName() {
		String dataset = null;
		if (projectName.contains("prod")) {
			dataset = datumDatasetNameProd;
		} else {
			dataset = datumDatasetNameDev;
		}
		return dataset;
	}

	/** 
	 * Find count of Blacklisted Emails
	 * @param resultCount
	 */
	private Long findCountOfBlacklistedEmails(TableResult resultCount) {
		Long adobeuuidCount2 = 0l;
		for (FieldValueList row : resultCount.iterateAll()) {
			String adobeuuidCount = (String) row.get(0).getValue();
			adobeuuidCount2 = Long.parseLong(adobeuuidCount);
		}
		return adobeuuidCount2;
	}

	/**
	 * This method helps to pull the username
	 * from incoming username detail string.
	 * @param user
	 * @return
	 */
	private String getTrimUsername(String user) {
		String [] usernameArr = user.split(":");
		if (null != usernameArr && usernameArr.length > 1) {
			return usernameArr[1];
		}
		return user;
	}

	@Override
	public boolean checkEmailInBlacklist(String email) {

		boolean flag = false;

		BigQueryOptions options = null;

		try{

			//For dev env.

			options = getOptions();
			BigQuery bigQuery2 = options.getService();
			LOGGER.info("bigQuery2 created to access Blacklist table");

			String verifyQuery = "SELECT result.md5 "
					+ "FROM "
					+"`"+datumProjectName+ConstantsUtil.POINT+
					findDatasetName()+ConstantsUtil.POINT+
					blacklistTable+"`" 
					+ "as result "
					+ "WHERE "
					+ "result.md5 ='"+email+"';";

			TableResult result = fetchRowsFromBlacklist(verifyQuery,bigQuery2);

			if(null != result && result.getTotalRows() > 0)
			{
				flag=true;
			}
			else {
				flag=false;
			}

		}
		catch (Exception e) {
			LOGGER.error(
					"BlackListServiceImpl.checkEmailInBlacklist(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"BlackListServiceImpl.checkEmailInBlacklist(): {} , Error MEssage: {}", e);
		}
		return flag;
	}


}
