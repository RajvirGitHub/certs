/**
 * 
 */
package com.networkedinsights.dto;

/**
 * @author rajvirs
 *
 */
public class JobStatsDto {
	
	private String dataFileName;
	private Integer idSyncDpid;
	private Integer recordsReceived;
	private Integer recordsSuccess;
	private Integer percentageSuccess;
	private Integer failedParseCheck;
	private Integer failedPCSTimeoutUUIDLookup;
	private Integer failedPCSTimeoutTraitsLookup;
	private Integer failedUUIDLookup;
	private Integer failedInvalidDemdexUUID;
	private Integer failedNoRealizedTrait;
	private Integer totalSignals;
	private Integer totalUnusedSignals;
	private Integer totalrealizedtraits;
	private Integer totalRemovedTraits;
	private Integer totalNewTraits;
	private Integer percentageUsedSignals;
	private Long startTime;
	private Long endTime;
	private String processingStartTime;
	private String processingEndTime;
	private Boolean samplingAvailable;
	private Integer totalInvalidGlobalDeviceIds;
	
	public String getDataFileName() {
		return dataFileName;
	}
	public void setDataFileName(String dataFileName) {
		this.dataFileName = dataFileName;
	}
	
	
	
	public Integer getIdSyncDpid() {
		return idSyncDpid;
	}
	public void setIdSyncDpid(Integer idSyncDpid) {
		this.idSyncDpid = idSyncDpid;
	}
	public Integer getRecordsReceived() {
		return recordsReceived;
	}
	public void setRecordsReceived(Integer recordsReceived) {
		this.recordsReceived = recordsReceived;
	}
	public Integer getRecordsSuccess() {
		return recordsSuccess;
	}
	public void setRecordsSuccess(Integer recordsSuccess) {
		this.recordsSuccess = recordsSuccess;
	}
	public Integer getPercentageSuccess() {
		return percentageSuccess;
	}
	public void setPercentageSuccess(Integer percentageSuccess) {
		this.percentageSuccess = percentageSuccess;
	}
	public Integer getFailedParseCheck() {
		return failedParseCheck;
	}
	public void setFailedParseCheck(Integer failedParseCheck) {
		this.failedParseCheck = failedParseCheck;
	}
	public Integer getFailedPCSTimeoutUUIDLookup() {
		return failedPCSTimeoutUUIDLookup;
	}
	public void setFailedPCSTimeoutUUIDLookup(Integer failedPCSTimeoutUUIDLookup) {
		this.failedPCSTimeoutUUIDLookup = failedPCSTimeoutUUIDLookup;
	}
	public Integer getFailedPCSTimeoutTraitsLookup() {
		return failedPCSTimeoutTraitsLookup;
	}
	public void setFailedPCSTimeoutTraitsLookup(Integer failedPCSTimeoutTraitsLookup) {
		this.failedPCSTimeoutTraitsLookup = failedPCSTimeoutTraitsLookup;
	}
	public Integer getFailedUUIDLookup() {
		return failedUUIDLookup;
	}
	public void setFailedUUIDLookup(Integer failedUUIDLookup) {
		this.failedUUIDLookup = failedUUIDLookup;
	}
	public Integer getFailedInvalidDemdexUUID() {
		return failedInvalidDemdexUUID;
	}
	public void setFailedInvalidDemdexUUID(Integer failedInvalidDemdexUUID) {
		this.failedInvalidDemdexUUID = failedInvalidDemdexUUID;
	}
	public Integer getFailedNoRealizedTrait() {
		return failedNoRealizedTrait;
	}
	public void setFailedNoRealizedTrait(Integer failedNoRealizedTrait) {
		this.failedNoRealizedTrait = failedNoRealizedTrait;
	}
	public Integer getTotalSignals() {
		return totalSignals;
	}
	public void setTotalSignals(Integer totalSignals) {
		this.totalSignals = totalSignals;
	}
	public Integer getTotalUnusedSignals() {
		return totalUnusedSignals;
	}
	public void setTotalUnusedSignals(Integer totalUnusedSignals) {
		this.totalUnusedSignals = totalUnusedSignals;
	}
	public Integer getTotalrealizedtraits() {
		return totalrealizedtraits;
	}
	public void setTotalrealizedtraits(Integer totalrealizedtraits) {
		this.totalrealizedtraits = totalrealizedtraits;
	}
	public Integer getTotalRemovedTraits() {
		return totalRemovedTraits;
	}
	public void setTotalRemovedTraits(Integer totalRemovedTraits) {
		this.totalRemovedTraits = totalRemovedTraits;
	}
	public Integer getTotalNewTraits() {
		return totalNewTraits;
	}
	public void setTotalNewTraits(Integer totalNewTraits) {
		this.totalNewTraits = totalNewTraits;
	}
	public Integer getPercentageUsedSignals() {
		return percentageUsedSignals;
	}
	public void setPercentageUsedSignals(Integer percentageUsedSignals) {
		this.percentageUsedSignals = percentageUsedSignals;
	}
	public Long getStartTime() {
		return startTime;
	}
	public void setStartTime(Long startTime) {
		 this.startTime = startTime;
	}
	public Long getEndTime() {
		return endTime;
	}

	public void setEndTime(Long endTime) {
		 this.endTime = endTime;
	}
	public Boolean getSamplingAvailable() {
		return samplingAvailable;
	}
	public void setSamplingAvailable(Boolean samplingAvailable) {
		this.samplingAvailable = samplingAvailable;
	}
	public Integer getTotalInvalidGlobalDeviceIds() {
		return totalInvalidGlobalDeviceIds;
	}
	public void setTotalInvalidGlobalDeviceIds(Integer totalInvalidGlobalDeviceIds) {
		this.totalInvalidGlobalDeviceIds = totalInvalidGlobalDeviceIds;
	}
	public String getProcessingStartTime() {
		return processingStartTime;
	}
	public void setProcessingStartTime(String processingStartTime) {
		this.processingStartTime = processingStartTime;
	}
	public String getProcessingEndTime() {
		return processingEndTime;
	}
	public void setProcessingEndTime(String processingEndTime) {
		this.processingEndTime = processingEndTime;
	}
	
	}

