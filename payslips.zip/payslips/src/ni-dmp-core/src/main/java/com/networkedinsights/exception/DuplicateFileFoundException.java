package com.networkedinsights.exception;

/**
 * @author rajvirs
 * created on - 14/02/2018
 * modified on - 14/02/2018
 */
public class DuplicateFileFoundException extends RuntimeException {

	private static final long serialVersionUID = 4666373954026847261L;

	public DuplicateFileFoundException(String string) {
		super(string);
	}

}
