/**
 * 
 */
package com.networkedinsights.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.networkedinsights.service.IFileService;

/**
 * @author rajvirs
 *
 */
@RestController
public class RootController extends AbstractBaseController{

	private static final Logger LOGGER = LoggerFactory.getLogger(RootController.class);
	
	@Autowired
	private IFileService fileService;
	/**
	 * This is the method for root url.
	 * @return
	 */
	@GetMapping("/")
	public ResponseEntity<String> startURL() {
		
		return ResponseEntity.ok("Welcome to DMP AAM!");
	}
	
	/**
	 * This method will pass html file
	 * to push subscriber
	 * @param fileName
	 * @return
	 */
	@GetMapping(value = "/core/pushSubscriber/{fileName}")
	public ResponseEntity<byte[]> pushSubscriberSendFile(
			@PathVariable String fileName) {
		LOGGER.info("Send File Push Subscriber called");

		byte [] byteArray = fileService.getHtmlFile(fileName);

		return ResponseEntity.ok()
				.contentType(contentType(fileName))
				.header(HttpHeaders.CONTENT_DISPOSITION,"attachment; filename=\"" + fileName + "\"")
				.body(byteArray);
	}
	
	/**
	 * Finds the contentType of file
	 * by looking at the extension
	 * @param fileName
	 * @return
	 */
	private MediaType contentType(String fileName) {
		String[] arr = fileName.split("\\.");
		String type = arr[arr.length-1];
		switch(type) {
			case "txt": return MediaType.TEXT_PLAIN;
			case "png": return MediaType.IMAGE_PNG;
			case "jpg": return MediaType.IMAGE_JPEG;
			default: return MediaType.APPLICATION_OCTET_STREAM;
		}
	}
}
