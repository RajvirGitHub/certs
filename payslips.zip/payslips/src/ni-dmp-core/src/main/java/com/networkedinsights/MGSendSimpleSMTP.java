package com.networkedinsights;

//import org.apache.http.HttpResponse;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;

public class MGSendSimpleSMTP {

    public static void main(String args[]) throws Exception {

    	HttpResponse<JsonNode> request = Unirest.post("https://api.mailgun.net/v3/mg.networkedinsights.com/messages")
				.basicAuth("api", "key-d8bd51d17be7ab3777c464ac3d54a9b7")
				//.header("content-type", "multipart/form-data;")
				.field("from", "noreply-logistics@mg.networkedinsights.com")
				.field("to", "swapnil.waghmode@networkedinsights.com")
				.field("subject", "sub")
				.field("html", "<html><a href='www.google.com'>abcd</a></html>").asJson();
				//.field("html", StringEscapeUtils.escapeHtml4("<html>HTML version </html>")).asString();
		
		System.out.println(request.getStatusText()+" : "+request.getStatus());
    }
}