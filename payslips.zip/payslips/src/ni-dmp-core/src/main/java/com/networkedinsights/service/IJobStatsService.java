/**
 * 
 */
package com.networkedinsights.service;

/**
 * @author rajvirs
 *
 */
public interface IJobStatsService {

	public boolean storeJobStats(Long timestamp);
}
