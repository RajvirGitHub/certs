/**
 * 
 */
package com.networkedinsights.dto;

import com.google.gson.annotations.SerializedName;

/**
 * @author rajvirs
 *
 */
public class AAMTokenMappingDto {
	
	@SerializedName("access_token")
	private String accessToken;
	

	
	@SerializedName("expires_in")
    private Integer expiresIn; 	// 3599,

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public Integer getExpiresIn() {
		return expiresIn;
	}

	public void setExpiresIn(Integer expiresIn) {
		this.expiresIn = expiresIn;
	}


}
