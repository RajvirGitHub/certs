/**
 * 
 */
package com.networkedinsights.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.networkedinsights.dto.DistributionsDto;
import com.networkedinsights.dto.JobStatsDto;
import com.networkedinsights.dto.PiiPubSubAttributesDto;
import com.networkedinsights.service.IDistributionsService;
import com.networkedinsights.service.INILeadsService;

/**
 * @author rajvirs
 * created on - 13/08/2019
 * modified on - 13/08/2019
 */

@RestController
@RequestMapping("/core/v1")
public class DistributionsController extends AbstractBaseController{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DistributionsController.class);
	
	@Autowired
	private IDistributionsService distributionsService;
	
	@Autowired
	private INILeadsService niLeadsService;
	
	@GetMapping("/distributions/{filename}")
	public ResponseEntity<List<DistributionsDto>> getDistributions (
			@PathVariable String filename) {
		if (null != filename) {
			LOGGER.info("Get Distribution History");
			return ResponseEntity.ok(distributionsService
					.getDistributionsHistory(filename));			
		}
		return null;
	}
	
	@GetMapping("/job_stats/{adobeFilename}")
	public JobStatsDto getJobStats ( 
			@PathVariable String adobeFilename) {
		return distributionsService.getJobStats(adobeFilename);
		
	} 
	
	@GetMapping("/leads_job_stats/{jobIdName}/{distributionType}")
	public PiiPubSubAttributesDto getNiLeadsJobStats ( 
			@PathVariable String jobIdName,
			@PathVariable String distributionType) {
			
		return niLeadsService.getNiLeadsJobStats(jobIdName, distributionType);
		
	}

}
