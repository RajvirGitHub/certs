/**
 * 
 */
package com.networkedinsights.dto;

import java.util.List;

/**
 * @author rajvirs
 *
 */
public class NiLeadsDto {

	private String destination;
	private String distributionType;
	private String fileName;
	private Integer traitId;
	private Integer quantile;
	private Long timestamp;
	private List<StatesDto> states;
	
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getDistributionType() {
		return distributionType;
	}
	public void setDistributionType(String distributionType) {
		this.distributionType = distributionType;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public Integer getTraitId() {
		return traitId;
	}
	public void setTraitId(Integer traitId) {
		this.traitId = traitId;
	}
	public List<StatesDto> getStates() {
		return states;
	}
	public void setStates(List<StatesDto> states) {
		this.states = states;
	}
	public Integer getQuantile() {
		return quantile;
	}
	public void setQuantile(Integer quantile) {
		this.quantile = quantile;
	}
	public Long getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}
	
}
