/**
 * 
 */
package com.networkedinsights.service;

import java.util.List;

import com.networkedinsights.dto.DistributionsDto;
import com.networkedinsights.dto.ExpandedAudienceDto;

/**
 * @author rajvirs
 *
 */
public interface IExpansionAudienceService {

	/**
	 * This method will help in storing
	 * selected quantile data.
	 * @param fileName
	 * @param qtl
	 * @param records
	 */
	public void storeQntlInfoInDatastore(ExpandedAudienceDto expandedAudienceDto);

	/**
	 * Fetch expanded audience listing
	 * @param traitId
	 * @return
	 */
	public List<ExpandedAudienceDto> fetchExpandedAudienceListing(Integer traitId);

	/**
	 * Distribute expanded audience 
	 * @param destination
	 * @param distributionType
	 * @param filename
	 * @param timestamp
	 * @param qtl
	 */
	public Long distributeExpandedAudienceIds(String destination, 
			String distributionType, String filename, Long timestamp, Integer qtl);

	/**
	 * Get Expanded Audience distribution history
	 * @param fileName
	 * @return
	 */
	public List<DistributionsDto> getDistributionsHistory(Long timestamp);

	/**
	 * Distribute process: Delete and create a table
	 * @param timestamp
	 * @param qtl
	 * @param distTimestamp
	 * @param timeoutTmpstp
	 */
	public Long distributeAndCreateTable(String filename, 
			Integer qtl, Long distTimestamp, Long timeoutTmpstp,
			String distributionType);

	/**
	 * Distribute find count and store in GCS
	 * @param filename
	 * @param qtl
	 * @param distTimestamp
	 * @return
	 */
	public Long distributeFindCountAndStoreInGCS(String filename, 
			Integer qtl, Long distTimestamp, 
			String bqDataset, Long oldTimestamp);

	/**
	 * Distribute find count and store in S3
	 * @param distributionType
	 * @param filename
	 * @param qtl
	 * @param distTimestamp
	 */
	public void distributeFindCountAndStoreInS3(String distributionType, 
			String filename, Integer qtl, Long distTimestamp,
			Long oldTimestamp);

	/**
	 * distribution: Storing in GCS
	 * @param qtl
	 * @param distTimestamp
	 */
	public void distributeStoreInGCS(Integer qtl, Long distTimestamp);

	/**
	 * Expanding Seed list file
	 * @param filename
	 * @param timestamp
	 * @return
	 */
	public Boolean expandingSeedListFile(String filename, Long timestamp);

}
