/**
 * 
 */
package com.networkedinsights.util;

import java.net.URL;

/**
 * @author rajvirs
 *
 */
public class ConstantsUtil {

	/**
	 * Default constructor added to fix Sonar issue
	 */
	private ConstantsUtil() {}
	
	public static final String UPLOADED_FOLDER = "D://tmp//bucket//";
	public static final String FTP_DPM = "ftp_dpm_";
	public static final String FILE_EXTN_SYNC = ".sync";

	public static final String TAB_SEPARATOR = "\t";
	public static final String NEWLINE_SEPARATOR = "\n";

	public static final String BLOBNAME = "NICOM-82_sampleupload.csv";	
	public static final String TABLE_NAME = "social_id_table_";
	public static final String DESTINATION_TABLE = "ni_adobe_uuid_sync_";
	public static final String SOURCEURI = "gs://"; 
	public static final String TOPIC_NAME = "ni-dmp-audience-topic";
	
	// DATASTORE fields
	public static final String TASK = "Task";
	public static final String SEQ_CODE = "SequenceCode";
	public static final String STATUS = "Status";
	public static final String TRAIT_ID = "TraitId";
	public static final String START_TIMESTAMP = "StartTimeStamp";
	public static final String TRAIT_NAME = "TraitName";
	public static final String TRAIT_DESC = "TraitDesc";
	public static final String TTL = "TTL";
	
	public static final String GCS_FILEPATH = "GCSFilePath";	
	public static final String END_TIMESTAMP = "EndTimeStamp";
	public static final String FEEDBACK_MSG = "FeedbackMsg";
	public static final String USERNAME = "Username";
	public static final String INTEGRATION_CODE = "IntegrationCode";
	public static final String INBOUND_CNT = "InboundCnt";
	public static final String INBOUND_AUD_FILENAME = "InboundAudienceFileName";
	public static final String MATCHED_CNT = "MatchedCount";
	public static final String TRAITLIST = "TraitList";
	public static final String CREATED_DATE = "CreatedDate";
	public static final String LAST_REFRESHED = "LastRefreshed";
	public static final String LAST_REFRESHED_TIME = "LastRefreshTime";
	
	public static final String VALIDATEFILE_STATUS = "File Validated successfully with traitId updated in Datastore";
	public static final String LOAD_SOCIALID_TO_FILE_STATUS = "Social Ids uploaded to table";
	public static final String SYNC_ADOBEUUID_SOCIALID_STATUS = "Adobe UUID join with social Id successful";
	public static final String OUTBOUND_FILE_FOR_GCS_STATUS = "Uploaded outbound file in GCS bucket";
	public static final String INTERMEDIATE_FILE_FOR_GCS_STATUS = "Stored Intermediate file in GCS bucket";
	public static final String UPLOAD_INBOUND_FILE_TO_S3_STATUS = "Stored inbound file in S3 bucket";

	public static final Integer START_SEQ_CODE = 1;
	public static final Integer VALIDATEFILE_SEQ_CODE = 2;
	public static final Integer LOAD_SOCIALID_TO_FILE_SEQ_CODE = 3;
	public static final Integer SYNC_ADOBEUUID_SOCIALID_SEQ_CODE = 4;
	public static final Integer OUTBOUND_FILE_FOR_GCS_SEQ_CODE = 5;
	public static final Integer INTERMEDIATE_FILE_FOR_GCS_SEQ_CODE = 6;
	public static final Integer UPLOAD_INBOUND_FILE_TO_S3_SEQ_CODE = 7;
	
	public static final String INVALID_FILE = "ERROR: Incorrect file format. Please upload .csv file";
	public static final String INVALID_TRAITID = "ERROR: Incorrect file format. Invalid length of traitId";
	public static final String INVALID_FILE_MULTIPLE_COLS = "ERROR: Incorrect file format. Contains multiple columns";
	public static final String INVALID_FILE_HEADER = "ERROR: Incorrect file format. Invalid file headers";
	
	public static final String ERROR = "ERROR";
	public static final Integer INVALID_FILE_ERRORCODE = 1001;
	public static final String CSV_EXTN = ".csv";
	public static final String ADOBE_UUID = "adobe_uuid";
	public static final String DATE_LABEL_FOR_FILE = "date=";
	public static final String DATE_FORMAT = "yyyy-MM-dd";
	public static final String DATE_IN_MMDDYY = "MM/dd/yy";
	
	public static final String DATE_IN_YYMMDD_TIME ="yyyy-MM-dd HH:mm:ss.SSSSSS z";
	public static final String UTC ="UTC";
	
	public static final Integer ERROR_VALIDATEFILE_SEQ_CODE = 7;
	public static final String ERROR_VALIDATEFILE_STATUS = "ERROR: Invalid File. Please upload file in valid format";
	public static final String ERROR_LOADSOCIALIDTOFILE_STATUS = "ERROR: While loading social Id's in Big Query table";
	public static final String ERROR_SYNC_ADOBE_SOCIALID_STATUS = "ERROR: While Big Query join between social id and adobe uuid";
	public static final String ERROR_INTERMEDIATEFILE_GCS_STATUS = "ERROR: While uploading file to intermediate GCS bucket";
	public static final String ERROR_UPLOAD_FILE_GCS_STATUS = "ERROR: While uploading outbound file to GCS";
	public static final String ERROR_UPLOAD_FILE_S3_STATUS = "ERROR: While uploading file to S3 bucket";
	
	public static final String SOCIAL_ID_PATTERN = "id:twitter.com:";
	public static final String INCORRECT_FILE_FORMAT = "ERROR: Incorrect file format";
	public static final Integer NO_FILE_FOUND_ERRORCODE = 1003;
	
	public static final String UTF8_ENCODING = "UTF-8";
	public static final long ADD_SECONDS = 3599;
	public static final String INCORRECT_FILE_SOCIAL_ID = "ERROR: Incorrect file format. Incorrect Social id";
	public static final String INCORRECT_FILE_TRAIT_INFO = "ERROR: Incorrect file format. Trait information not present";
	public static final String INCORRECT_FILE_TRAIT_NAME = "ERROR: Incorrect file format. Trait Name should be 0 to 255 characters";
	public static final String INCORRECT_FILE_TRAIT_WITH_SP_CHARS = "ERROR: Incorrect file format. Trait Name should not have special characters";
	
	public static final String AUTHORIZATION_AAM = "Authorization";
	public static final String BEARER_AAM = "Bearer ";
	public static final String BASIC_AAM = "Basic ";
	public static final String FOLDER_ID_AAM = "folderId";
	public static final String TRAIT_NAME_AAM = "name";
	public static final String TRAIT_TYPE_AAM = "traitType";
	public static final String DATASOURCE_ID_AAM = "dataSourceId";
	public static final String INTEGRATION_CODE_AAM = "integrationCode";
	public static final String TTL_AAM = "ttl";
	public static final String DESCRIPTION_AAM = "description";
	public static final String GRANT_TYPE_AAM = "grant_type";
	public static final String USERNAME_AAM = "username";
	public static final String PAWRD_AAM = "password";
	public static final String INCORRECT_TRAIT_NAME = "ERROR: Trait Name containing invalid special chars or name length not between 0 to 255 characters";
	public static final String ERROR_UUID_AUID_MATCH_CNT = "ERROR: Distinct UUID count below minimum threshold, Please upload a larger file.";
	public static final Integer DEFAULT_TTL_VALUE = 120;
	public static final Integer MAX_TTL_LIMIT = 400;
	public static final Integer INVALID_TRAIT_ERRORCODE = 1002;
	public static final Integer TRAITID_NOTFOUND_ERRORCODE = 1004;
	
	public static final String DUPLICATE_FILE = "File with same name already exists in storage";
	public static final String BLANK_SPACE = "";
	
	public static final String IN_PROGRESS_STATUS = "In progress";
	public static final String TRAIT_ENDPOINT = "/traits/";
	public static final String FORWARD_SLASH = "/";
	public static final String TRAITID_NOTFOUND = "TraitId not found in Adobe Audience Manager";
	public static final Object TRAITID_PREFIX = "d_sid=";
	public static final String FILE_UPLOADED = "Uploaded";
	public static final String FILE_PROCESSED = "Processed";
	public static final String FILE_IDS_MATCHED = "Matched";
	public static final String READY_TO_DISTRIBUTE = "Ready to Distribute";
	public static final String FILE_DISTRIBUTED = "Distributed";
	public static final String PROCESSING_COMPLETED = "Completed";
	public static final String DIGIT_PATTERN_REGEX = "\\d+";
	public static final String FILEPATH = "filePath";
	public static final String TIMESTAMP = "timestamp";
	public static final String FILENAME_TEST = "fileName";
	public static final String TRAIT_ID_TEST = "traitId";
	public static final String VERSION_V1 = "/v1";
	
	public static final Boolean BOOLEAN_TRUE = true;
	public static final Boolean BOOLEAN_FALSE = false;
	public static final String TRAITUSERMAP = "TraitUserMapping";
	public static final String CREATED_BY = "CreatedBy";
	public static final String UPDATED_BY = "UpdatedBy";
	public static final String EXPANSION_FLOW = "Expansion";	// CYBG-153 
	public static final String EXPANSION_STATUS = "ExpansionStatus";
	public static final String DELETEDTRAIT = "DeletedTraits";
	public static final String BIGQUERY_DATASET = "bigQueryDataset";
	public static final String GCS_PLOTLOCATION = "gcsPlotLocation";
	public static final String EXPANSION_PENDING = "Expansion pending";
	public static final String BQ_DATASET = "bq_dataset";
	public static final String UPLIFT_URL = "uplift_url";
	public static final String EXP_STATUS = "status";
	public static final String JOB_ID = "job_id";
	public static final String EXP_ERROR = "error";
	public static final String PUBLISH_TIME = "PublishTime";
	public static final String BLANK_BQDATASET = "Big query Dataset not present in Datastore.";
	public static final String POINT = ".";
	public static final String EXP_QTL = "_exp_";
	public static final String NI_INTERMEDIATE = "ni_intermediate_";
	public static final int BQ_DATASET_ERRORCODE = 1005;
	public static final String PARAMETERS = "parameters";
	public static final String OFFLINE_CREATED = "offline";
	public static final Integer ZERO_VAL = 0;
	public static final String DISTRIBUTIONS = "Distributions";
	public static final String DISTRIBUTION_HISTORY = "DistributionHistory";
	public static final String DISTRIBUTION_DATE = "DistributionDate";
	public static final String FILENAME = "Filename";
	public static final String DESTINATION = "Destination";
	public static final String DIST_TIMESTAMP = "distTimestamp";
	public static final String AVAILABLE_STATUS = "Available";
	public static final String PENDING_STATUS = "Pending";
	public static final String EXPANSION_AUDIENCE = "ExpansionAudList";
	public static final String RECORDS = "records";
	public static final String SELECTED_QUANTILE = "qtl";
	public static final String DISTRIBUTION_TYPE = "DistributionType";
	public static final String OVERWRITE_TYPE = "overwrite";
	public static final String APPEND_TYPE = "append";
	public static final String FILE_EXTN_OVERWRITE = ".overwrite";
	public static final String KEY_FACTORY = "Key factory";
	public static final String ISFROM_UI = "UIflow";
	public static final String EXPANDED_AUDIENCE = "ExpandedAudience";
	public static final String EXPANDED_AUD_DIST_HISTORY = "ExpandedAudDistHist";
	public static final String DEST_ADOBE = "adobe";
	public static final String DEST_NI_LEADS = "nileads";
	public static final String NILEADS_TABLE = "ni_leads_";
	public static final String JOBSTATS = "JobStats";
	public static final String DATA_FILENAME = "dataFileName";
	public static final String ID_SYNC_DPID = "idSyncDpid";
	public static final String RECORDS_RCVD = "recordsReceived";
	public static final String RECORDS_SUCCESS = "recordsSuccess";
	public static final String PERCENTAGE_SUCCESS = "percentageSuccess";
	public static final String FAILED_PARSE_CHECK = "failedParseCheck";
	public static final String FAILED_PCS_TIMEOUT_UUID = "failedPCSTimeoutUUIDLookup";
	public static final String FAILED_PCS_TIMEOUT_TRAITS = "failedPCSTimeoutTraitsLookup";
	public static final String FAILED_UUID_LOOKUP = "failedUUIDLookup";
	public static final String FAILED_INVALID_DEMDEX = "failedInvalidDemdexUUID";
	public static final String FAILED_NO_REALIZED_TRAITS = "failedNoRealizedTrait";
	public static final String TOTAL_SIGNALS = "totalSignals";
	public static final String TOTAL_UNUSED_SIGNALS = "totalUnusedSignals";
	public static final String TOTAL_REALIZED_TRAITS = "totalrealizedtraits";
	public static final String TOTAL_REMOVED_TRAITS = "totalRemovedTraits";
	public static final String TOTAL_NEW_TRAITS = "totalNewTraits";
	public static final String PERCENTAGE_USED_SIGNALS = "percentageUsedSignals";
	public static final String STARTTIME = "startTime";
	public static final String ENDTIME = "endTime";
	public static final String SAMPLING_AVAILABLE = "samplingAvailable";
	public static final String TOTAL_INVALID_GLOBAL_DEVICE_IDS = "totalInvalidGlobalDeviceIds";
	public static final String MATCH_TYPE = "match_type";
	public static final String ID = "id";
	public static final String FILE_LOCATION = "file_location";
	public static final String SUCCESS = "Success";
	
	public static final String OUTPUT_BUCKET = "output_bucket";
	public static final String OUTPUT_PREFIX = "output_prefix";
	public static final String CREDITS_REMAINING = "credits_remaining";
	public static final String SPAMTRAP = "spamtrap";
	public static final String CATCH_ALL = "catch_all";
	public static final String ABUSE = "abuse";
	public static final String VALID = "valid";
	public static final String DO_NOT_MAIL = "do_not_mail";
	public static final String INVALID = "invalid";
	public static final String UNKNOWN = "unknown";
	public static final String COUNT_VALID_EMAILS = "count_valid_emails";
	public static final String COUNT_INPUT_RECORDS = "count_input_records";
	public static final String JOB_ID_NAME = "jobIdName";
	
	public static final String OUTPUTBUCKET = "outputBucket";
	public static final String OUTPUTPREFIX = "outputPrefix";
	public static final String CREDITSREMAINING = "creditsRemaining";
	public static final String CATCHALL = "catchAll";
	public static final String DONOT_MAIL = "doNotMail";
	public static final String COUNTVALID_EMAILS = "countValidEmails";
	public static final String COUNTINPUT_RECORDS = "countInputRecords";
	public static final String LEADS_JOB_STATS = "NiLeadsJobStats";
	public static final Integer COMPLETED_CODE = 7;
	public static final String API_TRACK_TIMEOUT_DS = "APITimeoutTrackDS";
	public static final String TIMEOUT_TMPSTMP = "timeoutTmpstp";
	public static final String DIRECT_MAIL = "direct_mail";	
	
	public static final String COMMA_DEL = ",";
	public static final String EMAIL = "email";
	public static final String ALL_MAIL = "all_email";
	public static final String OUTPUTPROJECT = "outputProject";
	public static final String PHONE = "phone";
	public static final String OUTPUT_PROJECT = "output_project";
	public static final String OUTPUTRECORDS = "outputRecords";
	public static final String OUTPUT_RECORDS = "output_records";
	public static final String DNC_REMOVED = "dnc_removed";
	public static final String DNCREMOVED = "dncRemoved";

	
			
	
	public static final String DATE_IN_MMDDYY_TIME_UTC ="MM/dd/yy HH:mm:ss 'UTC'";
	public static final String PROCESSING = "PROCESSING";
	public static final String NOT_PROCESSED = "Not Processed";
	public static final String LEADS_FILE_AVAILABLE = "Leads file available for ";
	public static final String GS_BASEURL = "https://storage.cloud.google.com/";
}
