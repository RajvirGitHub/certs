/**
 * 
 */
package com.networkedinsights.dto;

/**
 * @author rajvirs
 *
 */
public class FileTransferDto {

	private String srcFilePath;
	
	private String destFilePath;
	
	public String getSrcFilePath() {
		return srcFilePath;
	}
	public void setSrcFilePath(String srcFilePath) {
		this.srcFilePath = srcFilePath;
	}
	public String getDestFilePath() {
		return destFilePath;
	}
	public void setDestFilePath(String destFilePath) {
		this.destFilePath = destFilePath;
	}
	
}
