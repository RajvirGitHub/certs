/**
 * 
 */
package com.networkedinsights.service;

import com.networkedinsights.dto.NiLeadsDto;
import com.networkedinsights.dto.PiiPubSubAttributesDto;

/**
 * @author rajvirs
 *
 */
public interface INILeadsService {

	/**
	 * Upload File from seed list platform
	 * to NI leads platform and call POST API
	 * @param niLeadsDto
	 * @return
	 */
	public String processFileToLeadsPlatform(NiLeadsDto niLeadsDto);

	/**
	 * Upload File from Expansion Aud platform
	 * to NI leads platform and call POST API
	 * @param niLeadsDto
	 * @return
	 */
	public String processExpansionFileToLeadsPlatform(NiLeadsDto niLeadsDto);

	/**
	 * Calls POST API which will alert NI Leads that
	 * file has been uploaded successfully
	 * @param niLeadsDto
	 * @param isExpansion
	 * @param jobIdName
	 * @return
	 */
	public Boolean callPostApi(NiLeadsDto niLeadsDto, 
			Boolean isExpansion, String jobIdName);

	/**
	 * Fetch Ni leads job stats data
	 * @param jobIdName
	 * @param distributionType
	 * @return
	 */
	public PiiPubSubAttributesDto getNiLeadsJobStats(String jobIdName,
			String distributionType);

}
