/**
 * 
 */
package com.networkedinsights.dto;

/**
 * @author rajvirs
 * created on - 02/04/2019
 * modified on - 05/07/2019
 */
public class FileDetailsListingDto {

	private String fileName;
	private String status;
	private Integer ingestedRecords;
	private String uploadDate;
	private String uploadedBy;
	private Long timestamp;
	private Boolean expansion;
	private String expansionStatus;
	private Integer quantile;
	
	private Boolean isFromUI;	// Added for CYBG-110
	private Integer distribution;
	
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Integer getIngestedRecords() {
		return ingestedRecords;
	}
	public void setIngestedRecords(Integer ingestedRecords) {
		this.ingestedRecords = ingestedRecords;
	}
	public String getUploadDate() {
		return uploadDate;
	}
	public void setUploadDate(String uploadDate) {
		this.uploadDate = uploadDate;
	}
	public String getUploadedBy() {
		return uploadedBy;
	}
	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}
	public Long getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}
	public Boolean getIsFromUI() {
		return isFromUI;
	}
	public void setIsFromUI(Boolean isFromUI) {
		this.isFromUI = isFromUI;
	}
	public Boolean getExpansion() {
		return expansion;
	}
	public void setExpansion(Boolean expansion) {
		this.expansion = expansion;
	}
	public Integer getQuantile() {
		return quantile;
	}
	public void setQuantile(Integer quantile) {
		this.quantile = quantile;
	}
	public String getExpansionStatus() {
		return expansionStatus;
	}
	public void setExpansionStatus(String expansionStatus) {
		this.expansionStatus = expansionStatus;
	}
	public Integer getDistribution() {
		return distribution;
	}
	public void setDistribution(Integer distribution) {
		this.distribution = distribution;
	}
	
}
