/**
 *
 */
package com.networkedinsights.controller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.networkedinsights.dto.ResponseExceptionDto;
import com.networkedinsights.exception.BQDatasetException;
import com.networkedinsights.exception.DuplicateFileFoundException;
import com.networkedinsights.exception.InvalidFileException;
import com.networkedinsights.exception.InvalidTraitNameException;
import com.networkedinsights.exception.NIDmpException;
import com.networkedinsights.exception.TraitIdNotFoundException;
import com.networkedinsights.util.ConstantsUtil;

/**
 * @author rajvirs
 * created on - 13/02/2018
 * modified on - 01/03/2018
 */
public class AbstractBaseController {

	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractBaseController.class);

	@ExceptionHandler(NIDmpException.class)
	public ResponseEntity<ResponseExceptionDto> handleException(
			HttpServletRequest request, NIDmpException e) {
		ResponseExceptionDto responseExceptionDto = new ResponseExceptionDto();
		responseExceptionDto.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		responseExceptionDto.setErrorMessage(e.getCause().getMessage());
		LOGGER.error(ConstantsUtil.ERROR, e);
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body(responseExceptionDto);
	}

	@ExceptionHandler(InvalidFileException.class)
	public ResponseEntity<ResponseExceptionDto> handleException(
			HttpServletRequest request, InvalidFileException e) {
		ResponseExceptionDto responseExceptionDto = new ResponseExceptionDto();
		responseExceptionDto.setErrorCode(ConstantsUtil.INVALID_FILE_ERRORCODE);
		responseExceptionDto.setErrorMessage(e.getMessage());
		LOGGER.error(ConstantsUtil.ERROR, e);
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body(responseExceptionDto);
	}
	
	@ExceptionHandler(DuplicateFileFoundException.class)
	public ResponseEntity<ResponseExceptionDto> handleException(
			HttpServletRequest request, DuplicateFileFoundException e) {
		ResponseExceptionDto responseExceptionDto = new ResponseExceptionDto();
		responseExceptionDto.setErrorCode(ConstantsUtil.NO_FILE_FOUND_ERRORCODE);
		responseExceptionDto.setErrorMessage(e.getMessage());
		LOGGER.error(ConstantsUtil.ERROR, e);
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body(responseExceptionDto);
	}
	
	@ExceptionHandler(InvalidTraitNameException.class)
	public ResponseEntity<ResponseExceptionDto> handleException(
			HttpServletRequest request, InvalidTraitNameException e) {
		ResponseExceptionDto responseExceptionDto = new ResponseExceptionDto();
		responseExceptionDto.setErrorCode(ConstantsUtil.INVALID_TRAIT_ERRORCODE);
		responseExceptionDto.setErrorMessage(e.getMessage());
		LOGGER.error(ConstantsUtil.ERROR, e);
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body(responseExceptionDto);
	}
	
	@ExceptionHandler(TraitIdNotFoundException.class)
	public ResponseEntity<ResponseExceptionDto> handleException(
			HttpServletRequest request, TraitIdNotFoundException e) {
		ResponseExceptionDto responseExceptionDto = new ResponseExceptionDto();
		responseExceptionDto.setErrorCode(ConstantsUtil.TRAITID_NOTFOUND_ERRORCODE);
		responseExceptionDto.setErrorMessage(e.getMessage());
		LOGGER.error(ConstantsUtil.ERROR, e);
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body(responseExceptionDto);
	}
	
	@ExceptionHandler(BQDatasetException.class)
	public ResponseEntity<ResponseExceptionDto> handleException(
			HttpServletRequest request, BQDatasetException e) {
		ResponseExceptionDto responseExceptionDto = new ResponseExceptionDto();
		responseExceptionDto.setErrorCode(ConstantsUtil.BQ_DATASET_ERRORCODE);
		responseExceptionDto.setErrorMessage(e.getMessage());
		LOGGER.error(ConstantsUtil.ERROR, e);
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body(responseExceptionDto);
	}
}
