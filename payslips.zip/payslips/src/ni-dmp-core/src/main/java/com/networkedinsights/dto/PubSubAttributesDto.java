/**
 * 
 */
package com.networkedinsights.dto;

/**
 * @author rajvirs
 *
 */
public class PubSubAttributesDto {
	
	private String jobId;
	private String status;
	private String bqDataset;
	private String upliftPlotLoc;
	private String error;
	
	public String getJobId() {
		return jobId;
	}
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getBqDataset() {
		return bqDataset;
	}
	public void setBqDataset(String bqDataset) {
		this.bqDataset = bqDataset;
	}
	public String getUpliftPlotLoc() {
		return upliftPlotLoc;
	}
	public void setUpliftPlotLoc(String upliftPlotLoc) {
		this.upliftPlotLoc = upliftPlotLoc;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	
}
