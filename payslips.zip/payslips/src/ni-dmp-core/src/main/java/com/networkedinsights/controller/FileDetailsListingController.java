/**
 * 
 */
package com.networkedinsights.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.networkedinsights.dto.FileDetailsListingDto;
import com.networkedinsights.service.IFileDetailsListingService;

/**
 * @author rajvirs
 * created on - 02/04/2019
 * modified on - 02/04/2019
 *
 */
@RestController
@RequestMapping("/core/v1")
public class FileDetailsListingController extends AbstractBaseController {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(FileDetailsListingController.class);
	
	@Autowired
	private IFileDetailsListingService fileDetailsListingService;

	/**
	 * Fetch file detailList for specified traitId
	 * @param traitId
	 * @return
	 */
	@GetMapping("/file_details/trait/{traitId}")
	public ResponseEntity<List<FileDetailsListingDto>> fileDetailsListing(
			@PathVariable Integer traitId) {
		return ResponseEntity.ok(fileDetailsListingService.fileDetailsListing(traitId));
	}
}
