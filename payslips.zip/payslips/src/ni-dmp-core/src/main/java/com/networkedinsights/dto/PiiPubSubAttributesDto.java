/**
 * 
 */
package com.networkedinsights.dto;

/**
 * @author rajvirs
 *
 */
public class PiiPubSubAttributesDto {

	private String status;
	private String jobId;
	private String outputBucket;
	private String outputPrefix;
	private String creditsRemaining;
	private String spamtrap;
	private String catchAll;
	private String abuse;
	private String valid;
	private String doNotMail;
	private String invalid;
	private String unknown;
	private String countValidEmails;
	private String countInputRecords;
	private String outputProject;
	private String outputRecords;
	private String dncRemoved;
	
	
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getJobId() {
		return jobId;
	}
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	public String getOutputBucket() {
		return outputBucket;
	}
	public void setOutputBucket(String outputBucket) {
		this.outputBucket = outputBucket;
	}
	public String getOutputPrefix() {
		return outputPrefix;
	}
	public void setOutputPrefix(String outputPrefix) {
		this.outputPrefix = outputPrefix;
	}
	public String getCreditsRemaining() {
		return creditsRemaining;
	}
	public void setCreditsRemaining(String creditsRemaining) {
		this.creditsRemaining = creditsRemaining;
	}
	public String getSpamtrap() {
		return spamtrap;
	}
	public void setSpamtrap(String spamtrap) {
		this.spamtrap = spamtrap;
	}
	public String getCatchAll() {
		return catchAll;
	}
	public void setCatchAll(String catchAll) {
		this.catchAll = catchAll;
	}
	public String getAbuse() {
		return abuse;
	}
	public void setAbuse(String abuse) {
		this.abuse = abuse;
	}
	public String getValid() {
		return valid;
	}
	public void setValid(String valid) {
		this.valid = valid;
	}
	public String getDoNotMail() {
		return doNotMail;
	}
	public void setDoNotMail(String doNotMail) {
		this.doNotMail = doNotMail;
	}
	public String getInvalid() {
		return invalid;
	}
	public void setInvalid(String invalid) {
		this.invalid = invalid;
	}
	public String getUnknown() {
		return unknown;
	}
	public void setUnknown(String unknown) {
		this.unknown = unknown;
	}
	public String getCountValidEmails() {
		return countValidEmails;
	}
	public void setCountValidEmails(String countValidEmails) {
		this.countValidEmails = countValidEmails;
	}
	public String getCountInputRecords() {
		return countInputRecords;
	}
	public void setCountInputRecords(String countInputRecords) {
		this.countInputRecords = countInputRecords;
	}
	public String getOutputProject() {
		return outputProject;
	}
	public void setOutputProject(String outputProject) {
		this.outputProject = outputProject;
	}
	public String getOutputRecords() {
		return outputRecords;
	}
	public void setOutputRecords(String outputRecords) {
		this.outputRecords = outputRecords;
	}
	public String getDncRemoved() {
		return dncRemoved;
	}
	public void setDncRemoved(String dncRemoved) {
		this.dncRemoved = dncRemoved;
	}
	
}
