/**
 * 
 */
package com.networkedinsights.dto;

/**
 * @author rajvirs
 *
 */
public class ExpandedAudienceDto {

	private String fileName;
	private String status;
	private String records;
	private String createdDate;
	private Integer quantile;
	private Integer distributions;
	private String traitId;
	private Long timestamp;
	
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRecords() {
		return records;
	}
	public void setRecords(String records) {
		this.records = records;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getQuantile() {
		return quantile;
	}
	public void setQuantile(Integer quantile) {
		this.quantile = quantile;
	}
	public Integer getDistributions() {
		return distributions;
	}
	public void setDistributions(Integer distributions) {
		this.distributions = distributions;
	}
	public String getTraitId() {
		return traitId;
	}
	public void setTraitId(String traitId) {
		this.traitId = traitId;
	}
	public Long getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}
	
}
