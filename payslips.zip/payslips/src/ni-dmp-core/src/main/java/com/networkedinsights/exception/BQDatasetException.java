/**
 * 
 */
package com.networkedinsights.exception;

/**
 * @author rajvirs
 *
 */
public class BQDatasetException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1538717072293827817L;

	public BQDatasetException(String string) {
		super(string);
	}

}
