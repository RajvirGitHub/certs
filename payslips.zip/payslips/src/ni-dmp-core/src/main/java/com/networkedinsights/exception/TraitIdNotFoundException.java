/**
 * 
 */
package com.networkedinsights.exception;

/**
 * @author rajvirs
 * created on - 26/03/2018
 * modified on - 26/03/2018
 *
 */
public class TraitIdNotFoundException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1213328811329305610L;

	public TraitIdNotFoundException(String string) {
		super(string);
	}
}
