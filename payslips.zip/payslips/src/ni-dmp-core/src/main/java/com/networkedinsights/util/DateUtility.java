/**
 * 
 */
package com.networkedinsights.util;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.TimeZone;






/**
 * @author rajvirs
 *
 */
public class DateUtility {

	/**
	 * Converts current time to Date String
	 * @return
	 */
	public static String getFormattedDateString() {

		LocalDate date = LocalDate.now(); 
		DateTimeFormatter newPattern = DateTimeFormatter.ofPattern(ConstantsUtil.DATE_FORMAT);

		return date.format(newPattern);
	}

	/**
	 * Convert time to Date String using DateTimeFormatter
	 * @param dateInMillis
	 * @return
	 */
	public static String getFormattedDateString(Long dateInMillis) {

		LocalDate date =
				Instant.ofEpochMilli(dateInMillis).atZone(ZoneId.systemDefault()).toLocalDate();
		DateTimeFormatter newPattern = DateTimeFormatter.ofPattern(ConstantsUtil.DATE_IN_MMDDYY);

		return date.format(newPattern);
	}

	/**
	 *  Convert time to Date String using SimpleDateFormat
	 * @param dateInMillis
	 * @return
	 */
	public static String getFormattedDateStringUtc(Long dateInMillis) {

		SimpleDateFormat sdf = new SimpleDateFormat(ConstantsUtil.DATE_IN_MMDDYY_TIME_UTC);
		sdf.setTimeZone(TimeZone.getTimeZone(ConstantsUtil.UTC));
		return  sdf.format(dateInMillis);

	}
	
	/**
	 * Default constructor added to fix Sonar issue
	 */
	private DateUtility(){

	}
}
