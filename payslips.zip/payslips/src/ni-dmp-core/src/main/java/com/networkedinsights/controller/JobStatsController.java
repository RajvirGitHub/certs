/**
 * 
 */
package com.networkedinsights.controller;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.networkedinsights.service.IJobStatsService;
import com.networkedinsights.service.INILeadsService;

/**
 * @author rajvirs
 *
 */
@RestController
public class JobStatsController extends AbstractBaseController {
	
	@Autowired
	private INILeadsService niLeadsServiceImpl;
	
	@Autowired
	private IJobStatsService jobStatsServiceImpl;
	
	@GetMapping(value="/testing_purpose/{id}")
	public int testingTimeout(@PathVariable int id) throws InterruptedException {
		
		System.out.println("Job stats:"+1573630200026l);
		jobStatsServiceImpl.storeJobStats(1573630200026l);
		System.out.println("Testing with id"+id);
		niLeadsServiceImpl.callPostApi(null, false, null);
		
		System.out.println("Math.random"+Math.random());
		
		Thread.sleep(40000);
		Random rand = new Random(); 
		  
        // Generate random integers in range 0 to 999 
        int rand_int1 = rand.nextInt(1000); 
		System.out.println("After sleep"+rand_int1);
		
		return id;
		
	}

}
