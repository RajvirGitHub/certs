/**
 * 
 */
package com.networkedinsights.service;

import java.util.List;

import com.networkedinsights.dto.DistributionsDto;
import com.networkedinsights.dto.JobStatsDto;

/**
 * @author rajvirs
 * created on - 13/08/2019
 * modified on - 13/08/2019
 */
public interface IDistributionsService {

	/**
	 * This method will get DistributionsHistory for a 
	 * particular filename
	 * @param filename
	 * @return
	 */
	public List<DistributionsDto> getDistributionsHistory(String filename);

	/**
	 * This method will get JobStats for a particular
	 * filename
	 * @param adobeFilename
	 * @return
	 */
	public JobStatsDto getJobStats(String adobeFilename);

}
