/**
 * 
 */
package com.networkedinsights.dto;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.google.gson.annotations.SerializedName;

/**
 * @author rajvirs
 * created on - 21/02/2019
 * modified on - 21/02/2019
 */
// Made this class as a singleton bean in order to 
// access Adobe and AWS secrets and access keys.
@Scope(value = "singleton")
@Component
public class AamAwsSecretsDto {
	
	@SerializedName("aam_username")
	private String aamUsername; 		
	@SerializedName("aam_password")
	private String aamPassword;			
	@SerializedName("aam_auth_secretkey")
	private String aamAuthSecretkey; 	
	@SerializedName("aam_auth_clientId")
	private String aamAuthClientId;		
	@SerializedName("aws_access_keyid")
	private String awsAccessKeyid;		
	@SerializedName("aws_secret_accesskey")
	private String awsSecretAccesskey;	
	
	public String getAamUsername() {
		return aamUsername;
	}
	public void setAamUsername(String aamUsername) {
		this.aamUsername = aamUsername;
	}
	public String getAamPassword() {
		return aamPassword;
	}
	public void setAamPassword(String aamPassword) {
		this.aamPassword = aamPassword;
	}
	public String getAamAuthSecretkey() {
		return aamAuthSecretkey;
	}
	public void setAamAuthSecretkey(String aamAuthSecretkey) {
		this.aamAuthSecretkey = aamAuthSecretkey;
	}
	public String getAamAuthClientId() {
		return aamAuthClientId;
	}
	public void setAamAuthClientId(String aamAuthClientId) {
		this.aamAuthClientId = aamAuthClientId;
	}
	public String getAwsAccessKeyid() {
		return awsAccessKeyid;
	}
	public void setAwsAccessKeyid(String awsAccessKeyid) {
		this.awsAccessKeyid = awsAccessKeyid;
	}
	public String getAwsSecretAccesskey() {
		return awsSecretAccesskey;
	}
	public void setAwsSecretAccesskey(String awsSecretAccesskey) {
		this.awsSecretAccesskey = awsSecretAccesskey;
	}

}
