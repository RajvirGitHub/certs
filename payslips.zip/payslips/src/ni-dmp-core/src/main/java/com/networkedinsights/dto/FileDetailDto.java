/**
 * 
 */
package com.networkedinsights.dto;

/**
 * @author rajvirs
 * created on - 21/01/2018
 * modified on - 22/01/2018
 *
 */
public class FileDetailDto {

	private String filePath;
	private Long timestamp;
	
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public Long getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}
	
}
