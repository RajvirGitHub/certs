package com.networkedinsights.config;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.BigQueryOptions;
import com.google.cloud.datastore.Datastore;
import com.google.cloud.datastore.DatastoreOptions;
import com.google.gson.Gson;
import com.networkedinsights.dto.AamAwsSecretsDto;
/**
 * @author rajvirs
 * created on - 07/02/2018
 * modified on - 13/03/2018
 */ 
@Configuration

public class S3Config {
	private static final Logger LOGGER = LoggerFactory.getLogger(S3Config.class);

    @Value("${aws.region}")
	private String regionName;
    
    @Value("${secrets.file.path}")
	private String secretsFilePath;    
    
	@Autowired
	private AamAwsSecretsDto aamAwsSecretsDto;
	
	@Bean
	public BigQuery bigQuery() {
		LOGGER.info(" BigQuery initialization called ");
		return BigQueryOptions.getDefaultInstance().getService();
	}
	
	@Bean
	public RestTemplate resttemplate(RestTemplateBuilder builder) {
		return builder.build();
	}
	
	@Bean
	public Datastore datastore() {
		LOGGER.info(" Datastore initialization called ");
		return DatastoreOptions.getDefaultInstance().getService();
	}
	
	/**
	 * Setting secret, username, pwd etc required for AAM and S3 authentication.
	 * @return
	 * @throws IOException
	 */
	@Bean("secretDto")
	//@Primary
	public AamAwsSecretsDto secretDto() throws IOException{
		LOGGER.info("SecretDto initialization called");
		if(null != secretsFilePath) {
			File file = new File(secretsFilePath);
			try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
				LOGGER.info("Reading the File");
				StringBuilder json = new StringBuilder("");
				String line = null;
				while((line = reader.readLine()) != null){
					json.append(line);
				}
				aamAwsSecretsDto = new Gson().fromJson(json.toString(), AamAwsSecretsDto.class);
				LOGGER.info("SecretDto object populated ");
			} catch(Exception e) {
				LOGGER.error(
					"S3Config.secretDto():{}, Error MEssage: {}", e);
			}

		}
		return aamAwsSecretsDto;
	}
	
	@Bean
	@DependsOn("secretDto")
	public AmazonS3 s3client() {
		
		LOGGER.info("S3client initialization called ");

		BasicAWSCredentials awsCredentials = new BasicAWSCredentials(aamAwsSecretsDto.getAwsAccessKeyid(), 
				aamAwsSecretsDto.getAwsSecretAccesskey());
		return AmazonS3ClientBuilder.standard()
				.withRegion(Regions.fromName(regionName))
                .withCredentials(new AWSStaticCredentialsProvider(awsCredentials))
                .build();
	}
	
}