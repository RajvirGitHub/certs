/**
 * 
 */
package com.networkedinsights.service.impl;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.services.s3.internal.Constants;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.ReadChannel;
import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.BigQueryOptions;
import com.google.cloud.bigquery.ExtractJobConfiguration;
import com.google.cloud.bigquery.Job;
import com.google.cloud.bigquery.JobId;
import com.google.cloud.bigquery.JobInfo;
import com.google.cloud.bigquery.QueryJobConfiguration;
import com.google.cloud.bigquery.Table;
import com.google.cloud.bigquery.TableId;
import com.google.cloud.bigquery.TableResult;
import com.google.cloud.datastore.Datastore;
import com.google.cloud.datastore.Entity;
import com.google.cloud.datastore.Key;
import com.google.cloud.datastore.KeyFactory;
import com.google.cloud.datastore.Query;
import com.google.cloud.datastore.QueryResults;
import com.google.cloud.datastore.StructuredQuery.PropertyFilter;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.Storage.CopyRequest;
import com.google.cloud.storage.StorageOptions;
import com.networkedinsights.dto.NiLeadsDto;
import com.networkedinsights.dto.PiiPubSubAttributesDto;
import com.networkedinsights.exception.NIDmpException;
import com.networkedinsights.service.INILeadsService;
import com.networkedinsights.util.ConstantsUtil;
import com.networkedinsights.util.DateUtility;

/**
 * @author rajvirs
 *
 */
@Service
public class NILeadsServiceImpl implements INILeadsService{
	private static final Logger LOGGER = LoggerFactory.getLogger(NILeadsServiceImpl.class); 

	@Value("${project.name}")
	private String projectName;

	@Value("${bucketname.inbound.ui}")
	private String bucketnameInboundUi;
	
	@Value("${pathto.credkey.airflow}")
	private String pathToJsonKey;

	@Value("${gcsDataset.name}")
	private String datasetName;
	
	@Value("${pii.matcher.bucket.dev}")
	private String piiMatcherBucketDev;
	
	@Value("${pii.matcher.bucket.prod}")
	private String piiMatcherBucketProd;
	
	@Value("${pii.matcher.post.api}")
	private String piiMatcherPostApiUrl;
	
	@Value("${pii.matcher.post.apiprod}")
	private String piiMatcherPostProdApiUrl;
	
	// Code changes for CYBG 323 | Hardcode exclude parameters for PII Matcher
	@Value("${pii.matcher.exclude}")
	private Boolean piiMatcherExclude;
	
	@Value("${remove.intl.domains}")
	private Boolean removeIntlDomains;
	
	@Value("${remove.edu.domains}")
	private Boolean removeEduDomains;

	@Autowired
	private BigQuery bigQuery;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private Datastore datastore;

	@Override
	public String processFileToLeadsPlatform(NiLeadsDto niLeadsDto) {
		////////
		// Upload file to the new bucket

		String name = niLeadsDto.getFileName();
		//String fileName = niLeadsDto.getFileName();	//Commented
		String fileName = name.substring(0, name.length()-4) + "_"
				+ Instant.now().toEpochMilli() + ConstantsUtil.CSV_EXTN;	// Added timestamp to make jobid unique for all distributions
		try {
			Storage storageObj = getStorageObj();
			BlobId blobId = null;
			String piiBucket = null;
			if(projectName.contains("prod")) {
				piiBucket = piiMatcherBucketProd;
			} else {
				piiBucket = piiMatcherBucketDev;
			}

			LOGGER.info("BUCKET name:{}", bucketnameInboundUi);
			String jobIdNameLoc = fileName.substring(0, fileName.length()-4);
			LOGGER.info("jobIdNameLocal:{}", jobIdNameLoc);
			updateDistributionHistory(niLeadsDto, jobIdNameLoc);

			blobId = BlobId.of(piiBucket, fileName);
			String blobName = niLeadsDto.getFileName();
			Storage storage = StorageOptions.getDefaultInstance().getService();
			LOGGER.info("storage obj formed");
			try (ReadChannel reader = storage.reader(bucketnameInboundUi, blobName)) {

				LOGGER.info("ReadChannel reader");
				StringBuilder sb = readFileInChunks(reader);

				LOGGER.info("Reading file in stringbuffer");
				uploadSmallBlob(storageObj, sb.toString(), 
						 blobId);
				LOGGER.info("Uploaded blob and flag set");
			}

			LOGGER.info("Test: File Uploaded to bucket:");

		} catch (Exception e) {
			LOGGER.error("NILeadsServiceImpl.processFileToLeadsPlatform {}", e.getMessage());
			throw new NIDmpException(
					"NILeadsServiceImpl.processFileToLeadsPlatform(): {} , Error MEssage: {}", e);
		}

		return fileName;
	}
	
	public Blob copyBlob(Storage storageObj, String srcBucket, 
			String destBucket, String blobName) {
		// [START copyBlob]
		LOGGER.info("copyBlob called");
		CopyRequest request =
				CopyRequest.newBuilder()
				.setSource(BlobId.of(srcBucket, blobName))
				.setTarget(BlobId.of(destBucket, blobName))
				.build();
		LOGGER.info("copyBlob request");
		Blob blob = storageObj.copy(request).getResult();
		LOGGER.info("copyBlob file copied");
		// [END copyBlob]
		return blob;
	}
	
	/**
	 * @return
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	private Storage getStorageObj() throws IOException {
		LOGGER.info("getStorageObj called");
		StorageOptions options = StorageOptions.newBuilder()
				.setProjectId(projectName)
				.setCredentials(GoogleCredentials.fromStream(
						new FileInputStream(pathToJsonKey))).build();
		LOGGER.info("StorageOptions: {}", options.getProjectId());
		return options.getService();
	}
	
	/** Read file and appends in StringBuilder object
	 * @param reader
	 * @return
	 * @throws IOException
	 */
	private StringBuilder readFileInChunks(ReadChannel reader) throws IOException {

		LOGGER.info("Reading File");
		ByteBuffer byteBuffer = ByteBuffer.allocate(512 * 1024);

		StringBuilder sb = new StringBuilder(ConstantsUtil.BLANK_SPACE);
		while (reader.read(byteBuffer) > 0) {
			byteBuffer.flip(); 	//flip is used to prepare a buffer for get operation and makes it ready
			//rewind is used to read again the data it already contains. rewind sets the buffer position to zero

			Charset charset = Charset.forName("US-ASCII");
			CharBuffer charBuffer = charset.decode(byteBuffer);

			sb.append(charBuffer);

			byteBuffer.clear(); 
		}
		return sb;
	}
	
	/**
	 * Uploads file to intermediate bucket
	 * @param data
	 * @param bucketName
	 * @param timestamp
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	private String uploadSmallBlob(Storage storage, String data, 
			BlobId blobId) throws UnsupportedEncodingException
	{
		
		BlobInfo blobInfo = BlobInfo.newBuilder(blobId).setContentType("application/octet-stream").build();
		LOGGER.info("Test: blobInfo: {}", blobInfo);	
		ByteArrayInputStream inputStream = new ByteArrayInputStream(
				data.getBytes(Constants.DEFAULT_ENCODING));
		LOGGER.info("inputStream obj created");
		storage.create(blobInfo, inputStream);
		
		LOGGER.info("File uploaded to PII bucket");
		return "blob added";
	}

	@Override
	public String processExpansionFileToLeadsPlatform(NiLeadsDto niLeadsDto) {
		String bqDataset = null;
		try {
			
			String name = niLeadsDto.getFileName();
			String filename = name.substring(0, name.length()-4) + "_"
					+ Instant.now().toEpochMilli() + ConstantsUtil.CSV_EXTN;
			
			String jobIdNameLoc = filename.substring(0, filename.length()-4);
			LOGGER.info("jobIdNameLocal:{}", jobIdNameLoc);
			long distNo = updateExpansionDistributionHistory(niLeadsDto, jobIdNameLoc);
			// Update distribution no in Exp Aud listing
			updateExpAudienceListing(niLeadsDto.getTimestamp(), distNo);
			
			// Fetch bqDataset
			QueryResults<Entity> queryResult = fetchByFilename(niLeadsDto.getFileName());
			bqDataset = fetchBqDataset(queryResult, bqDataset);
			Long startTimestamp = fetchStartTimestamp(
					queryResult);
			LOGGER.info("startTimestamp: {}",startTimestamp);
			// This method will copy data to a new table
			deleteExistingTable(niLeadsDto.getTimestamp());
			LOGGER.info("before creating options");
			BigQueryOptions options = BigQueryOptions.newBuilder()
					.setProjectId(projectName)
					.setCredentials(GoogleCredentials.fromStream(
							new FileInputStream(pathToJsonKey)))
					.build();
			LOGGER.info("after options");
			BigQuery bigQuery2 = options.getService();
			
			String query = "SELECT DISTINCT "
					+ "twitter_id "
					+ "FROM "
					+ "`"+bqDataset+"` as results "
					+ "WHERE "
					+ "results.qtl <= "	+ niLeadsDto.getQuantile()
					+ ";";
			LOGGER.info("Before runCopyJoinQueryData");
			runCopyJoinQueryData(query, niLeadsDto.getTimestamp(), bigQuery2);
			LOGGER.info("After runCopyJoinQueryData");

			LOGGER.info("Before getTable");
			Table niLeadsTable = bigQuery.getTable(datasetName, 
					ConstantsUtil.NILEADS_TABLE +niLeadsDto.getTimestamp());

			LOGGER.info("After getTable");
			
			putResultinGCS2(niLeadsTable, filename, bigQuery2);
			LOGGER.info("After putResultinGCS2");
			return filename;
		} catch (Exception e) {
			LOGGER.error("NILeadsServiceImpl.processExpansionFileToLeadsPlatform {}", e.getMessage());
			throw new NIDmpException(
					"NILeadsServiceImpl.processExpansionFileToLeadsPlatform(): {} , Error MEssage: {}", e);
		}
		
	}

	/**
	 * Fetch bigquery Dataset from datastore
	 * @param niLeadsDto
	 * @param bqDataset
	 * @return
	 */
	private String fetchBqDataset(QueryResults<Entity> queryResult, 
			String bqDataset) {
		
		if (queryResult.hasNext()) {
			Entity entity = queryResult.next();
			
			if (entity.contains(ConstantsUtil.BIGQUERY_DATASET) && 
					null != entity.getString(ConstantsUtil.BIGQUERY_DATASET)) {
				bqDataset = entity.getString(ConstantsUtil.BIGQUERY_DATASET);
			}
		}
		return bqDataset;
	}
	
	/**
	 * Fetch startTimestamp from datastore
	 * @param niLeadsDto
	 * @param bqDataset
	 * @return
	 */
	private Long fetchStartTimestamp(QueryResults<Entity> queryResult) {
		
		if (queryResult.hasNext()) {
			Entity entity = queryResult.next();
			
			if (entity.contains(ConstantsUtil.START_TIMESTAMP)) {
				return entity.getLong(ConstantsUtil.START_TIMESTAMP);
			}
		}
		return null;
	}
	
	/**
	 * Fetch Result by filename i.e. GCS_FILEPATH
	 * @param filename
	 * @return
	 */
	private QueryResults<Entity> fetchByFilename(String filename) {
		// Build the Query
		if(null != filename && filename.contains(ConstantsUtil.CSV_EXTN)) {
			filename = bucketnameInboundUi + ConstantsUtil.FORWARD_SLASH 
					+ filename;
		} else {
			filename = bucketnameInboundUi + ConstantsUtil.FORWARD_SLASH 
					+ filename + ConstantsUtil.CSV_EXTN;
		}
		Query<Entity> query = Query.newEntityQueryBuilder()
				.setKind(ConstantsUtil.TASK)    //specify the task name - here it is 'Task'                                 
				.setFilter(PropertyFilter.eq(ConstantsUtil.GCS_FILEPATH, filename))  //where clause - first parameter should match the column name in datastore.
				.build();
		return datastore.run(query);
	}
	
	/**
	 * To Delete existing table
	 * @param oldTimestamp
	 */
	private void deleteExistingTable(Long timestamp) {
		// ADDED CODE TO Delete existing table | START
		TableId tableId = TableId.of(datasetName,
				ConstantsUtil.NILEADS_TABLE +timestamp);
		boolean deleted = bigQuery.delete(tableId);
		if(deleted) {
			LOGGER.info("Deleted the table");
		} else {
			LOGGER.info("Table not present");
		}
		// ADDED CODE TO Delete existing table | END
	}
	
	/**
	 * Run join query and copy the result in a new table
	 * @param query
	 */
	private TableResult runCopyJoinQueryData(String query, Long
			timestamp, BigQuery bigQuery2) throws InterruptedException
	{
		LOGGER.info("Run join query and copy the result in a new table");
		QueryJobConfiguration queryConfig = QueryJobConfiguration.newBuilder(query)
				// Save the results of the query to a permanent table.
				.setDestinationTable(TableId.of(datasetName, 
						ConstantsUtil.NILEADS_TABLE+timestamp))
				.setUseLegacySql(false)
				.build();
		LOGGER.info("After queryConfig");
		JobId jobId = JobId.of(UUID.randomUUID().toString());
		LOGGER.info("After jobid");
		Job queryJob = bigQuery2.create(JobInfo.newBuilder(queryConfig).setJobId(jobId).build());
		LOGGER.info("During queryJob");
		queryJob = queryJob.waitFor();
		return queryJob.getQueryResults();
	}

	/**
	 * Put the Join Query Result in a CSV file and load this file to GCS bucket
	 * @param table
	 * @throws InterruptedException 
	 */
	private void putResultinGCS2(Table table, String fileName, 
			BigQuery bigQuery2) throws InterruptedException
	{
		String bucketUrl = null;
		if(projectName.contains("prod")) {
			bucketUrl = ConstantsUtil.SOURCEURI
					+ piiMatcherBucketProd + "/"+fileName;
		} else {
			bucketUrl = ConstantsUtil.SOURCEURI
					+ piiMatcherBucketDev + "/"+fileName;
		}
		

		LOGGER.info("bucketUrl :{}", bucketUrl);
		LOGGER.info("Table tableId: {}", table.getTableId());

		ExtractJobConfiguration extractConfiguration = ExtractJobConfiguration
				.newBuilder(table.getTableId(), bucketUrl)
				.setPrintHeader(false)
				.setFieldDelimiter("\t")
				//.setFormat("NEWLINE_DELIMITED_JSON") //By default it is CSV so commenting
				.build();
		LOGGER.info("extractConfiguration");
		Job job = bigQuery2.create(JobInfo.of(extractConfiguration));
		LOGGER.info("startedJob");
		// Wait for the job to complete
		while(!job.isDone()){
			LOGGER.info("Waiting for job to complete");
			Thread.sleep(1000L);
		}
		if (job.getStatus().getError() == null) {
			LOGGER.info("Query Result Exported Successfully to GCS");
		} 
		else {
			LOGGER.info("Query Result Not Exported to GCS");
		}

	}

	@Override
	public Boolean callPostApi(NiLeadsDto niLeadsDto, 
			Boolean isExpansion, String jobIdName) {
		
		try {
			LOGGER.info("set HttpHeader for POST API");
			HttpHeaders headers = setHttpHeaderForRestCall();
			
			String bucket = null;
			String piiMatcherUrl = null;
			if(projectName.contains("prod")) {
				bucket = piiMatcherBucketProd;
				piiMatcherUrl = piiMatcherPostProdApiUrl;
			} else {
				bucket = piiMatcherBucketDev;
				piiMatcherUrl = piiMatcherPostApiUrl;
			}
			
			Map<String, String> fileLocMap = new HashMap<>();
			fileLocMap.put("bucket", bucket);
			fileLocMap.put("prefix", jobIdName);
			
			List<Map<String, String>> includeMapList = new ArrayList<>();
			
			if (!CollectionUtils.isEmpty(niLeadsDto.getStates())) {
				niLeadsDto.getStates().forEach(obj -> {
					Map<String, String> includeMap = new HashMap<>();
					includeMap.put("state", obj.getAbbreviation());
					includeMapList.add(includeMap);
				});
			}
			
			Map<String, Object> map = new HashMap<>();
			map.put(ConstantsUtil.ID, jobIdName.substring(0, jobIdName.length()-4));
			map.put(ConstantsUtil.MATCH_TYPE, niLeadsDto.getDistributionType());
			map.put(ConstantsUtil.FILE_LOCATION, fileLocMap);
			
			Map<String, Object> filterMap = new HashMap<>();
			filterMap.put("include", includeMapList);
			
			
		//	map.put("include", includeMapList);
			
			// Code changes for CYBG 323 | Hardcode exclude parameters for PII Matcher
			// piiMatcherExclude is configurable so are removeIntlDomains and removeEduDomains
			// if need be can be changed in .prop file
			if (piiMatcherExclude) {
				Map<String, Boolean> excludeMap = new HashMap<>();
				excludeMap.put("remove_intl_domains", removeIntlDomains);
				excludeMap.put("remove_edu_domains", removeEduDomains);
				
				filterMap.put("exclude", excludeMap);
				
			//	map.put("exclude", excludeMap);
			}
			map.put("filters", filterMap);

			HttpEntity<?> request = new HttpEntity<>(map, headers);
			URI url = new URI(piiMatcherUrl);
			
			LOGGER.info("request for POST API: {}", request);
			LOGGER.info("url for POST API: {}",url);
			ResponseEntity<String> response = restTemplate.postForEntity( url, request , String.class );
			LOGGER.info("response from POST API getStatusCode: {}",response.getStatusCode());
			LOGGER.info("response from POST API hasBody: {}",response.hasBody());
			LOGGER.info("response from POST API getHeaders: {}",response.getHeaders());

			return true;
		} catch (Exception e) {
			LOGGER.error("NILeadsServiceImpl.callPostApi {}", e);
			throw new NIDmpException(
					"NILeadsServiceImpl.callPostApi(): {} , Error MEssage: {}", e);
		}
	}

	/**
	 * @param niLeadsDto
	 * @param jobIdName
	 */
	private long updateExpansionDistributionHistory(NiLeadsDto niLeadsDto, String jobIdName) {
		long distributionNo = findDistributionNo(niLeadsDto.getTimestamp());
		LOGGER.info("Expansion distributionNo: {}",distributionNo);
		// Create a Key factory to construct keys associated with this project.
		long dhTimeStamp = Instant.now().toEpochMilli();
		String distributionDate = DateUtility.getFormattedDateString(dhTimeStamp);
		String inboundRecords = "";	// TBD Later
		KeyFactory keyFactory = datastore.newKeyFactory()
				.setKind(ConstantsUtil.EXPANDED_AUD_DIST_HISTORY);
		LOGGER.info(ConstantsUtil.KEY_FACTORY);
		Key key = datastore.allocateId(keyFactory.newKey());
		Entity task = Entity.newBuilder(key)
				.set(ConstantsUtil.DIST_TIMESTAMP, dhTimeStamp)
				.set(ConstantsUtil.DISTRIBUTIONS, distributionNo)
				.set(ConstantsUtil.FILENAME, niLeadsDto.getFileName())
				.set(ConstantsUtil.STATUS, ConstantsUtil.PENDING_STATUS)
				.set(ConstantsUtil.INBOUND_CNT, inboundRecords)	
				.set(ConstantsUtil.MATCHED_CNT, ConstantsUtil.BLANK_SPACE)	// UPDATED IN LATER STAGE
				.set(ConstantsUtil.DISTRIBUTION_DATE, distributionDate)
				.set(ConstantsUtil.DESTINATION, niLeadsDto.getDestination())
				.set(ConstantsUtil.START_TIMESTAMP, niLeadsDto.getTimestamp())	
				.set(ConstantsUtil.SEQ_CODE, ConstantsUtil.VALIDATEFILE_SEQ_CODE) //file is already VALIDATED
				.set(ConstantsUtil.INBOUND_AUD_FILENAME, ConstantsUtil.BLANK_SPACE) // UPDATED IN LATER STAGE
				.set(ConstantsUtil.DISTRIBUTION_TYPE, niLeadsDto.getDistributionType())
				.set(ConstantsUtil.JOB_ID_NAME, jobIdName)
				.build();
		datastore.put(task);
		
		return distributionNo;
	}
	
	/**
	 * Update expanded Audience listing with distribution count
	 * @param expAudListingtimestamp
	 * @param distributionNo
	 */
	private void updateExpAudienceListing(Long 
			expAudListingtimestamp, long distributionNo) {
		QueryResults<Entity> result = fetchAudListingByTimestamp(
				expAudListingtimestamp);
		if (result.hasNext()) {
			LOGGER.info("updating exp audience listing:{}",expAudListingtimestamp);
			LOGGER.info("updating exp audience listing distNo:{}",distributionNo);
			Entity entity = result.next();
			Key entityKey = entity.getKey();
			entity = Entity.newBuilder(datastore.get(entityKey))
					.set(ConstantsUtil.DISTRIBUTIONS, distributionNo)
					.build();
			datastore.put(entity);
		}
		
	}
	
	/**
	 * Fetch Expanded Audience listing by timestamp
	 * @param expandedAudListingtimestamp
	 * @return
	 */
	private QueryResults<Entity> fetchAudListingByTimestamp(
			Long expAudListingtimestamp) {
		// Build the Query
		Query<Entity> query = Query.newEntityQueryBuilder()
				.setKind(ConstantsUtil.EXPANSION_AUDIENCE)                               
				.setFilter(PropertyFilter.eq(ConstantsUtil.TIMESTAMP, expAudListingtimestamp))
				.build();
		return datastore.run(query);
	}

	/**
	 * @param niLeadsDto
	 * @param jobIdName
	 */
	private void updateDistributionHistory(NiLeadsDto niLeadsDto, String jobIdName) {
		// 
		LOGGER.info("Distribution DS called");
		String inboundRecords = null;
		long distributionNo = 0l;
		
		// Updating Task table
		QueryResults<Entity> result = fetchByFilename(niLeadsDto.getFileName());
		if (result.hasNext()) {
			Entity entity = result.next();
			Key entityKey = entity.getKey();
			// Processing on result
			inboundRecords = entity.getString(ConstantsUtil.INBOUND_CNT);
			if(entity.contains(ConstantsUtil.DISTRIBUTIONS)) {

				distributionNo = entity.getLong(ConstantsUtil.DISTRIBUTIONS) + 1;
				entity = Entity.newBuilder(datastore.get(entityKey))
						.set(ConstantsUtil.DISTRIBUTIONS, distributionNo)
						.set(ConstantsUtil.SEQ_CODE, ConstantsUtil.VALIDATEFILE_SEQ_CODE) //as file is already validated.
						.build();
				// * Incrementing Distribution count
				datastore.put(entity);
			}
		}
		// Create a Key factory to construct keys associated with this project.
		long dhTimeStamp = Instant.now().toEpochMilli();
		String distributionDate = DateUtility.getFormattedDateString(dhTimeStamp);
		KeyFactory keyFactory = datastore.newKeyFactory()
				.setKind(ConstantsUtil.DISTRIBUTION_HISTORY);
		LOGGER.info(ConstantsUtil.KEY_FACTORY);
		Key key = datastore.allocateId(keyFactory.newKey());
		Entity task = Entity.newBuilder(key)
				.set(ConstantsUtil.DIST_TIMESTAMP, dhTimeStamp)
				.set(ConstantsUtil.DISTRIBUTIONS, distributionNo)
				.set(ConstantsUtil.FILENAME, niLeadsDto.getFileName())
				.set(ConstantsUtil.STATUS, ConstantsUtil.PENDING_STATUS)
				.set(ConstantsUtil.INBOUND_CNT, inboundRecords)	
				.set(ConstantsUtil.MATCHED_CNT, ConstantsUtil.BLANK_SPACE)	// UPDATED IN LATER STAGE
				.set(ConstantsUtil.DISTRIBUTION_DATE, distributionDate)
				.set(ConstantsUtil.DESTINATION, niLeadsDto.getDestination())
				.set(ConstantsUtil.USERNAME, ConstantsUtil.BLANK_SPACE)	// ADD USERNAME as per LOGGED IN USER
			//	.set(ConstantsUtil.TRAIT_ID, traitId.toString())
				.set(ConstantsUtil.START_TIMESTAMP, niLeadsDto.getTimestamp())
				.set(ConstantsUtil.SEQ_CODE, ConstantsUtil.VALIDATEFILE_SEQ_CODE) //file is already VALIDATED
				.set(ConstantsUtil.INBOUND_AUD_FILENAME, ConstantsUtil.BLANK_SPACE) // UPDATED IN LATER STAGE
				.set(ConstantsUtil.DISTRIBUTION_TYPE, niLeadsDto.getDistributionType())
				.set(ConstantsUtil.JOB_ID_NAME, jobIdName)
				.build();
		datastore.put(task);
	}
	
	/**
	 * @param expandedAudListingtimestamp
	 * @param distributionNo
	 * @return
	 */
	private long findDistributionNo(Long expandedAudListingtimestamp) {
		long distributionNo = 1l;
		Map<Long, String> map = new HashMap<>();
		QueryResults<Entity> result2 = fetchDHByStartTimestamp(
			expandedAudListingtimestamp);
		while (result2.hasNext())
		{
			Entity entity = result2.next();
			map.put(entity.getLong(ConstantsUtil.DISTRIBUTIONS)
					, entity.getString(ConstantsUtil.DISTRIBUTION_TYPE));
		}

		if (!map.isEmpty()) {
			TreeMap<Long, String> treeMap = new TreeMap<>(
		            (Comparator<Long>) (o1, o2) -> o2.compareTo(o1));
			treeMap.putAll(map);
			// distributionType = treeMap firstEntry getValue
			distributionNo = treeMap.firstKey() + 1l;
		}
		return distributionNo;
	}
	
	/**
	 * fetch DH by starttimestamp
	 * @param startTimeStamp
	 * @return
	 */
	private QueryResults<Entity> fetchDHByStartTimestamp(long startTimeStamp) {
		// Build the Query
		Query<Entity> query = Query.newEntityQueryBuilder()
				.setKind(ConstantsUtil.EXPANDED_AUD_DIST_HISTORY)                               
				.setFilter(PropertyFilter.eq(ConstantsUtil.START_TIMESTAMP, startTimeStamp))
				.build();
		return datastore.run(query);
	}
	
	/** Sets HttpHeaders for Rest API call
	 * @return
	 */
	private HttpHeaders setHttpHeaderForRestCall() {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		
		return httpHeaders;
	}

	@Override
	public PiiPubSubAttributesDto getNiLeadsJobStats(String jobIdName,
			String distributionType) {
		LOGGER.info("getNiLeadsJobStats called");
		PiiPubSubAttributesDto dto = null;
		try {
			QueryResults<Entity> result = fetchJobStatsByJobIdName(jobIdName);
			
			// Code changes for CYBG 321 | Storing and Display job stats for Phone
			if (ConstantsUtil.EMAIL.equalsIgnoreCase(distributionType) ||
					ConstantsUtil.ALL_MAIL.equalsIgnoreCase(distributionType)) {
				if (result.hasNext()) {
					Entity entity = result.next();
					
					// Set PiiPubSubAttributesDto
					dto = new PiiPubSubAttributesDto();
					dto.setAbuse(entity.getString(ConstantsUtil.ABUSE));
					dto.setCatchAll(entity.getString(ConstantsUtil.CATCHALL));
					dto.setCountInputRecords(entity.getString(ConstantsUtil.COUNTINPUT_RECORDS));
					dto.setCountValidEmails(entity.getString(ConstantsUtil.COUNTVALID_EMAILS));
					dto.setCreditsRemaining(entity.getString(ConstantsUtil.CREDITSREMAINING));
					dto.setDoNotMail(entity.getString(ConstantsUtil.DONOT_MAIL));
					dto.setInvalid(entity.getString(ConstantsUtil.INVALID));
					dto.setJobId(entity.getString(ConstantsUtil.JOB_ID_NAME));
					dto.setSpamtrap(entity.getString(ConstantsUtil.SPAMTRAP));
					dto.setUnknown(entity.getString(ConstantsUtil.UNKNOWN));
					dto.setValid(entity.getString(ConstantsUtil.VALID));
				}
			} else if (ConstantsUtil.PHONE.equalsIgnoreCase(distributionType)) {
				if (result.hasNext()) {
					Entity entity = result.next();

					// Set PiiPubSubAttributesDto
					dto = new PiiPubSubAttributesDto();
					LOGGER.info("Output Records: {}",entity.getString(ConstantsUtil.OUTPUTRECORDS));
					dto.setOutputRecords(entity.getString(ConstantsUtil.OUTPUTRECORDS));
					dto.setDncRemoved(entity.getString(ConstantsUtil.DNCREMOVED));
				}
			}
			
		} catch (Exception e) {
			LOGGER.error(
					"NILeadsServiceImpl.getNiLeadsJobStats(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"NILeadsServiceImpl.getNiLeadsJobStats(): {} , Error MEssage: {}", e);
		}
		return dto;
	}
	
	/**
	 * Fetch Job Stats by jobIdName
	 * @param jobIdName
	 * @return
	 */
	private QueryResults<Entity> fetchJobStatsByJobIdName(String jobIdName) {
		if(jobIdName.contains(ConstantsUtil.CSV_EXTN)) {
			jobIdName = jobIdName.substring(0, jobIdName.length()-4);
		}
		// Build the Query
		Query<Entity> query = Query.newEntityQueryBuilder()
				.setKind(ConstantsUtil.LEADS_JOB_STATS)  
				.setFilter(PropertyFilter.eq(ConstantsUtil.JOB_ID_NAME, jobIdName))
				.build();
		return datastore.run(query);
	}
	
}
