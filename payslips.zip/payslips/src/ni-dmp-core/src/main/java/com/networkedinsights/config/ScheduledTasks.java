/**
 * 
 */
package com.networkedinsights.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.threeten.bp.Instant;

import com.networkedinsights.service.IAAMService;
import com.networkedinsights.service.IFileService;
import com.networkedinsights.service.IJobStatsService;

/**
 * @author rajvirs
 *
 */
@Component
public class ScheduledTasks {
	private static final Logger LOGGER = LoggerFactory.getLogger(ScheduledTasks.class);
	
	@Autowired
	private IAAMService aamServiceImpl;
	
	@Autowired
	private IFileService fileServiceImpl;
	
	@Autowired
	private IJobStatsService jobStatsServiceImpl;
	/**
	 * This is a scheduled job which will run at
	 * 3 PM IST daily and reload traits in datastore
	 * by first deleting datastore and then fetching
	 * latest records from Adobe.
	 */
	@Scheduled(cron = "0 0 15 * * ?", zone = "Asia/Kolkata") //(fixedDelay = 3000) CET
	public void scheduleTaskReloadTraitsFromAdobe() {
		LOGGER.info("ScheduleTask to Reload Traits from Adobe to Datastore called: {}", Instant.now());
	 	aamServiceImpl.reloadTraitListFromJob();
	}
	
	// 15,30,45,59 * * ? * *			* * * ? * *
	/**
	 * This is a scheduled job which will run every
	 * 1 minute and fetch Pull Subscriber data.
	 */
	@Scheduled(cron = "0 * * ? * *")
	public void scheduleTaskPullSubscriberData() {
		LOGGER.info("ScheduleTask to Pull Subscriber Data: {}", Instant.now());
		fileServiceImpl.pullSub();
	}
	
	/**
	 * This is a scheduled job which will run twice daily
	 * at 01:00 AM and 01:00 PM IST
	 */
	@Scheduled(cron = "0 0 07,15,23 ? * *", zone = "UTC")
	public void scheduleTaskUpdateJobStats() {
		LOGGER.info("ScheduleTask to update Job Stats: {}", Instant.now());
		long timestamp = Instant.now().toEpochMilli();
		jobStatsServiceImpl.storeJobStats(timestamp);
	}
	
	/**
	 * This is a scheduled job which will run every
	 * 1 minute starting at 30th second 
	 * and fetch Pull Subscriber data for NI leads.
	 */
	@Scheduled(cron = "30 * * ? * *")
	public void scheduleTaskPullSubscriberDataForNiLeads() {
		LOGGER.info("ScheduleTask to Pull NiLeads Subscriber Data: {}", Instant.now());
		fileServiceImpl.pullSubForNiLeads();
	}
}
