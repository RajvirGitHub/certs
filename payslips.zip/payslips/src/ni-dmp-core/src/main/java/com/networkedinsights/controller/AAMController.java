package com.networkedinsights.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.networkedinsights.dto.TraitDto;
import com.networkedinsights.dto.TraitListDto;
import com.networkedinsights.service.IAAMService;

/**
 * @author rajvirs 172.27.25.144
 * created on - 21/01/2018
 * modified on - 13/03/2018
 */
@RestController
@RequestMapping("/core/v1")
//@CrossOrigin(origins = "http://localhost:3000")
public class AAMController extends AbstractBaseController{
	private static final Logger LOGGER = LoggerFactory.getLogger(AAMController.class);

	@Autowired
	private IAAMService aamService;
	
	/**
	 * This method will create a Trait, for the
	 * given set of parameters through UI part.
	 * @param traitDtoO
	 * @return
	 */
	@PostMapping("/trait")
	public ResponseEntity<String> createTrait(@RequestBody TraitDto traitDto) {
		LOGGER.info("CREATE TRAIT called");
		
		return ResponseEntity.ok(aamService.createTrait(traitDto));
	}

	/**
	 * This method will fetch trait list for the
	 * specified folderId and datasourceId if any.
	 * @param folderId
	 * @param dataSourceId
	 * @return
	 */
	@GetMapping("/trait")
	public ResponseEntity<List<TraitListDto>> fetchTraitList(
			@RequestParam(value = "folderId", required = false) String folderId,
			@RequestParam(value = "dataSourceId", required = false) String dataSourceId) {
		
		return ResponseEntity.ok(aamService.fetchTraitList(folderId, dataSourceId));
	}
	
	/**
	 * This method will fetch trait info (TTL) for the 
	 * passed trait Id.
	 * @param traitId
	 * @return
	 */
	@GetMapping("/trait/{traitId}")
	public ResponseEntity<Integer> fetchTraitById(@PathVariable
			Integer traitId) {
		TraitDto traitDto = aamService.fetchTraitById(traitId);
		if (null != traitDto)
			return ResponseEntity.ok(traitDto.getTtl());
		else
			return ResponseEntity.ok(0);	// Setting for Junit test case.
	}
	
	/**
	 * This method will fetch trait list for the
	 * specified folderId and datasourceId if any.
	 * @param folderId
	 * @param dataSourceId
	 * @return
	 */
	@GetMapping("/reload/trait")
	public ResponseEntity<List<TraitListDto>> reloadTraitList() {
		
		return ResponseEntity.ok(aamService.reloadTraitList());
	}	
	
	/**
	 * This method will Delete trait from Datastore 
	 * and Adobe Audience Manager.
	 * @param traitId
	 * @return
	 */
	@DeleteMapping("/trait/{traitId}/{username}")
	public ResponseEntity<Boolean> deleteTraitById(@PathVariable
			Integer traitId, @PathVariable String username) {
			return ResponseEntity.ok(aamService.deleteTraitById(
					traitId, username));
	}
	
	/**
	 * This method will update a Trait, for the
	 * given set of parameters through UI.
	 * @param traitDto
	 * @return
	 */
	@PutMapping("/trait/{traitId}")
	public ResponseEntity<Boolean> updateTrait(@RequestBody TraitDto traitDto,
			@PathVariable Integer traitId) {
		LOGGER.info("UPDATE TRAIT called");
		
		return ResponseEntity.ok(aamService.updateTrait(
				traitDto, traitId));
	}
	
}
