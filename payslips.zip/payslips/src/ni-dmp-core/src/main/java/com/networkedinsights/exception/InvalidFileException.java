package com.networkedinsights.exception;

/**
 * @author rajvirs
 * created on - 13/02/2018
 * modified on - 14/02/2018
 */
public class InvalidFileException extends RuntimeException {

	private static final long serialVersionUID = -362375505565248790L;

	public InvalidFileException(String string) {
		super(string);
	}

}
