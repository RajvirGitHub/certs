/**
 * 
 */
package com.networkedinsights.dto;

/**
 * @author rajvirs
 * created on - 26/03/2018
 * modified on - 26/03/2018
 *
 */
public class FileDetailPubDto {
	private String filepath;
	private Long starttimestamp;
	
	public String getFilepath() {
		return filepath;
	}
	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}
	public Long getStarttimestamp() {
		return starttimestamp;
	}
	public void setStarttimestamp(Long starttimestamp) {
		this.starttimestamp = starttimestamp;
	}
}
