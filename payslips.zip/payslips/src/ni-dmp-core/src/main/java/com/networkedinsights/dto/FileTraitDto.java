/**
 * 
 */
package com.networkedinsights.dto;

/**
 * @author rajvirs
 *
 */
public class FileTraitDto {
	
	private String fileName;
	private Integer traitId;
	
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public Integer getTraitId() {
		return traitId;
	}
	public void setTraitId(Integer traitId) {
		this.traitId = traitId;
	}
}
