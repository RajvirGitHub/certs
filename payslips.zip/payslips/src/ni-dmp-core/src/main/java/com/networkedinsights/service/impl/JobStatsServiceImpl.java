/**
 * 
 */
package com.networkedinsights.service.impl;

import java.util.List;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.google.cloud.datastore.Batch;
import com.google.cloud.datastore.Datastore;
import com.google.cloud.datastore.Entity;
import com.google.cloud.datastore.Key;
import com.google.cloud.datastore.KeyFactory;
import com.google.cloud.datastore.Query;
import com.google.cloud.datastore.QueryResults;
import com.networkedinsights.dto.JobStatsDto;
import com.networkedinsights.exception.NIDmpException;
import com.networkedinsights.service.IAAMService;
import com.networkedinsights.service.IJobStatsService;
import com.networkedinsights.util.ConstantsUtil;

/**
 * @author rajvirs
 *
 */
@Service
public class JobStatsServiceImpl implements IJobStatsService {

	private static final Logger LOGGER = LoggerFactory.getLogger(JobStatsServiceImpl.class);

	@Autowired
	private IAAMService aamServiceImpl;

	@Autowired
	private Datastore datastore;

	private KeyFactory userKeyFactory;

	@PostConstruct
	public void initializeKeyFactories() {
		LOGGER.info("Initializing key factories");
		userKeyFactory = datastore.newKeyFactory().setKind(ConstantsUtil.JOBSTATS);
	}

	@Override
	public boolean storeJobStats(Long timestamp) {
		LOGGER.info("getJobSTats called");
		
		try {
			// Check if DS is not empty
			List<JobStatsDto> list = null;
			QueryResults<Entity> result = fetchJobStatsDS();
			if (result.hasNext()) {
				list = aamServiceImpl.fetchJobStatsList(
						timestamp, false);
			}
			else {
				// DS is empty
				list = aamServiceImpl.fetchJobStatsList(
						timestamp, true);
			}

			LOGGER.info("getJobSTats list: {}",list.size());
			if (!CollectionUtils.isEmpty(list)) {
				updateJobStatsInDatastore(list);
			}
		} catch (Exception e) {
			LOGGER.error(
					"DistributionsServiceImpl.getJobStats(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"DistributionsServiceImpl.getJobStats(): {} , Error MEssage: {}", e);
		}
		LOGGER.info("DS created ");
		return true;
	}

	/**
	 * Fetch Distribution History by filename
	 * @param filename
	 * @return
	 */
	private QueryResults<Entity> fetchJobStatsDS() {
		// Build the Query
		Query<Entity> query = Query.newEntityQueryBuilder()
				.setKind(ConstantsUtil.JOBSTATS)                                
				.build();
		return datastore.run(query);
	}

	/**
	 * Store all Traits in Datastore
	 * @param traitDtoList
	 * @return
	 */
	private Batch.Response updateJobStatsInDatastore(List<JobStatsDto> jobStatsDtoList) {
		Batch batch = datastore.newBatch();
		LOGGER.info("getJobSTats creating batch ");
		for (JobStatsDto obj : jobStatsDtoList) {
			batch.put(createJobStatsEntity(obj));
		}
		LOGGER.info("getJobSTats after creating batch ");
		return batch.submit();
	}

	/**
	 * Set Trait Entity to add in Batch
	 * @param obj
	 * @return
	 */
	private Entity createJobStatsEntity(JobStatsDto obj) {
		Key key = userKeyFactory.newKey(obj.getDataFileName());
		
		return Entity.newBuilder(key)
				.set(ConstantsUtil.DATA_FILENAME, obj.getDataFileName())
				.set(ConstantsUtil.ID_SYNC_DPID, obj.getIdSyncDpid())
				.set(ConstantsUtil.RECORDS_RCVD, obj.getRecordsReceived())
				.set(ConstantsUtil.RECORDS_SUCCESS, obj.getRecordsSuccess())
				.set(ConstantsUtil.PERCENTAGE_SUCCESS, obj.getPercentageSuccess())
				.set(ConstantsUtil.FAILED_PARSE_CHECK, obj.getFailedParseCheck())
				.set(ConstantsUtil.FAILED_PCS_TIMEOUT_UUID, obj.getFailedPCSTimeoutUUIDLookup())
				.set(ConstantsUtil.FAILED_PCS_TIMEOUT_TRAITS, obj.getFailedPCSTimeoutTraitsLookup())
				.set(ConstantsUtil.FAILED_UUID_LOOKUP, obj.getFailedUUIDLookup())
				.set(ConstantsUtil.FAILED_INVALID_DEMDEX, obj.getFailedInvalidDemdexUUID())
				.set(ConstantsUtil.FAILED_NO_REALIZED_TRAITS, obj.getFailedNoRealizedTrait())
				.set(ConstantsUtil.TOTAL_SIGNALS, obj.getTotalSignals())
				.set(ConstantsUtil.TOTAL_UNUSED_SIGNALS, obj.getTotalUnusedSignals())
				.set(ConstantsUtil.TOTAL_REALIZED_TRAITS, obj.getTotalrealizedtraits())
				.set(ConstantsUtil.TOTAL_REMOVED_TRAITS, obj.getTotalRemovedTraits())
				.set(ConstantsUtil.TOTAL_NEW_TRAITS, obj.getTotalNewTraits())
				.set(ConstantsUtil.PERCENTAGE_USED_SIGNALS, obj.getPercentageUsedSignals())
				.set(ConstantsUtil.STARTTIME, obj.getStartTime())
				.set(ConstantsUtil.ENDTIME, obj.getEndTime())
				.set(ConstantsUtil.SAMPLING_AVAILABLE, obj.getSamplingAvailable())
				.set(ConstantsUtil.TOTAL_INVALID_GLOBAL_DEVICE_IDS, obj.getTotalInvalidGlobalDeviceIds())
				.build();
	}
}
