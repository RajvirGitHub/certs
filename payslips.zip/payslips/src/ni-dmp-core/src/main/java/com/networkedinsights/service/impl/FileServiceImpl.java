package com.networkedinsights.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.LongStream;

import javax.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.threeten.bp.Duration;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.internal.Constants;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.S3Object;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.core.ApiFuture;
import com.google.api.gax.core.FixedCredentialsProvider;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.ReadChannel;
import com.google.cloud.RetryOption;
import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.Dataset;
import com.google.cloud.bigquery.DatasetInfo;
import com.google.cloud.bigquery.Field;
import com.google.cloud.bigquery.FieldValue;
import com.google.cloud.bigquery.FieldValueList;
import com.google.cloud.bigquery.FormatOptions;
import com.google.cloud.bigquery.Job;
import com.google.cloud.bigquery.JobId;
import com.google.cloud.bigquery.JobInfo;
import com.google.cloud.bigquery.JobInfo.CreateDisposition;
import com.google.cloud.bigquery.LegacySQLTypeName;
import com.google.cloud.bigquery.LoadJobConfiguration;
import com.google.cloud.bigquery.QueryJobConfiguration;
import com.google.cloud.bigquery.Schema;
import com.google.cloud.bigquery.Table;
import com.google.cloud.bigquery.TableId;
import com.google.cloud.bigquery.TableResult;
import com.google.cloud.datastore.Datastore;
import com.google.cloud.datastore.DatastoreOptions;
import com.google.cloud.datastore.Entity;
import com.google.cloud.datastore.Key;
import com.google.cloud.datastore.KeyFactory;
import com.google.cloud.datastore.Query;
import com.google.cloud.datastore.QueryResults;
import com.google.cloud.datastore.StructuredQuery;
import com.google.cloud.datastore.StructuredQuery.PropertyFilter;
import com.google.cloud.pubsub.v1.Publisher;
import com.google.cloud.pubsub.v1.stub.GrpcSubscriberStub;
import com.google.cloud.pubsub.v1.stub.SubscriberStub;
import com.google.cloud.pubsub.v1.stub.SubscriberStubSettings;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Bucket;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import com.google.protobuf.ByteString;
import com.google.pubsub.v1.AcknowledgeRequest;
import com.google.pubsub.v1.ProjectSubscriptionName;
import com.google.pubsub.v1.ProjectTopicName;
import com.google.pubsub.v1.PubsubMessage;
import com.google.pubsub.v1.PullRequest;
import com.google.pubsub.v1.PullResponse;
import com.google.pubsub.v1.ReceivedMessage;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.networkedinsights.dto.FileDetailDto;
import com.networkedinsights.dto.FileDetailPubDto;
import com.networkedinsights.dto.FileTraitDto;
import com.networkedinsights.dto.PiiPubSubAttributesDto;
import com.networkedinsights.dto.PubSubAttributesDto;
import com.networkedinsights.dto.TraitDto;
import com.networkedinsights.exception.DuplicateFileFoundException;
import com.networkedinsights.exception.InvalidFileException;
import com.networkedinsights.exception.NIDmpException;
import com.networkedinsights.service.IAAMService;
import com.networkedinsights.service.IFileService;
import com.networkedinsights.util.ConstantsUtil;
import com.networkedinsights.util.DateUtility;
/**
 * @author rajvirs
 * created on - 17/01/2019
 * modified on - 13/03/2019
 */

@Service
public class FileServiceImpl implements IFileService {

	private static final Logger LOGGER = LoggerFactory.getLogger(FileServiceImpl.class);
	private static Storage storage = null;

	/** The method is called after the FileServiceImpl bean is initialized
	 * 
	 */
	@PostConstruct
	public static void initializeStorage() {
		storage = StorageOptions.getDefaultInstance().getService();
	}


	@Value("${gcsDataset.name}")
	private String datasetName;

	@Value("${aws.bucket}")
	private String bucket;

	@Value("${dpid}")
	private String dpid;

	@Value("${uuid.min.threshold}")
	private Integer minThresholdForDistinctUUID;

	@Value("${project.name}")
	private String projectName;

	@Value("${topic.name}")
	private String topicName;

	@Value("${bucketname.inbound}")
	private String bucketnameInbound;

	@Value("${bucketname.inbound.ui}")
	private String bucketnameInboundUi;

	@Value("${bucketname.intermediate}")
	private String bucketnameIntermediate;

	@Value("${bucketname.outbound}")
	private String bucketnameOutbound;

	@Value("${airflow.bucket}")
	private String airflowBucket;

	@Value("${pathto.credkey.airflow}")
	private String pathToJsonKey;

	@Value("${cloud9.airflow.dev}")
	private String cloud9AirflowDev;

	@Value("${cloud9.airflow.subs.dev}")
	private String cloud9AirflowSubsDev;

	@Value("${bucket.inbound.upliftdev}")
	private String inboundBucketUpliftDev;

	// Environment variables from Prod
	@Value("${airflow.bucket.prod}")
	private String airflowBucketProd;

	@Value("${cloud9.airflow.prod}")
	private String cloud9AirflowProd;

	@Value("${cloud9.airflow.subs.prod}")
	private String cloud9AirflowSubsProd;

	@Value("${bucket.inbound.upliftprod}")
	private String inboundBucketUpliftProd; //bucket.inbound.upliftprod

	@Value("${pii.matcher.subs.dev}")
	private String piiMatcherSubsDev;

	@Value("${pii.matcher.subs.prod}")
	private String piiMatcherSubsProd;

	@Value("${mailgun.domain}")
	private String mailgunDomain;

	@Value("${mailgun.apikey}")
	private String mailgunApikey;

	@Value("${mailgun.from.email}")
	private String mailgunFromEmail;

	@Value("${mailgun.to.email}")
	private String mailgunToEmail;
	
	@Value("${pii.matcher.bucket.dev}")
	private String piiMatcherBucketDev;
	
	@Value("${pii.matcher.bucket.prod}")
	private String piiMatcherBucketProd;
	@Autowired
	private AmazonS3 s3Client;

	@Autowired
	private BigQuery bigQuery;

	@Autowired
	private IAAMService aamService;

	@Autowired
	private Datastore datastore;

	@Autowired
	private RestTemplate restTemplate;

	@Override
	public void uploadFile(String keyName, MultipartFile file,
			Integer traitId) {
		try {
			// Get the file and save it somewhere
			byte[] bytes = file.getBytes();

			Bucket bucket4Upload = storage.get(bucketnameInboundUi);

			ByteArrayInputStream inputStream = new ByteArrayInputStream(
					bytes);
			// COMMENTING FOR TESTING
			bucket4Upload.create(file.getOriginalFilename(), inputStream);

			LOGGER.info("File UPLOADED SUCCESSFULLY");


		} catch(DuplicateFileFoundException e) {
			throw e;
		} catch(Exception e) {
			LOGGER.error("FileServiceImpl.uploadFile {}", e.getMessage());
			throw new NIDmpException(
					"FileServiceImpl.uploadFile(): {} , Error MEssage: {}", e);
		} 
	}


	@Override
	public Boolean validateFile(FileDetailDto fileDetailDto) {

		LOGGER.info("validate File");
		try{
			String [] fileLocArr = fileDetailDto.getFilePath().split("_");
			if(null != fileLocArr && fileLocArr.length > 0 && 
					(fileDetailDto.getFilePath().endsWith(ConstantsUtil.CSV_EXTN) ||
							fileDetailDto.getFilePath().endsWith(".CSV"))){

				processFileValidation(fileDetailDto, fileLocArr[fileLocArr.length-1]);
			} else{
				LOGGER.error("Incorrect file type, Please upload .csv file");
				throw new InvalidFileException(ConstantsUtil.INVALID_FILE);
			}

		} 
		catch(InvalidFileException e) {
			setSequenceCode(fileDetailDto.getTimestamp(), 
					ConstantsUtil.ERROR_VALIDATEFILE_SEQ_CODE, 
					e.getMessage());
			throw e;
		}
		catch(Exception e) {
			LOGGER.error(
					"FileServiceImpl.validateFile(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			setSequenceCode(fileDetailDto.getTimestamp(), 
					ConstantsUtil.ERROR_VALIDATEFILE_SEQ_CODE, 
					ConstantsUtil.ERROR_VALIDATEFILE_STATUS);	
			throw new NIDmpException(
					"FileServiceImpl.validateFile(): {} , Error MEssage: {}", e);
		}
		return true;
	}


	@Override
	public Boolean loadSocialIdToFile(FileDetailDto
			fileDetailDto) {
		LOGGER.info("Loading socialIds to file");
		Dataset dataset = null;
		try {
			DatasetInfo.newBuilder(datasetName).build();
			// Creates the dataset
			dataset = bigQuery.getDataset(datasetName);
			LOGGER.info("Dataset ID {}: ", dataset.getDatasetId());
			//Get the social_id table reference
			Table table = bigQuery.getTable(datasetName, ConstantsUtil.TABLE_NAME
					+fileDetailDto.getTimestamp());
			if(table == null)
			{
				loadDataFromGCSToTable(fileDetailDto);
			} else {
				LOGGER.info("Table already exists");
			}
			// Update Sequence code with Status
			setSequenceCode(fileDetailDto.getTimestamp(), ConstantsUtil.LOAD_SOCIALID_TO_FILE_SEQ_CODE, 
					ConstantsUtil.LOAD_SOCIALID_TO_FILE_STATUS);

		} catch (Exception e) {
			LOGGER.error(
					"FileServiceImpl.loadSocialIdToFile(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			setSequenceCode(fileDetailDto.getTimestamp(), 
					ConstantsUtil.ERROR_VALIDATEFILE_SEQ_CODE, 
					ConstantsUtil.ERROR_LOADSOCIALIDTOFILE_STATUS);
			throw new NIDmpException(
					"FileServiceImpl.loadSocialIdToFile(): {} , Error MEssage: {}", e);
		}
		return true;
	}


	@Override
	public Boolean syncAdobeUUIdWithSocialId(FileDetailDto
			fileDetailDto) {

		LOGGER.info("Sync adobeUUId with socialId");
		try {
			String deleteQuery = "delete from "+datasetName+"."+ConstantsUtil.TABLE_NAME
					+fileDetailDto.getTimestamp()+" where social_id is null;";
			runQueryDelete(deleteQuery);

			String queryWithView = "select t1.adobe_uuid as adobe_uuid,t2.social_id as social_id FROM "
					+datasetName+"."
					+ConstantsUtil.TABLE_NAME+fileDetailDto.getTimestamp()
					+" as t2 LEFT JOIN `"+projectName+"."+datasetName
					+".adobe_xref_view` as t1 ON t2.social_id = t1.twitter_id;";
			runQuery(queryWithView, fileDetailDto.getTimestamp());

			// Update Sequence code with Status
			setSequenceCode(fileDetailDto.getTimestamp(), 
					ConstantsUtil.SYNC_ADOBEUUID_SOCIALID_SEQ_CODE, 
					ConstantsUtil.SYNC_ADOBEUUID_SOCIALID_STATUS);

		} catch(Exception e) {
			LOGGER.error(
					"FileServiceImpl.syncAdobeUUIdWithSocialId(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			setSequenceCode(fileDetailDto.getTimestamp(), 
					ConstantsUtil.ERROR_VALIDATEFILE_SEQ_CODE, 
					ConstantsUtil.ERROR_SYNC_ADOBE_SOCIALID_STATUS);
			throw new NIDmpException(
					"FileServiceImpl.syncAdobeUUIdWithSocialId(): {} , Error MEssage: {}", e);
		}
		return true;
	}


	/**
	 * This method will set Sequence Code appropriately, to keep
	 * track of processing.
	 * @param startTimeStamp
	 * @param sequenceCode
	 * @param traitId
	 * @param status
	 */
	public void setSequenceCode(long startTimeStamp, Integer sequenceCode, 
			String traitId, String status)
	{

		QueryResults<Entity> result = fetchByStartTimestamp(startTimeStamp);
		if(result.hasNext())
		{
			Key entityKey = result.next().getKey();						  
			Entity entity = Entity.newBuilder(datastore.get(entityKey))
					.set(ConstantsUtil.SEQ_CODE, sequenceCode) //setting the value of Sequence Code.
					.set(ConstantsUtil.STATUS, status)
					.set(ConstantsUtil.TRAIT_ID, traitId)
					.build();
			datastore.put(entity);
		}	
	}

	@Override
	public void createIntermediateFileForGCS(FileDetailDto fileDetailDto) {
		//	destinationTable - > Change the way it is SET as per present code it will change always	
		//	Put result of join query in file in GCS
		try{
			LOGGER.info("Create Intermediate file for GCS");

			String queryWithView = "select t1.adobe_uuid as adobe_uuid,t1.social_id as social_id FROM "+datasetName+"."+
					ConstantsUtil.DESTINATION_TABLE+fileDetailDto.getTimestamp()+" as t1;";
			TableResult result = fetchDestinationTable(queryWithView);
			Set<String> adobeUUIDSet = new HashSet<>();
			String data = iterateQueryResult(result, fileDetailDto.getTimestamp(), adobeUUIDSet);
			uploadSmallBlob(data, bucketnameIntermediate, 
					fileDetailDto.getTimestamp());
			// Update Sequence code with Status and MatchedAdobeRec
			setSequenceCodeAndMatchedAdobeRec(fileDetailDto.getTimestamp(), 
					ConstantsUtil.INTERMEDIATE_FILE_FOR_GCS_SEQ_CODE, 
					ConstantsUtil.INTERMEDIATE_FILE_FOR_GCS_STATUS, adobeUUIDSet.size());
		} catch(InvalidFileException e) {
			setSequenceCode(fileDetailDto.getTimestamp(), 
					ConstantsUtil.ERROR_VALIDATEFILE_SEQ_CODE, 
					e.getMessage());
			throw e;
		} catch(Exception e){
			LOGGER.error(
					"FileServiceImpl.createIntermediateFileForGCS(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			setSequenceCode(fileDetailDto.getTimestamp(), 
					ConstantsUtil.ERROR_VALIDATEFILE_SEQ_CODE, 
					ConstantsUtil.ERROR_INTERMEDIATEFILE_GCS_STATUS);
			throw new NIDmpException(
					"FileServiceImpl.createIntermediateFileForGCS(): {} , Error MEssage: {}", e);
		}

	}


	/**
	 * This method will set Sequence Code appropriately, to keep
	 * track of processing.
	 * @param startTimeStamp
	 * @param sequenceCode
	 * @param status
	 */
	public void setSequenceCode(long startTimeStamp, Integer sequenceCode, 
			String status) {

		long distributionNo = 0l;

		QueryResults<Entity> result = fetchByStartTimestamp(startTimeStamp);
		if(result.hasNext())
		{
			Entity entity = result.next();
			Key entityKey = entity.getKey();

			distributionNo = setDistributionNo(distributionNo, entity);
			entity = Entity.newBuilder(datastore.get(entityKey))
					.set(ConstantsUtil.SEQ_CODE, sequenceCode) //setting the value of Sequence Code.
					.set(ConstantsUtil.STATUS, status)
					.build();
			datastore.put(entity);
		}
		try {
			TimeUnit.MILLISECONDS.sleep(100);
		} catch (InterruptedException e) {

			LOGGER.error("InterruptedException in setSequenceCode : {}", e);
			// Only logging isn't enough. So, Restore interrupted state..
			Thread.currentThread().interrupt();

		}
		// Update DistributionHistory DS | CYBG 201,202
		updateDistributionHistory(startTimeStamp, sequenceCode, 
				status, distributionNo);
	}

	@Override
	public Boolean uploadOutboundFileGCS(FileDetailDto fileDetailDto) {

		//Put result of join query in file in GCS
		try{
			LOGGER.info("Uploading Outbound file to GCS");
			String destTableName = ConstantsUtil.DESTINATION_TABLE
					+fileDetailDto.getTimestamp();
			Table destTable = bigQuery.getTable(datasetName, destTableName);
			putResultinGCS(destTable, destTableName, fileDetailDto.getTimestamp());

			// Update Sequence code with Status
			setSequenceCode(fileDetailDto.getTimestamp(), 
					ConstantsUtil.OUTBOUND_FILE_FOR_GCS_SEQ_CODE, 
					ConstantsUtil.OUTBOUND_FILE_FOR_GCS_STATUS);
		} catch(Exception e){
			LOGGER.error(
					"FileServiceImpl.uploadOutboundFileGCS(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			setSequenceCode(fileDetailDto.getTimestamp(), 
					ConstantsUtil.ERROR_VALIDATEFILE_SEQ_CODE, 
					ConstantsUtil.ERROR_UPLOAD_FILE_GCS_STATUS);
			throw new NIDmpException(
					"FileServiceImpl.uploadOutboundFileGCS(): {} , Error MEssage: {}", e);
		}
		return true;

	}

	@Override
	public void uploadInboundFileToS3(FileDetailDto fileDetailDto) {

		String blobName = ConstantsUtil.NI_INTERMEDIATE+fileDetailDto.getTimestamp()
		+ConstantsUtil.CSV_EXTN;
		try (ReadChannel reader = storage.reader(bucketnameIntermediate, blobName)) {
			long startTime = System.currentTimeMillis();

			StringBuilder sb = readFileInChunks(reader);

			long endTime = System.currentTimeMillis();
			LOGGER.info("Time taken to read file from Intermediate storage{} ms", (endTime - startTime));

			processDataUploadToS3(fileDetailDto.getTimestamp(), sb.toString().trim());
		} catch (AmazonServiceException ase) {
			LOGGER.error("AmazonServiceException from POST requests: Error Message: {} "
					, ase.getMessage());
			throw ase;
		} catch (AmazonClientException ace) {
			LOGGER.error("AmazonClientException from POST requests: Error Message: {} "
					, ace.getMessage());
			throw ace;
		} catch(Exception e){
			LOGGER.error(
					"FileServiceImpl.uploadInboundFileToS3(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			setSequenceCode(fileDetailDto.getTimestamp(), 
					ConstantsUtil.ERROR_VALIDATEFILE_SEQ_CODE, 
					ConstantsUtil.ERROR_UPLOAD_FILE_S3_STATUS);
			throw new NIDmpException(
					"FileServiceImpl.uploadInboundFileToS3(): {} , Error MEssage: {}", e);
		}

	}

	// Uploading file to S3 for Audience Expansion flow
	@Override
	public String uploadExpandedInboundFileToS3(Long timestamp, 
			String destFileName, String distributionType) {

		String host = System.getenv("NI_DMP_CORE_FILE_TRANSFER_SVC_SERVICE_HOST");
		LOGGER.info("host name for POST API: {}",host);
		try {
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);

			StringBuilder sb = new StringBuilder(ConstantsUtil.FTP_DPM);
			sb.append(dpid).append("_").append(Instant.now().getEpochSecond());
			if (ConstantsUtil.OVERWRITE_TYPE.equalsIgnoreCase(distributionType)) {
				sb.append(ConstantsUtil.FILE_EXTN_OVERWRITE);
			} else {
				sb.append(ConstantsUtil.FILE_EXTN_SYNC);
			}
			String srcFilePath = ConstantsUtil.SOURCEURI +bucketnameIntermediate
					+ConstantsUtil.FORWARD_SLASH +destFileName;

			String destFilePath = "s3://"+ bucket + ConstantsUtil.DATE_LABEL_FOR_FILE + 
					DateUtility.getFormattedDateString() +
					ConstantsUtil.FORWARD_SLASH + sb.toString();
			Map<String, String> fileTransferMap = new HashMap<>();
			fileTransferMap.put("srcFilePath", srcFilePath);
			fileTransferMap.put("destFilePath", destFilePath);

			HttpEntity<?> request = new HttpEntity<>(fileTransferMap, httpHeaders);
			URI url = new URI("http://"+host+":8080"+"/core/v1/file-transfer");
			LOGGER.info("request for POST API request: {}",request);
			LOGGER.info("url for POST API url:{} ",url);
			ResponseEntity<String> response = restTemplate.postForEntity( url, request , String.class );
			LOGGER.info("Response from File transfer POST API: {}",response.getStatusCode());
			LOGGER.info("response from POST API hasBody: {}",response.hasBody());
			LOGGER.info("response from POST API getBody: {}",response.getBody());

			// Update Sequence code with Status
			String finalFile = null;
			if (response.hasBody() && ConstantsUtil.SUCCESS
					.equalsIgnoreCase(response.getBody())) {
				finalFile = sb.toString();
				setSequenceCodeInDS(timestamp, finalFile,
						ConstantsUtil.UPLOAD_INBOUND_FILE_TO_S3_SEQ_CODE, 
						ConstantsUtil.UPLOAD_INBOUND_FILE_TO_S3_STATUS);

				LOGGER.info("Uploaded File name and sequence code in DS: {} ", finalFile);
			} else {
				LOGGER.info("Error in uploading file to S3");
			}

			return finalFile;
		} catch (AmazonServiceException ase) {
			LOGGER.error("AmazonServiceException from POST requests: Error Message: {}"
					, ase.getMessage());
			throw ase;
		} catch (AmazonClientException ace) {
			LOGGER.error("AmazonClientException from POST requests: Error Message: {}"
					, ace.getMessage());
			throw ace;
		} catch(Exception e){
			LOGGER.error(
					"FileServiceImpl.uploadExpandedInboundFileToS3(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			setSequenceCode(timestamp, 
					ConstantsUtil.ERROR_VALIDATEFILE_SEQ_CODE, 
					ConstantsUtil.ERROR_UPLOAD_FILE_S3_STATUS);
			throw new NIDmpException(
					"FileServiceImpl.uploadExpandedInboundFileToS3(): {} , Error MEssage: {}", e);
		}

	}

	/**
	 * @param fileDetailDto
	 * @param sb
	 * @throws UnsupportedEncodingException
	 */
	private void processDataUploadToS3(Long timestamp, String stringBuilder2)
			throws UnsupportedEncodingException {
		String bucketName2 = bucket + ConstantsUtil.DATE_LABEL_FOR_FILE + 
				DateUtility.getFormattedDateString();	//d.format(newPattern)
		// write File listOf Ids  trait Id 	CODE FOR  GZIP
		// Upload file
		// Code changes to update extension based on user selection CYBG-229
		// User can either append the file with .sync extension or 
		// user can overwrite the file with .overwrite extension.

		String distributionType = null;
		QueryResults<Entity> result2 = fetchDHByStartTimestamp(
				timestamp);
		Map<Long, String> map = new HashMap<>();
		while (result2.hasNext())
		{
			Entity entity = result2.next();

			if ((ConstantsUtil.DEST_ADOBE).equalsIgnoreCase(entity.getString(ConstantsUtil.DESTINATION
					)) && entity.contains(ConstantsUtil.DISTRIBUTION_TYPE)) {

				map.put(entity.getLong(ConstantsUtil.DISTRIBUTIONS)
						, entity.getString(ConstantsUtil.DISTRIBUTION_TYPE));
			}
		}

		if (!map.isEmpty()) {
			TreeMap<Long, String> treeMap = new TreeMap<>(
					(Comparator<Long>) (o1, o2) -> o2.compareTo(o1));
			treeMap.putAll(map);
			distributionType = treeMap.firstEntry().getValue();	
		}

		StringBuilder sb = new StringBuilder(ConstantsUtil.FTP_DPM);
		sb.append(dpid).append("_").append(Instant.now().getEpochSecond());
		if (ConstantsUtil.OVERWRITE_TYPE.equalsIgnoreCase(distributionType)) {
			sb.append(ConstantsUtil.FILE_EXTN_OVERWRITE);
		} else {
			sb.append(ConstantsUtil.FILE_EXTN_SYNC);
		}
		ByteArrayInputStream inputStream = new ByteArrayInputStream(
				stringBuilder2.getBytes(Constants.DEFAULT_ENCODING));
		//Amazon S3 never stores partial objects, if during this call an exception wasn't thrown, the entire object was stored. 
		s3Client.putObject(bucketName2, sb.toString(), inputStream, new ObjectMetadata());

		// Update Sequence code with Status
		setSequenceCode(timestamp, sb.toString(),
				ConstantsUtil.UPLOAD_INBOUND_FILE_TO_S3_SEQ_CODE, 
				ConstantsUtil.UPLOAD_INBOUND_FILE_TO_S3_STATUS);

		LOGGER.info("Uploaded File Name: {} ", sb);
		LOGGER.info("Bucket: {} ", bucketName2);
	}

	@Override
	public Boolean makeEntryInDataStoreCallPubSub(FileTraitDto 
			fileTraitDto, String destination, String distributionType) {
		try {
			makeEntryInDataStore(fileTraitDto.getFileName(), 
					bucketnameInboundUi, destination, distributionType);
		} catch (Exception e) {
			LOGGER.error(
					"FileServiceImpl.makeEntryInDataStoreCallPubSub(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"FileServiceImpl.makeEntryInDataStoreCallPubSub(): {} , Error MEssage: {}", e);
		}
		return true;
	}

	@Override
	public byte [] downloadInboundFile(String fileName, Boolean isUI) {
		String bucketName = null;
		if (isUI)
			bucketName = bucketnameInboundUi;
		else
			bucketName = bucketnameInbound;

		try (ReadChannel reader = storage.reader(bucketName, fileName)) {
			StringBuilder sb = readFileInChunks(reader);

			return String.valueOf(sb).getBytes();
		} catch(Exception e){
			LOGGER.error(
					"FileServiceImpl.downloadInboundFile(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"FileServiceImpl.downloadInboundFile(): {} , Error MEssage: {}", e);
		}
	}

	/**
	 * Sets SequenceCode, status and inbound Aud filename
	 * @param startTimeStamp
	 * @param fileName
	 * @param sequenceCode
	 * @param status
	 */
	private void setSequenceCode(Long startTimeStamp, String fileName, 
			Integer sequenceCode,
			String status) {

		long distributionNo = 0l;
		QueryResults<Entity> result = fetchByStartTimestamp(startTimeStamp);
		if(result.hasNext())
		{
			Entity entity = result.next();
			Key entityKey = entity.getKey();
			distributionNo = setDistributionNo(distributionNo, entity);					  
			entity = Entity.newBuilder(datastore.get(entityKey))
					.set(ConstantsUtil.SEQ_CODE, sequenceCode) //setting the value of Sequence Code.
					.set(ConstantsUtil.STATUS, status)
					.set(ConstantsUtil.INBOUND_AUD_FILENAME, fileName)
					.build();
			datastore.put(entity);
		}	

		// Update DistributionHistory DS | CYBG 201,202
		updateDistributionHistoryWithS3File(startTimeStamp, sequenceCode, 
				status, distributionNo, fileName);
	}


	/**
	 * Processing validations of inbound file. 
	 * @param fileDetailDto
	 * @param obj
	 * @throws Exception 
	 */
	private void processFileValidation(FileDetailDto fileDetailDto, String obj) throws Exception {
		LOGGER.info("File Name validation for trait Id and .csv format");
		if(obj.endsWith(ConstantsUtil.CSV_EXTN) || obj.endsWith(".CSV")){
			String traitId = getTraitId(fileDetailDto.getTimestamp());
			LOGGER.info("getTraitId: {}",traitId);
			if(null != traitId && traitId.length() > 0) {
				// UI Flow i.e. file uploaded from UI
				LOGGER.info("Inside If: UI Flow i.e. file uploaded from UI");
				readLargeFileContent(fileDetailDto, traitId, true, true);
			} else {
				LOGGER.info("Inside else: GCF triggered Rest API");
				// File uploaded in Storage and GCF triggered Rest API
				traitId = obj.substring(0, obj.length()-4);
				if(traitId.matches("\\d+")){
					if(traitId.length() <= 8){
						LOGGER.info("Valid Format for traitId");
						// Read file
						readLargeFileContent(fileDetailDto, traitId, true, false);
					} else {
						LOGGER.error("Invalid length of traitId");
						throw new InvalidFileException(ConstantsUtil.INVALID_TRAITID);
					}
				} else {
					// CREATE a trait. POST CALL of ADOBE AAM API
					// Read file
					readLargeFileContent(fileDetailDto, traitId, false, false);
				}
			}

		}
	}

	/**
	 * Read File Content to validate file header and content.
	 * @param fileDetailDto
	 * @param traitId
	 * @param flag
	 * @throws Exception
	 */
	private void readLargeFileContent(FileDetailDto fileDetailDto,
			String traitId, Boolean flag, Boolean isFromUI) throws Exception 
	{
		String temp = fileDetailDto.getFilePath();

		// CODE change for maintaining flow between UI and GCF Flow
		String blobNameLocal = null;
		String bucketObj = null;
		if(temp.startsWith(bucketnameInboundUi)){
			blobNameLocal = temp.substring(bucketnameInboundUi.length()+1, temp.length());
			bucketObj = bucketnameInboundUi;
		} else {
			blobNameLocal = temp.substring(bucketnameInbound.length()+1, temp.length());
			bucketObj = bucketnameInbound;
		}

		try (ReadChannel reader = storage.reader(bucketObj, blobNameLocal)) {
			long startTime = System.currentTimeMillis();
			List<String> traitInfoList = new ArrayList<>();
			Set<String> uniqueSocialIds = new HashSet<>(); //FOR SPRINT 5 UNIQUE ID's

			StringBuilder sb = readFileInChunks(reader);
			if(sb.toString().contains(",")){
				LOGGER.error("Invalid file, Contains multiple columns");
				throw new InvalidFileException(ConstantsUtil.INVALID_FILE_MULTIPLE_COLS);
			}
			String [] fileDataInArr = sb.toString().split(ConstantsUtil.NEWLINE_SEPARATOR);
			//Modified FOR SPRINT 5 store UNIQUE ID's
			processFileDataValidation(fileDataInArr, traitInfoList, isFromUI, uniqueSocialIds);	

			long endTime = System.currentTimeMillis();

			if(isFromUI) {
				//Code to update trait info and seq code, status when file uploaded from UI
				TraitDto traitDto = aamService.fetchTraitById(Integer.parseInt(traitId));
				updateTraitInfoInDatastore(fileDetailDto.getTimestamp(), 
						ConstantsUtil.VALIDATEFILE_SEQ_CODE, traitId, 
						ConstantsUtil.VALIDATEFILE_STATUS, traitDto, uniqueSocialIds.size());
			}
			else if(!CollectionUtils.isEmpty(traitInfoList) 
					&& traitInfoList.size() == 3) {

				//Code to update trait info and seq code, status when file uploaded from Storage
				if(!flag) {
					// CALL SERVICE TO CREATE TRAIT
					traitId = aamService.createTraitId(traitInfoList);
					aamService.reloadTraitsFromStorageFlow();	//Reload traits in Datastore
				}
				// Update in Datastore
				updateTraitInfoInDatastore(fileDetailDto.getTimestamp(), 
						ConstantsUtil.VALIDATEFILE_SEQ_CODE, traitId, 
						ConstantsUtil.VALIDATEFILE_STATUS, traitInfoList, uniqueSocialIds.size());

			} else {
				// THROW ERROR STATING INVALID FILE
				LOGGER.error("Invalid file headers, Please upload a valid file");
				throw new InvalidFileException(ConstantsUtil.INVALID_FILE_HEADER);
			}
			LOGGER.info("time taken {} ms", (endTime - startTime));
		} catch(Exception e){
			LOGGER.error("FileServiceImpl.readLargeFileContent: No such object{} ", e);
			setSequenceCode(fileDetailDto.getTimestamp(), 
					ConstantsUtil.ERROR_VALIDATEFILE_SEQ_CODE, 
					e.getMessage());
			throw e;
		}
	}

	/**
	 * This method will update trait id, trait info and set Sequence Code 
	 * appropriately, to keep track of processing.
	 * @param timestamp
	 * @param validatefileSeqCode
	 * @param traitId
	 * @param validatefileStatus
	 * @param traitDto
	 */
	private void updateTraitInfoInDatastore(Long timestamp, Integer seqCode, String traitId,
			String validatefileStatus, TraitDto traitDto, Integer uniqueSocialIds) {

		LOGGER.info("Updating Trait information in Datastore");

		QueryResults<Entity> result= fetchByStartTimestamp(timestamp);
		if(result.hasNext())
		{
			Key entityKey= result.next().getKey();						  
			Entity entity=Entity.newBuilder(datastore.get(entityKey))
					.set(ConstantsUtil.SEQ_CODE, seqCode) //setting the value of Sequence Code.
					.set(ConstantsUtil.STATUS, validatefileStatus)
					.set(ConstantsUtil.TRAIT_ID, traitId)
					.set(ConstantsUtil.TRAIT_NAME, traitDto.getName())
					.set(ConstantsUtil.TRAIT_DESC, traitDto.getDescription())
					.set(ConstantsUtil.TTL, traitDto.getTtl())
					.set(ConstantsUtil.INBOUND_CNT, uniqueSocialIds.toString())
					.build();
			datastore.put(entity);
		}	

	}

	/** Read file and appends in StringBuilder object
	 * @param reader
	 * @return
	 * @throws IOException
	 */
	private StringBuilder readFileInChunks(ReadChannel reader) throws IOException {

		LOGGER.info("Reading File");
		ByteBuffer byteBuffer = ByteBuffer.allocate(512 * 1024);

		StringBuilder sb = new StringBuilder(ConstantsUtil.BLANK_SPACE);
		while (reader.read(byteBuffer) > 0) {
			byteBuffer.flip(); 	//flip is used to prepare a buffer for get operation and makes it ready
			//rewind is used to read again the data it already contains. rewind sets the buffer position to zero

			Charset charset = Charset.forName("US-ASCII");
			CharBuffer charBuffer = charset.decode(byteBuffer);

			sb.append(charBuffer);

			byteBuffer.clear(); 
		}
		return sb;
	}

	/**
	 * This method will update trait id, trait info and set Sequence Code 
	 * appropriately, to keep track of processing.
	 * @param startTimeStamp
	 * @param sequenceCode
	 * @param traitId
	 * @param status
	 * @param traitInfoList
	 */
	private void updateTraitInfoInDatastore(Long timestamp, Integer sequenceCode, 
			String traitId, String status, List<String> traitInfoList, Integer uniqueSocialIds) {

		LOGGER.info("Updating Trait information in Datastore");

		QueryResults<Entity> result= fetchByStartTimestamp(timestamp);
		if(result.hasNext())
		{
			Integer ttl = ConstantsUtil.DEFAULT_TTL_VALUE;
			if(traitInfoList.get(2).trim().matches("\\d+") &&
					Integer.parseInt(traitInfoList.get(2).trim()) <= ConstantsUtil.MAX_TTL_LIMIT){

				ttl = Integer.parseInt(traitInfoList.get(2).trim());
			}
			Key entityKey= result.next().getKey();						  
			Entity entity=Entity.newBuilder(datastore.get(entityKey))
					.set(ConstantsUtil.SEQ_CODE, sequenceCode) //setting the value of Sequence Code.
					.set(ConstantsUtil.STATUS, status)
					.set(ConstantsUtil.TRAIT_ID, traitId)
					.set(ConstantsUtil.TRAIT_NAME, traitInfoList.get(0))
					.set(ConstantsUtil.TRAIT_DESC, traitInfoList.get(1))
					.set(ConstantsUtil.TTL, ttl)
					.set(ConstantsUtil.INBOUND_CNT, uniqueSocialIds.toString())
					.build();
			datastore.put(entity);
		}	
	}


	/** Adds file header to list for later processing.
	 * @param fileDataInArr
	 * @throws UnsupportedEncodingException 
	 */
	private void processFileDataValidation(String[] fileDataInArr,
			List<String> traitInfoList, Boolean isFromUI, Set<String> uniqueSocialIds) 
					throws UnsupportedEncodingException {
		int temp=0;
		LOGGER.info("Validate Headers and SocialIds present in file");
		for(String row: fileDataInArr){
			if(row == null ) {
				LOGGER.error("***** INCORRECT FILE FORMAT! Null Record");
				throw new InvalidFileException(ConstantsUtil.INCORRECT_FILE_FORMAT);
			}
			else if(row.length() < 1) {
				LOGGER.error("***** INCORRECT FILE FORMAT! Blank Record****");
				throw new InvalidFileException(ConstantsUtil.INCORRECT_FILE_FORMAT);
			}
			if( temp < 3 && !isFromUI){
				// SKIP First 3 rows
				temp = processFileHeaderRows(traitInfoList, temp, row);
			} 
			else {
				validateSocialIds(row, uniqueSocialIds);
			}
		}
	}

	/**
	 * @param row
	 */
	private void validateSocialIds(String row, Set<String> uniqueSocialIds) {

		if(row.startsWith(ConstantsUtil.SOCIAL_ID_PATTERN)){
			String [] truncatedRow = row.split(ConstantsUtil.SOCIAL_ID_PATTERN);
			if(null != truncatedRow && truncatedRow.length == 2){
				//match for digit
				if(!(truncatedRow[1].replaceAll("(\\r|\\n)", "").matches("\\d+"))) {
					LOGGER.error("***** INCORRECT FILE FORMAT! incorrect id SOCIAL ID *****");
					throw new InvalidFileException(ConstantsUtil.INCORRECT_FILE_SOCIAL_ID);
				}
			} else {
				LOGGER.error("***** INCORRECT FILE FORMAT! incorrect SOCIAL ID *****");
				throw new InvalidFileException(ConstantsUtil.INCORRECT_FILE_SOCIAL_ID);
			}
			uniqueSocialIds.add(row);
		} else {
			LOGGER.error("***** INCORRECT FILE FORMAT! incorrect SOCIAL ID *****");
			throw new InvalidFileException(ConstantsUtil.INCORRECT_FILE_SOCIAL_ID);
		}

	}

	/** Validate Trait Info rows present in file & prepare a list of it. 
	 * @param traitInfoList
	 * @param temp
	 * @param row
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	private int processFileHeaderRows(List<String> traitInfoList, int temp, String row) throws UnsupportedEncodingException {

		LOGGER.info("Processing File HeaderRows");
		if(row.contains(ConstantsUtil.SOCIAL_ID_PATTERN)){
			LOGGER.error("***** INCORRECT FILE FORMAT! Trait info not present *****");
			throw new InvalidFileException(ConstantsUtil.INCORRECT_FILE_TRAIT_INFO);
		} else if(temp == 0){
			byte[] b = row.getBytes("US-ASCII");	// Convert String to byte array
			// primitive byte array to List using LongStream Java 8
			List<Long> list = LongStream.range(0, b.length).map(i 
					-> b[(int) i]).boxed().collect(Collectors.toList());
			if( row.trim().length() > 255 || row.trim().length() < 1) {
				LOGGER.error("***** INCORRECT FILE FORMAT! Trait Name should be 0 to 255 characters *****");
				throw new InvalidFileException(ConstantsUtil.INCORRECT_FILE_TRAIT_NAME);
			} else if(row.contains("-") || row.contains("|") 
					|| row.contains("\t") || list.contains(63l)){
				// This checks for Special characters namely: hyphen, pipe, tab and dash 
				LOGGER.error("***** INCORRECT FILE FORMAT! Trait Name with special character *****");
				throw new InvalidFileException(
						ConstantsUtil.INCORRECT_FILE_TRAIT_WITH_SP_CHARS);
			}
		}
		traitInfoList.add(row);
		temp++;
		return temp;
	}

	/**
	 * Load the social_id in sample social_id table and build table schema
	 * @throws IOException 
	 * @throws InterruptedException 
	 */
	private void loadDataFromGCSToTable(FileDetailDto fileDetailDto) throws InterruptedException
	{

		TableId tableId = TableId.of(datasetName, ConstantsUtil.TABLE_NAME+fileDetailDto.getTimestamp());
		// Table field definition
		Field[] fields =
				new Field[] {
						Field.of("social_id", LegacySQLTypeName.STRING)
		};
		// Table schema definition
		Schema schema = Schema.of(fields);

		LoadJobConfiguration configuration =
				LoadJobConfiguration.builder(tableId, ConstantsUtil.SOURCEURI+fileDetailDto.getFilePath())
				.setFormatOptions(FormatOptions.csv())
				.setCreateDisposition(CreateDisposition.CREATE_IF_NEEDED)
				.setSchema(schema)
				.build();

		// Load the table
		JobInfo jobInfo = JobInfo.of(configuration);
		Job loadJob = bigQuery.create(jobInfo);
		loadJob = loadJob.waitFor();
		// Check the table
		LOGGER.info("INSERT called for SocialId table: State:{} ", loadJob.getStatus().getState());

		boolean isFromUi = getIsFromUI(fileDetailDto.getTimestamp());
		if (!isFromUi) {
			// i.e. not UI Flow so removing 1st three records
			String query = "Delete from `"+projectName+"."+datasetName+"."
					+ConstantsUtil.TABLE_NAME+fileDetailDto.getTimestamp()
					+"` where social_id IN (select * FROM `"+projectName+"."
					+datasetName+"."+ConstantsUtil.TABLE_NAME
					+fileDetailDto.getTimestamp()+"` Limit 3);";

			runQueryDelete(query);

			LOGGER.info("DELETE called to remove header rows "); 
		} 

	}

	/**
	 * Runs the join query and also put the result in a destination table
	 * @param query
	 */
	private TableResult runQuery(String query, Long
			timestamp) throws InterruptedException
	{
		LOGGER.info("Run join query and put the result in a destination table");
		QueryJobConfiguration queryConfig = QueryJobConfiguration.newBuilder(query)
				// Save the results of the query to a permanent table.
				.setDestinationTable(TableId.of(datasetName, ConstantsUtil.DESTINATION_TABLE+timestamp))
				.setUseLegacySql(false)
				.build();
		JobId jobId = JobId.of(UUID.randomUUID().toString());
		Job queryJob = bigQuery.create(JobInfo.newBuilder(queryConfig).setJobId(jobId).build());
		queryJob = queryJob.waitFor();
		return queryJob.getQueryResults();
	}
	/**
	 * Run delete query to remove null value from sample social id table
	 * @param query
	 */
	private void runQueryDelete(String query) throws InterruptedException
	{
		QueryJobConfiguration queryConfig = QueryJobConfiguration.newBuilder(query)
				.setUseLegacySql(false)
				.build();
		JobId jobId = JobId.of(UUID.randomUUID().toString());
		Job queryJob = bigQuery.create(JobInfo.newBuilder(queryConfig).setJobId(jobId).build());
		queryJob = queryJob.waitFor();
		LOGGER.info("Removed null values from social_id table {}",queryJob.isDone());
	}

	/**
	 * Put the Join Query Result in a CSV file and load this file to GCS bucket
	 * @param table
	 * @throws InterruptedException 
	 */
	private void putResultinGCS(Table table, String destTableName, 
			Long timestamp) throws InterruptedException
	{
		Job job = table.extract("CSV", ConstantsUtil.SOURCEURI+bucketnameOutbound
				+"/"+destTableName+ConstantsUtil.CSV_EXTN);
		// Wait for the job to complete
		try {
			Job completedJob =
					job.waitFor(
							RetryOption.initialRetryDelay(Duration.ofSeconds(1)),
							RetryOption.totalTimeout(Duration.ofMinutes(3)));
			if (completedJob != null && completedJob.getStatus().getError() == null) {
				LOGGER.info("Query Result Exported Successfully to GCS");
			} 
			else {
				LOGGER.info("Query Result Not Exported to GCS");
			}
		} catch (InterruptedException e) {
			LOGGER.error("FileServiceImpl.putResultinGCS{}", e);
			setSequenceCode(timestamp, 
					ConstantsUtil.ERROR_VALIDATEFILE_SEQ_CODE, 
					ConstantsUtil.ERROR_UPLOAD_FILE_GCS_STATUS);
			throw e;
		}
	}

	/**
	 * Fetch result from destination table
	 * @param query
	 */
	private TableResult fetchDestinationTable(String query) throws InterruptedException
	{
		QueryJobConfiguration queryConfig = QueryJobConfiguration.newBuilder(query)
				// Save the results of the query to a permanent table.
				.setUseLegacySql(false)
				.build();
		JobId jobId = JobId.of(UUID.randomUUID().toString());
		LOGGER.info("Fetching results from destination table");
		Job queryJob = bigQuery.create(JobInfo.newBuilder(queryConfig).setJobId(jobId).build());
		queryJob = queryJob.waitFor();
		return queryJob.getQueryResults();
	}
	/**
	 * Iterate over the Join Query ResultSet
	 * Add each adobe_uuid and traitId in StringBuilder obj
	 */
	private String iterateQueryResult(TableResult result, 
			Long startTimeStamp, Set<String> adobeUUIDSet) 
	{
		StringBuilder stringBuilder = new StringBuilder();
		String traitId = getTraitId(startTimeStamp);


		for (FieldValueList row : result.iterateAll()) {
			try {

				if(null !=row.get(ConstantsUtil.ADOBE_UUID).getValue()) {
					Object [] rowArr = row.toArray();
					FieldValue g =  (FieldValue)rowArr[0]; 
					g.getValue();
					//Added a COUNTER here to Check distinct Social Id's matching with Adobe Id
					if(adobeUUIDSet.add(row.get(ConstantsUtil.ADOBE_UUID).getStringValue())){

						stringBuilder.append(row.get(ConstantsUtil.ADOBE_UUID).getStringValue())
						.append(ConstantsUtil.TAB_SEPARATOR)
						.append(ConstantsUtil.TRAITID_PREFIX)
						.append(traitId)
						.append(ConstantsUtil.NEWLINE_SEPARATOR);
					}

				}
			} catch(NullPointerException exception) {
				LOGGER.warn("No matching adobe_uuid found for social_id {}:", row.get("social_id").getStringValue());
			}
		}

		if(adobeUUIDSet.size() < minThresholdForDistinctUUID) {
			LOGGER.error(ConstantsUtil.ERROR_UUID_AUID_MATCH_CNT);
			throw new InvalidFileException(ConstantsUtil.ERROR_UUID_AUID_MATCH_CNT);
		}
		return stringBuilder.toString();
	}

	/**
	 * Fetch TraitId from Datastore for a given timestamp
	 * @param startTimeStamp
	 * @return
	 */
	private String getTraitId(long startTimeStamp)
	{
		String traitId=null;

		QueryResults<Entity> result= fetchByStartTimestamp(startTimeStamp);
		if(result.hasNext())
		{
			Key entityKey = result.next().getKey();
			Entity retrieved = datastore.get(entityKey);
			traitId = retrieved.getString(ConstantsUtil.TRAIT_ID); //Make changes here
			LOGGER.info("TraitId retrieved from DataStore");
		}
		return traitId; 
	}

	/**
	 * Fetch TraitId from Datastore for a given timestamp
	 * @param startTimeStamp
	 * @return
	 */
	private boolean getIsFromUI(long startTimeStamp)
	{
		boolean isFromUi = false;

		QueryResults<Entity> result= fetchByStartTimestamp(startTimeStamp);
		if(result.hasNext())
		{
			Key entityKey = result.next().getKey();
			Entity retrieved = datastore.get(entityKey);
			if (retrieved.contains(ConstantsUtil.ISFROM_UI)) {
				isFromUi = retrieved.getBoolean(ConstantsUtil.ISFROM_UI);
			}
			LOGGER.info("TraitId retrieved from DataStore");
		}
		return isFromUi; 
	}

	/**
	 * Uploads file to intermediate bucket
	 * @param data
	 * @param bucketName
	 * @param timestamp
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	private String uploadSmallBlob(String data, String bucketName, Long timestamp) throws UnsupportedEncodingException
	{

		Bucket bucket4Upload = storage.get(bucketName);
		ByteArrayInputStream inputStream = new ByteArrayInputStream(
				data.getBytes(Constants.DEFAULT_ENCODING));
		bucket4Upload.create(ConstantsUtil.NI_INTERMEDIATE+timestamp+ConstantsUtil.CSV_EXTN, inputStream);
		LOGGER.info("File uploaded to Intermediate Storage");
		return "blob added";
	}

	/**
	 * Makes entry in Datastore for Audience file uploaded from UI
	 * @param originalFilename
	 * @param bucketnameUi
	 * @param traitId
	 * @throws Exception
	 */
	private void makeEntryInDataStore(String originalFilename, 
			String bucketnameUi, String destination, String 
			distributionType) throws Exception {

		String gcsFilePath = bucketnameUi + ConstantsUtil.FORWARD_SLASH + originalFilename;
		// CHANGE DISTRIBUTION COUNT HERE * OR CHANGE once file uploaded to S3

		//long startTimeStamp   storeFileDetailsInDatastore traitId, gcsFilePath, false)
		Long startTimeStamp = null;
		String inboundRecords = null;
		long distributionNo = 0l;
		QueryResults<Entity> result = fetchFileDetailsByFileName(originalFilename);
		if (result.hasNext()) {
			Entity entity = result.next();
			Key entityKey = entity.getKey();
			// Processing on result
			startTimeStamp = entity.getLong(ConstantsUtil.START_TIMESTAMP);
			inboundRecords = entity.getString(ConstantsUtil.INBOUND_CNT);
			if(entity.contains(ConstantsUtil.DISTRIBUTIONS)) {

				distributionNo = entity.getLong(ConstantsUtil.DISTRIBUTIONS) + 1;
				entity = Entity.newBuilder(datastore.get(entityKey))
						.set(ConstantsUtil.DISTRIBUTIONS, distributionNo)
						.set(ConstantsUtil.SEQ_CODE, ConstantsUtil.VALIDATEFILE_SEQ_CODE) //as file is already validated.
						.build();
				// * Incrementing Distribution count
				datastore.put(entity);
			}
		}

		//		NEED to fetch DH for given timestamp and identify if file was processed by Adobe earlier (check InboundAudFileName), IF yes 
		//Add a new record in DS with seq code =6 so it directly uploads file to S3 also read matched rec match rate and put it in the new rec
		QueryResults<Entity> result2 = fetchDHByStartTimestamp(
				startTimeStamp);
		boolean distFlag = true;
		while (result2.hasNext())
		{

			Entity entity = result2.next();
			if ((ConstantsUtil.DEST_ADOBE).equalsIgnoreCase(entity.getString(
					ConstantsUtil.DESTINATION)) && ConstantsUtil.FILE_DISTRIBUTED
					.equalsIgnoreCase(entity.getString(ConstantsUtil.STATUS))) {

				storeReDistributionDataInDS(originalFilename, destination
						, distributionType, distributionNo, entity);
				FileDetailDto fileDetailDto = new FileDetailDto();
				fileDetailDto.setFilePath(gcsFilePath);
				fileDetailDto.setTimestamp(startTimeStamp);
				uploadInboundFileToS3(fileDetailDto);

				distFlag = false;
				LOGGER.info("ReDistributionHistory performed");
				break;
			}
		}	

		// Storing entry in Distribution Datastore
		if (distFlag) {
			storeDistributionDataInDS(originalFilename, destination, 
					distributionType, inboundRecords, distributionNo, startTimeStamp);
			LOGGER.info("Entity added in Datastore");
			FileDetailPubDto fileDetailPubDto = createFileDetailPubDtoObj(gcsFilePath, startTimeStamp);
			LOGGER.info("gcsFilePath: {}", gcsFilePath);
			LOGGER.info("startTimeStamp: {}", startTimeStamp);
			publisherFunction(fileDetailPubDto);
		}
	}


	/**
	 * @param gcsFilePath
	 * @param startTimeStamp
	 * @return
	 */
	private FileDetailPubDto createFileDetailPubDtoObj(String gcsFilePath, Long startTimeStamp) {
		FileDetailPubDto fileDetailPubDto = new FileDetailPubDto();
		fileDetailPubDto.setFilepath(gcsFilePath);
		fileDetailPubDto.setStarttimestamp(startTimeStamp);
		return fileDetailPubDto;
	}

	/** 
	 * Stores fileDetails in Datastore
	 * @param traitId
	 * @param gcsFilePath
	 * @return
	 */
	private long storeFileDetailsInDatastore(Integer traitId, String gcsFilePath,
			Boolean expansion) {
		LOGGER.info("DS called");
		String expansionStatus = ConstantsUtil.BLANK_SPACE;
		// Create a Key factory to construct keys associated with this project.
		long startTimeStamp = Instant.now().toEpochMilli();
		KeyFactory keyFactory = datastore.newKeyFactory().setKind(ConstantsUtil.TASK);
		LOGGER.info(ConstantsUtil.KEY_FACTORY);
		Key key = datastore.allocateId(keyFactory.newKey());
		Entity task = Entity.newBuilder(key)
				.set(ConstantsUtil.SEQ_CODE, ConstantsUtil.START_SEQ_CODE) //setting the value of Sequence Code.
				.set(ConstantsUtil.STATUS, ConstantsUtil.IN_PROGRESS_STATUS)
				.set(ConstantsUtil.START_TIMESTAMP, startTimeStamp)
				.set(ConstantsUtil.GCS_FILEPATH, gcsFilePath)
				.set(ConstantsUtil.END_TIMESTAMP, ConstantsUtil.BLANK_SPACE)
				.set(ConstantsUtil.FEEDBACK_MSG, ConstantsUtil.BLANK_SPACE)
				.set(ConstantsUtil.USERNAME, ConstantsUtil.BLANK_SPACE)	// ADD USERNAME as per LOGGED IN USER
				.set(ConstantsUtil.TRAIT_ID, traitId.toString())
				.set(ConstantsUtil.TRAIT_NAME, ConstantsUtil.BLANK_SPACE)	// UPDATED IN LATER STAGE
				.set(ConstantsUtil.TRAIT_DESC, ConstantsUtil.BLANK_SPACE)	// UPDATED IN LATER STAGE
				.set(ConstantsUtil.TTL, ConstantsUtil.BLANK_SPACE)		// UPDATED IN LATER STAGE
				.set(ConstantsUtil.INTEGRATION_CODE, ConstantsUtil.BLANK_SPACE)	// UPDATED IN LATER STAGE
				.set(ConstantsUtil.INBOUND_CNT, ConstantsUtil.BLANK_SPACE)	// UPDATED IN LATER STAGE
				.set(ConstantsUtil.MATCHED_CNT, ConstantsUtil.BLANK_SPACE)	// UPDATED IN LATER STAGE
				.set(ConstantsUtil.INBOUND_AUD_FILENAME, ConstantsUtil.BLANK_SPACE)// UPDATED IN LATER STAGE
				.set(ConstantsUtil.EXPANSION_FLOW, expansion)	// Added for CYBG-153
				.set(ConstantsUtil.EXPANSION_STATUS, expansionStatus)
				.set(ConstantsUtil.DISTRIBUTIONS, ConstantsUtil.ZERO_VAL)
				.set(ConstantsUtil.ISFROM_UI, ConstantsUtil.BOOLEAN_TRUE)
				.build();
		datastore.put(task);
		return startTimeStamp;
	}

	/**
	 * Invokes Publisher with filepath and timestamp
	 * @param fileDetailPubDto
	 * @throws Exception
	 */
	private void publisherFunction(FileDetailPubDto 
			fileDetailPubDto) throws Exception	
	{
		LOGGER.info("Publisher Function ");
		ProjectTopicName projectTopicName = ProjectTopicName.of(projectName, 
				topicName);
		Publisher publisher = null;
		List<ApiFuture<String>> futures = new ArrayList<>();
		LOGGER.info("projectTopicName:{} ", projectTopicName.getProject());
		try {
			// Create a publisher instance with default settings bound to the topic
			publisher = Publisher.newBuilder(projectTopicName).build();
			LOGGER.info("publisher:{} ", publisher.getTopicName());
			ObjectMapper objectMapper = new ObjectMapper();
			String jsonMessageString = objectMapper.writeValueAsString(fileDetailPubDto);
			LOGGER.info("jsonMessageString:{} ", jsonMessageString);
			ByteString data = ByteString.copyFromUtf8(jsonMessageString);
			LOGGER.info("JSON Data formed");
			PubsubMessage pubsubMessage = PubsubMessage.newBuilder()
					.setData(data)
					.build();
			LOGGER.info("Pub Sub msg");
			ApiFuture<String> future = publisher.publish(pubsubMessage);
			LOGGER.info("Publisher publish called");
			futures.add(future);
			LOGGER.info("Added to futures");
		}
		finally {
			if (publisher != null) {
				publisher.shutdown();
			}
		}					
	}
	/**
	 * This method will set matchedAdobeRec and Sequence Code 
	 * to keep track of processing. 
	 * @param startTimeStamp
	 * @param sequenceCode
	 * @param status
	 */
	public void setSequenceCodeAndMatchedAdobeRec(long startTimeStamp, Integer sequenceCode, 
			String status, Integer matchedCnt) {

		QueryResults<Entity> result = fetchByStartTimestamp(startTimeStamp);
		long distributionNo = 0l;
		if(result.hasNext())
		{
			Entity entity = result.next();
			Key entityKey = entity.getKey();
			distributionNo = setDistributionNo(distributionNo, entity);						  
			entity = Entity.newBuilder(datastore.get(entityKey))
					.set(ConstantsUtil.SEQ_CODE, sequenceCode) //setting the value of Sequence Code.
					.set(ConstantsUtil.STATUS, status)
					.set(ConstantsUtil.MATCHED_CNT, matchedCnt.toString())
					.build();
			datastore.put(entity);
		}

		// Update DistributionHistory DS | CYBG 201,202
		updateDistributionHistoryWithMatchedCnt(startTimeStamp, sequenceCode, 
				status, distributionNo, matchedCnt);
	}

	/**Fetch Result by startTimestamp
	 * @param startTimeStamp
	 * @return
	 */
	private QueryResults<Entity> fetchByStartTimestamp(long startTimeStamp) {
		// Build the Query
		Query<Entity> query = Query.newEntityQueryBuilder()
				.setKind(ConstantsUtil.TASK)    //specify the task name - here it is 'Task'                                 
				.setFilter(PropertyFilter.eq(ConstantsUtil.START_TIMESTAMP, startTimeStamp))  //where clause - first parameter should match the column name in datastore.
				.build();
		return datastore.run(query);
	}

	@Override
	public ByteArrayOutputStream inboundFileDownloadFromS3Bucket(String keyName) {
		String bucketName = "demdex-s2s-clients/networkedinsights/date=2019-05-02";

		try {
			S3Object s3object = s3Client.getObject(new GetObjectRequest(bucketName, keyName));

			InputStream is = s3object.getObjectContent();
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			int len;
			byte[] buffer = new byte[4096];
			while ((len = is.read(buffer, 0, buffer.length)) != -1) {
				baos.write(buffer, 0, len);
			}

			return baos;
		} catch (IOException ioe) {
			LOGGER.error("IOException: ", ioe);
		} catch (AmazonServiceException ase) {
			LOGGER.error("AmazonServiceException from POST requests: Error Message: {} "
					, ase);
			throw ase;
		} catch (AmazonClientException ace) {
			LOGGER.error("Error Message: ", ace);
			throw ace;
		}

		return null;
	}


	@Override
	public Boolean storeValidateUploadFile(String fileName, 
			MultipartFile multipartFile, Integer traitId, Boolean expansion) {

		Boolean flag = false;
		try {
			String gcsFilePath = bucketnameInboundUi//"audience_expansion-cloud9-airflow" 
					+ ConstantsUtil.FORWARD_SLASH + fileName;

			// Store File details in Datastore. 3rd param for Expansion
			long startTimeStamp = storeFileDetailsInDatastore(traitId, gcsFilePath, expansion);
			LOGGER.info("startTimeStamp: {}",startTimeStamp);
			// Validate File
			FileDetailDto fileDetailDto = new FileDetailDto();
			fileDetailDto.setFilePath(gcsFilePath);
			fileDetailDto.setTimestamp(startTimeStamp);

			//		readLargeFileContent fileDetailDto, traitId toString , true, true 
			readLargeFileContent(fileDetailDto, traitId.toString(), true, true);
			//		boolean validateFlag  validateFile fileDetailDto 
			//		if  validateFlag   expansion   
			if (expansion) {
				// Upload file to the new bucket
				byte[] dataInBytes = multipartFile.getBytes();
				ByteArrayInputStream inputStream = new ByteArrayInputStream(
						dataInBytes);

				Storage storageObj = getStorageObj();
				BlobId blobId = null;
				LOGGER.info("File is:{}", fileName);
				if(projectName.contains("prod")) {
					LOGGER.info("BUCKET is:{}", airflowBucketProd);
					blobId = BlobId.of(airflowBucketProd, fileName);
				} else {
					LOGGER.info("BUCKET is:{}", airflowBucket);
					blobId = BlobId.of(airflowBucket, fileName);					
				}

				BlobInfo blobInfo = BlobInfo.newBuilder(blobId).setContentType("text/plain").build();
				LOGGER.info("Test: blobInfo: {}", blobInfo);	
				storageObj.create(blobInfo, inputStream);
				LOGGER.info("Test: File Uploaded to bucket:");

				// Update Expansion status once file is uploaded to Exp flow
				QueryResults<Entity> result= fetchByStartTimestamp(startTimeStamp);
				if(result.hasNext())
				{
					Entity entity = result.next();
					Key entityKey = entity.getKey();
					entity = Entity.newBuilder(datastore.get(entityKey))
							.set(ConstantsUtil.EXPANSION_STATUS, ConstantsUtil.EXPANSION_PENDING)
							.build();
					datastore.put(entity);
				}
				flag = true;
			}
			return flag;

		} catch(InvalidFileException e) {
			LOGGER.error("InvalidFileException");
			throw e;
		}
		catch (Exception e) {
			LOGGER.error(
					"FileServiceImpl.storeValidateUploadFile(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());

			throw new NIDmpException(
					"FileServiceImpl.storeValidateUploadFile(): {} , Error MEssage: {}", e);
		}
	}


	/**
	 * @return
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	private Storage getStorageObj() throws IOException {
		LOGGER.info("getStorageObj called");
		StorageOptions options = StorageOptions.newBuilder()
				.setProjectId(projectName)
				.setCredentials(GoogleCredentials.fromStream(
						new FileInputStream(pathToJsonKey))).build();
		LOGGER.info("StorageOptions: {}", options.getProjectId());
		return options.getService();
	}


	@Override
	public void pushSubscriberPubSubData(PubSubAttributesDto dto,
			Long tmstp) {

		try {
			if ( null != dto) {
				QueryResults<Entity> result = fetchFileDetailsByFileName(dto.getJobId());

				if(result.hasNext())
				{
					// Update Datastore with Audience expansion details,
					// bq_datset and gcs_file_loc
					Entity entity = result.next();
					Key entityKey = entity.getKey();
					LOGGER.info("Get Result entityKey");
					if (ConstantsUtil.BLANK_SPACE.equals(dto.getError())) {
						// Case: When Pub/Sub returns bigQuery Dataset and 
						// Gcs Plot location value	
						LOGGER.info("Inside IF Update Entity:");
						entity = updateDatastoreWhenNoError(dto, tmstp, entity, entityKey);

					} else {
						LOGGER.info("Entity object set Error:{}",dto.getError());
						// Case: When Pub/Sub returns some Error.
						entity = Entity.newBuilder(datastore.get(entityKey))
								.set(ConstantsUtil.ERROR, dto.getError())
								.set(ConstantsUtil.EXPANSION_STATUS, dto.getStatus())
								.build();

					}
					// Updating BqDataset and GcsPlot location 
					// or Error info in FileSetails Datastore.
					LOGGER.info("Entity object set");
					datastore.put(entity);
					LOGGER.info("After Update Entity:");
				}	
			}
		} catch (Exception e) {
			LOGGER.error(
					"FileServiceImpl.pushSubscriberPubSubData(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());

			throw new NIDmpException(
					"FileServiceImpl.pushSubscriberPubSubData(): {} , Error MEssage: {}", e);

		}
	}


	/**
	 * @param dto
	 * @param tmstp
	 * @param entity
	 * @param entityKey
	 * @return
	 */
	private Entity updateDatastoreWhenNoError(PubSubAttributesDto dto, Long tmstp, Entity entity, Key entityKey) {
		if(entity.contains(ConstantsUtil.PUBLISH_TIME))
		{
			LOGGER.info("Comparing Publish time");
			Long tmp = entity.getLong(ConstantsUtil.PUBLISH_TIME);

			if(tmp < tmstp) {
				LOGGER.info("Comparing PublishTime tmp<tmstp=true");

				entity = Entity.newBuilder(datastore.get(entityKey))
						.set(ConstantsUtil.BIGQUERY_DATASET, dto.getBqDataset())
						.set(ConstantsUtil.GCS_PLOTLOCATION, dto.getUpliftPlotLoc())
						.set(ConstantsUtil.EXPANSION_STATUS, dto.getStatus())
						.set(ConstantsUtil.PUBLISH_TIME, tmstp)
						.set(ConstantsUtil.ERROR, dto.getError())
						.build();

			}
		} else {
			LOGGER.info("Comparing PublishTime tmp<tmstp=false");

			// First time entry for Pull Subs
			entity = Entity.newBuilder(datastore.get(entityKey))
					.set(ConstantsUtil.BIGQUERY_DATASET, dto.getBqDataset())
					.set(ConstantsUtil.GCS_PLOTLOCATION, dto.getUpliftPlotLoc())
					.set(ConstantsUtil.EXPANSION_STATUS, dto.getStatus())
					.set(ConstantsUtil.PUBLISH_TIME, tmstp)
					.build();
		}
		return entity;
	}


	/**
	 * @param dto
	 * @return
	 */
	private QueryResults<Entity> fetchFileDetailsByFileName(String jobId) {
		String filePath = null;
		if(null != jobId && jobId.contains(ConstantsUtil.CSV_EXTN)) {
			filePath = bucketnameInboundUi + ConstantsUtil.FORWARD_SLASH 
					+ jobId;
		} else {
			filePath = bucketnameInboundUi + ConstantsUtil.FORWARD_SLASH 
					+ jobId + ConstantsUtil.CSV_EXTN;
		}

		LOGGER.info("Filepath: {}", filePath);
		// Fetch existing Datastore entry for a filename
		StructuredQuery<Entity> query = Query.newEntityQueryBuilder()
				.setKind(ConstantsUtil.TASK)
				.setFilter(PropertyFilter.eq(ConstantsUtil.GCS_FILEPATH, filePath))
				.build();
		return datastore.run(query);
	}


	@Override
	public byte[] getHtmlFile(String fileName) {
		ClassLoader classLoader = getClass().getClassLoader();
		try (InputStream inputStream = classLoader.getResourceAsStream(fileName)) {

			ByteArrayOutputStream bufferObj = new ByteArrayOutputStream();
			byte[] data = new byte[1024];
			int xRead;
			while ((xRead = inputStream.read(data, 0, data.length)) != -1) {
				bufferObj.write(data, 0, xRead);
			}
			bufferObj.flush();
			return bufferObj.toByteArray();

		} catch (IOException e) {
			LOGGER.error(
					"FileServiceImpl.getHtmlFile(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());

			throw new NIDmpException(
					"FileServiceImpl.getHtmlFile(): {} , Error MEssage: {}", e);
		}
	}


	@Override
	public byte [] uploadUpliftHtmlFile(String fileName) {
		byte [] byteArr = null;
		QueryResults<Entity> result = fetchFileDetailsByFileName(fileName);
		while (result.hasNext()) {
			Entity entity = result.next();
			// Processing on result
			if (entity.contains(ConstantsUtil.GCS_PLOTLOCATION) && 
					null != entity.getString(ConstantsUtil.GCS_PLOTLOCATION)) {

				String upliftFileLoc = entity.getString(
						ConstantsUtil.GCS_PLOTLOCATION);
				if (null == upliftFileLoc){
					return byteArr;
				} 
				if (!upliftFileLoc.startsWith(ConstantsUtil.SOURCEURI)) {
					return byteArr;
				}
				upliftFileLoc = upliftFileLoc.substring(5, upliftFileLoc.length());
				String [] upliftArr = upliftFileLoc.split(
						ConstantsUtil.FORWARD_SLASH);
				StringBuilder bucketName = formingBucketName(upliftArr);
				LOGGER.info("Before StorageObj");
				// Read file from the specified location

				Storage storageObj = null;
				try {
					storageObj = getStorageObj();
				} catch (Exception e) {
					LOGGER.error(
							"FileServiceImpl.uploadUpliftHtmlFile() : {}, Error MEssage: {}",
							e.getClass().getName(), e.getMessage());
					throw new NIDmpException(
							"FileServiceImpl.uploadUpliftHtmlFile() : {}, Error MEssage: {}", e);
				}

				try (ReadChannel reader = storageObj.reader(bucketName.substring(0, bucketName.length()-1), 
						upliftArr[upliftArr.length-1])) {
					byteArr = readHtmlDataFromUpliftPath(upliftArr, reader);
					return byteArr;

				} catch (Exception e) {
					LOGGER.error(
							"FileServiceImpl.uploadUpliftHtmlFile(): {} , Error MEssage: {}",
							e.getClass().getName(), e.getMessage());
					throw new NIDmpException(
							"FileServiceImpl.uploadUpliftHtmlFile(): {} , Error MEssage: {}", e);
				}
			}
		}
		return byteArr;
	}


	/**
	 * @param upliftArr
	 * @return
	 */
	private StringBuilder formingBucketName(String[] upliftArr) {
		StringBuilder bucketName = new StringBuilder();
		for(int i = 0; i < upliftArr.length-1; i++) {

			bucketName.append(upliftArr[i]).append(
					ConstantsUtil.FORWARD_SLASH);
		}
		return bucketName;
	}


	/**
	 * @param upliftArr
	 * @param reader
	 * @return
	 * @throws IOException
	 * @throws UnsupportedEncodingException
	 */
	private byte[] readHtmlDataFromUpliftPath(String[] upliftArr, ReadChannel reader)
			throws IOException {
		byte[] byteArr;
		long startTime = System.currentTimeMillis();

		LOGGER.info("Before readFileInchunks");
		StringBuilder sb = readFileInChunks(reader);

		long endTime = System.currentTimeMillis();
		LOGGER.info("Time taken to read file from Intermediate storage{} ms", (endTime - startTime));
		String stringBuilder2 = sb.toString().trim();

		LOGGER.info("File read successfully");
		// Store the file in Storage of ni dmp project 
		// Need changes for Prod env
		Bucket bucket4Upload = null;
		if(projectName.contains("prod")) {
			bucket4Upload = storage.get(inboundBucketUpliftProd);
		} else {
			bucket4Upload = storage.get(inboundBucketUpliftDev);
		}

		LOGGER.info("Get storage");
		ByteArrayInputStream inputStream = new ByteArrayInputStream(
				stringBuilder2.getBytes(Constants.DEFAULT_ENCODING));
		bucket4Upload.create(upliftArr[upliftArr.length-1], inputStream);
		LOGGER.info("File uploaded to DMP Storage.");
		byteArr = String.valueOf(sb).getBytes();
		return byteArr;
	}


	@Override
	public String pullSub() {

		LOGGER.info("Inside Process Message function");
		//Variable that defines how many message to pull at once
		int numOfMessages = 1;
		//Build an SubscriberStubSettings object that would help in pulling the message

		SubscriberStubSettings subscriberStubSettings = null;
		try {
			subscriberStubSettings = buildSubscriberStubSettingsObj();
		} catch (Exception e) {
			LOGGER.error(
					"FileServiceImpl.pullSub() : {} , Error Message: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"FileServiceImpl.pullSub() : {} , Error Message: {}", e);
		}
		//Create a SubscriberStub which would send the pull request
		try (SubscriberStub subscriber = GrpcSubscriberStub.create(subscriberStubSettings))
		{
			//Fetch pub/sub subscription name from project
			String subscriptionName = setSubscriptionName();
			//Build a pull request
			LOGGER.info("subscriptionName: {} ", subscriptionName);
			PullRequest pullRequest =PullRequest.newBuilder()
					.setMaxMessages(numOfMessages)
					.setReturnImmediately(true)
					.setSubscription(subscriptionName)
					.build();

			LOGGER.info("Pull Request");
			// Send Synchronous Pull request and get the pull response
			PullResponse pullResponse = subscriber.pullCallable().call(pullRequest);
			LOGGER.info("Pull Response");
			//Get message count in pull response
			int getReceivedMessagesCount = pullResponse.getReceivedMessagesCount();
			LOGGER.info("Pull response data: {} ", getReceivedMessagesCount);
			//Condition will be true if any message retrieved from subscription
			if(getReceivedMessagesCount!=0)
			{
				LOGGER.info("Inside IF: {} ", getReceivedMessagesCount);
				processPullSubscriberData(pullResponse);
			}
		}catch(Exception e){
			LOGGER.error(
					"FileServiceImpl.pullSub (): {}, Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"FileServiceImpl.pullSub (): {}, Error MEssage: {}", e);
		}

		return "success";
	}


	/**
	 * @return
	 */
	private String setSubscriptionName() {
		String subscriptionName = null;
		if(projectName.contains("prod")) {
			subscriptionName = ProjectSubscriptionName.format(cloud9AirflowProd, 
					cloud9AirflowSubsProd);
		} else {
			subscriptionName = ProjectSubscriptionName.format(cloud9AirflowDev, 
					cloud9AirflowSubsDev);
		}
		return subscriptionName;
	}

	/**
	 * set Subscription for Pii Matcher
	 * @return
	 */
	private String setSubscriptionForPii() {
		LOGGER.info("setSubscriptionForPii");
		String subscriptionName = null;
		if(projectName.contains("prod")) {
			subscriptionName = ProjectSubscriptionName.format(cloud9AirflowProd, 
					piiMatcherSubsProd);
		} else {
			subscriptionName = ProjectSubscriptionName.format(cloud9AirflowDev, 
					piiMatcherSubsDev);
		}
		return subscriptionName;
	}


	/**
	 * @param subscriberStubSettings
	 * @return
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	private SubscriberStubSettings buildSubscriberStubSettingsObj() 
			throws IOException {

		SubscriberStubSettings subscriberStubSettings = null;

		GoogleCredentials credentials = GoogleCredentials.fromStream(
				new FileInputStream(pathToJsonKey));
		LOGGER.info("credentials: {}", credentials);
		subscriberStubSettings = SubscriberStubSettings.newBuilder()
				.setCredentialsProvider(FixedCredentialsProvider.create(credentials)).build();
		LOGGER.info("subscriberStubSettings: {} ", subscriberStubSettings);

		return subscriberStubSettings;
	}


	/**
	 * This method will process Pull Subscriber
	 * data and call Rest service to store 
	 * the data in Datastore for future use.
	 * @param pullResponse
	 * @throws IOException 
	 */
	private void processPullSubscriberData(PullResponse pullResponse) throws IOException {

		List<ReceivedMessage> msgList =  pullResponse.getReceivedMessagesList();
		//Iterate over list containing messages (1 iteration will happen)
		for(ReceivedMessage msg : msgList)
		{
			//Get the actual message from pub/sub
			PubsubMessage message = msg.getMessage();
			Map<String, String> attributeMap = message.getAttributes();
			String json = attributeMap.toString();
			LOGGER.info("Attributes: {}", json);
			LOGGER.info("GetPublishTime: {} ", message.getPublishTime());
			LOGGER.info("getMessageId: {} ", message.getMessageId());

			PubSubAttributesDto dto = populatePubSubAttributesDto(attributeMap);

			// Store PullSubscriberData in Datastore
			pushSubscriberPubSubData(dto, message.getPublishTime().getSeconds());

			// acknowledging the message otherwise Pull subscriber 
			// will be called again and again
			acknowledgeSubscribedMessage(pullResponse);
			LOGGER.info("Subscribed message Acknowledged");
		}
	}

	/**
	 * This method will process Pull Subscriber
	 * data and call Rest service to store 
	 * the data in Datastore for future use.
	 * @param pullResponse
	 * @throws IOException 
	 * @throws InterruptedException 
	 */
	private void processPiiPullSubscriberData(PullResponse pullResponse) throws IOException, InterruptedException {

		List<ReceivedMessage> msgList =  pullResponse.getReceivedMessagesList();
		//Iterate over list containing messages (1 iteration will happen)
		for(ReceivedMessage msg : msgList)
		{
			//Get the actual message from pub/sub
			PubsubMessage message = msg.getMessage();
			Map<String, String> attributeMap = message.getAttributes();
			String json = attributeMap.toString();
			LOGGER.info("Pii Attributes: {}", json);
			LOGGER.info("Pii GetPublishTime: {} ", message.getPublishTime());
			LOGGER.info("Pii getMessageId: {} ", message.getMessageId());

			PiiPubSubAttributesDto dto = populatePiiPubSubAttributesDto(attributeMap);
			LOGGER.info("Pii populatePiiPubSubAttributesDto");
			// Store PullSubscriberData in Datastore
			pushSubscriberPiiPubSubData(dto, message.getPublishTime().getSeconds());

			// acknowledging the message otherwise Pull subscriber 
			// will be called again and again
			acknowledgeSubscribedMessageForPii(pullResponse);
			LOGGER.info("Subscribed message Acknowledged for pii");
		}
	}


	private void pushSubscriberPiiPubSubData(PiiPubSubAttributesDto dto,
			Long tmstp) throws InterruptedException {

		// Storing in Datastore to access jobStats info later for Ni leads
		LOGGER.info("pushSubscriberPiiPubSubData tmstp:{}", tmstp);
		if ( null != dto) {
			LOGGER.info("inside pushSubscriberPiiPubSubData"
					+ ".getJobId:{}", dto.getJobId());
			QueryResults<Entity> result = fetchDetailsByJobId(dto.getJobId());

			if (result.hasNext()) {
				// Seed list flow
				LOGGER.info("Result found for fetchDetailsByJobId()");
				Entity entity = result.next();
				Key entityKey = entity.getKey();
				updateInDatastore(dto, entityKey, 
						entity.getString(ConstantsUtil.DISTRIBUTION_TYPE));

			} else {
				LOGGER.info("Inside else of pushSubscriberPiiPubSubData");
				QueryResults<Entity> result2 = fetchDetailsByJobIdExpFlow(dto.getJobId());
				if (result2.hasNext()) {
					// Expansion flow
					LOGGER.info("Result found for fetchDetailsByJobIdExpFlow()");
					Entity entity2 = result2.next();
					Key entityKey2 = entity2.getKey();
					updateInDatastore(dto, entityKey2, 
							entity2.getString(ConstantsUtil.DISTRIBUTION_TYPE),
							entity2.getLong(ConstantsUtil.START_TIMESTAMP));

				} else {
					// Job Id is not valid or not present in DH and EDH
					// send mail with jobId = null

					ErrorEmaiForNullJobId(dto);
					LOGGER.info("Job Id Not present in DH and EDH ");

				}
			}

		}
	}

	/**
	 * Seed List
	 * @param dto
	 * @param entity
	 * @param entityKey
	 */
	private void updateInDatastore(PiiPubSubAttributesDto dto, 
			Key entityKey, String distributionType) {
		if (ConstantsUtil.PROCESSING_COMPLETED
				.equalsIgnoreCase(dto.getStatus())) {
			LOGGER.info("Status is Completed");

			processingForCompletedStatus(dto, entityKey, distributionType);

		} 
		else if(ConstantsUtil.EXP_ERROR 
				.equalsIgnoreCase(dto.getStatus()))
		{
			LOGGER.info("Status is error");
			createContentsForErrorEmail(dto);
		}
		else {
			LOGGER.info("Status is pending or processing ");
			Entity entity = Entity.newBuilder(datastore.get(entityKey))
					.set(ConstantsUtil.STATUS, dto.getStatus())
					//.set(ConstantsUtil.SEQ_CODE, ConstantsUtil.OUTBOUND_FILE_FOR_GCS_SEQ_CODE)
					//.set(ConstantsUtil.MATCHED_CNT, adobeuuidCount)
					.build();
			datastore.put(entity);

		}
	}

	/**
	 * Expansion flow
	 * @param dto
	 * @param entity
	 * @param entityKey
	 * @throws InterruptedException 
	 */
	private void updateInDatastore(PiiPubSubAttributesDto dto, 
			Key entityKey, String distributionType, Long startTmstmp) throws InterruptedException {
		if (ConstantsUtil.PROCESSING_COMPLETED
				.equalsIgnoreCase(dto.getStatus())) {
			LOGGER.info("Status is Completed");

			// Code changes for comments in CYBG 286 | storing matched records
			processingForCompletedStatus(dto, entityKey, distributionType);

		}
		else if(ConstantsUtil.EXP_ERROR 
				.equalsIgnoreCase(dto.getStatus()))
		{
			LOGGER.info("Status is error");
			createContentsForErrorEmail(dto);
		}
		else {
			LOGGER.info("Status other than Completed");

			// Finding inbound count for Processing status
			if (ConstantsUtil.PROCESSING
					.equalsIgnoreCase(dto.getStatus())) {
				String inboundRec = "";
				if (startTmstmp > 0l) {
					String countRecordsQuery = "SELECT DISTINCT count(*) "
							+ "FROM "
							+"`"+projectName+ConstantsUtil.POINT+
							datasetName+ConstantsUtil.POINT+
							ConstantsUtil.NILEADS_TABLE+startTmstmp+"`;"; 
					LOGGER.info("countRecords: {}",countRecordsQuery);
					TableResult result = fetchDestinationTable(countRecordsQuery);
					LOGGER.info("countRecords after Table result");
					inboundRec = findCountOfInboundRecords(result);
					LOGGER.info("InboundRec count: {}", inboundRec);
				}
				Entity entity = Entity.newBuilder(datastore.get(entityKey))
						.set(ConstantsUtil.STATUS, dto.getStatus())
						.set(ConstantsUtil.INBOUND_CNT, inboundRec)
						.build();
				datastore.put(entity);
			} else {
				// Pending status
				Entity entity = Entity.newBuilder(datastore.get(entityKey))
						.set(ConstantsUtil.STATUS, dto.getStatus())
						.build();
				datastore.put(entity);
			}
		}
	}

	/**
	 * @param dto
	 * @param entityKey
	 * @param distributionType
	 */
	private void processingForCompletedStatus(PiiPubSubAttributesDto dto, Key entityKey, String distributionType) {
		String matchCount = "";
		if(null != dto.getCountValidEmails()) {
			matchCount = dto.getCountValidEmails();				
		} else if (null != dto.getOutputRecords()) {
			matchCount = dto.getOutputRecords();
		}

		Entity entity = Entity.newBuilder(datastore.get(entityKey))
				.set(ConstantsUtil.STATUS, dto.getStatus())
				//.set(ConstantsUtil.OUTPUTBUCKET, (null!=dto.getOutputBucket()) ? dto.getOutputBucket():"")
				.set(ConstantsUtil.OUTPUTBUCKET, dto.getOutputBucket())
				.set(ConstantsUtil.OUTPUTPREFIX, dto.getOutputPrefix())
				.set(ConstantsUtil.MATCHED_CNT, matchCount)
				.set(ConstantsUtil.SEQ_CODE, ConstantsUtil.COMPLETED_CODE)
				.build();
		datastore.put(entity);

		// Code changes for comments in CYBG 286 | storing data for diff dist types
		if (ConstantsUtil.EMAIL.equalsIgnoreCase(distributionType) ||
				ConstantsUtil.ALL_MAIL.equalsIgnoreCase(distributionType)) {
			updateNiLeadsJobStats(dto);
			emailBodyAllMailEmail(distributionType,dto);			
		} else if (ConstantsUtil.PHONE.equalsIgnoreCase(distributionType)) {
			updateNiLeadsJobStatsForPhone(dto);
			emailBodyPhone(distributionType,dto);
		} else if (ConstantsUtil.DIRECT_MAIL.equalsIgnoreCase(distributionType)) {
			updateNiLeadsJobStatsForDirectMail(dto);
			emailBodyDirectMail(distributionType,dto);
		}
	}

	private String getTraitName(PiiPubSubAttributesDto dto){
		Entity entity1 = null;
		Entity entity2 = null;
		Entity entity3 = null;
		String fileName = null;
		String traitName = null;
		
		QueryResults<Entity> result1 = fetchDetailsByJobId(dto.getJobId());
		if (result1.hasNext()) {
			// Distribute flow
			LOGGER.info("Result found for fetchDetailsByJobId()");
			entity1 = result1.next();
			fileName = entity1.getString(ConstantsUtil.FILENAME);			
		}else{
			QueryResults<Entity> result2 = fetchDetailsByJobIdExpFlow(dto.getJobId());
			if (result2.hasNext()) {
				// Expansion flow
				LOGGER.info("Result found for fetchDetailsByJobIdExpFlow");
				entity2 = result2.next();
				fileName = entity2.getString(ConstantsUtil.FILENAME);	
		}				
		}
		
		LOGGER.info("File name is:{}",fileName);
		QueryResults<Entity> result3=fetchFileDetailsByFileName(fileName);
		if (result3.hasNext()) {
			entity3 = result3.next();
			traitName = entity3.getString(ConstantsUtil.TRAIT_NAME);
		}
		return traitName;
	}
	private StringBuilder createCommonMailBody(String distributionType, PiiPubSubAttributesDto dto){
		Entity entity1 = null;
		Entity entity2 = null;
		String fileName = null;
		String inboundCount = null;
		String matchedCount = null;
		String piiBucket = null;
		StringBuilder sb = new StringBuilder();
		URL gsBucket = null;
		
		//file name
		QueryResults<Entity> result1 = fetchDetailsByJobId(dto.getJobId());
		if (result1.hasNext()) {
			// Distribute flow
			LOGGER.info("Result found for fetchDetailsByJobId");
			entity1 = result1.next();
			fileName = entity1.getString(ConstantsUtil.FILENAME);
			inboundCount = entity1.getString(ConstantsUtil.INBOUND_CNT);
			matchedCount = entity1.getString(ConstantsUtil.MATCHED_CNT);
		}else{
			QueryResults<Entity> result2 = fetchDetailsByJobIdExpFlow(dto.getJobId());
			if (result2.hasNext()) {
				// Expansion flow
				LOGGER.info("Result found for fetchDetailsByJobIdExpFlow");
				entity2 = result2.next();
				fileName = entity2.getString(ConstantsUtil.FILENAME);
				inboundCount = entity2.getString(ConstantsUtil.INBOUND_CNT);
				matchedCount = entity2.getString(ConstantsUtil.MATCHED_CNT);
			}
		}
		
		//GS bucket location 
		if(projectName.contains("prod")) {
			piiBucket = piiMatcherBucketProd;
		} else {
			piiBucket = piiMatcherBucketDev;
		}
		
		try {
			// Added changes as per Davids comment and tkt CYBG
			String outputPrefix = dto.getOutputPrefix();
			outputPrefix = outputPrefix.replace("-*.csv", "-000000000000.csv");
			gsBucket = new URL(ConstantsUtil.GS_BASEURL+dto.getOutputBucket()
			+"/"+outputPrefix);
			
		} catch (MalformedURLException e) {
			LOGGER.error("FileServiceImpl.createCommonMailBody {}", e.getMessage());
			throw new NIDmpException(
					"FileServiceImpl.createCommonMailBody(): {} , Error Message: {}", e);
		}
		
		//match rate		

		Integer matchRate = null;
     String matchRate1 = null;
		if (null != inboundCount && inboundCount.trim().matches(ConstantsUtil.DIGIT_PATTERN_REGEX)
				&& null != matchedCount && matchedCount.trim().matches(ConstantsUtil.DIGIT_PATTERN_REGEX)) {

			matchRate = (int) Math.round(
					(Double.parseDouble(matchedCount.trim()) / Double.parseDouble(inboundCount.trim())) * 100);
		}
		
	if(matchRate != null)
		{
		matchRate1=matchRate + "%";

		}else
		{
			 matchRate1 = Integer.toString(matchRate);
		}
		
		//audience trait name 
		String traitName = getTraitName(dto);
		

		String distributionType1= distributionType.substring(0,1).toUpperCase();
	 distributionType= distributionType.substring(1);
	  distributionType=distributionType1.concat(distributionType);

		sb.append("Hello,\nYour file " + fileName
				+ " for the audience "+traitName+" has been successfully processed"
				+ " and is available for download at the URL below:\n\n"+gsBucket
				+ "\n\nJob stats:\n\n* Audience: "+traitName+"\n* Job type: " + distributionType
				+ "\n* Count of input records: " + inboundCount + "\n* Count of de-duped output records: "
				+ matchedCount + "\n* Calculated Match rate: " + matchRate1);
		
		return sb;
	}

	private void emailBodyAllMailEmail(String distributionType, PiiPubSubAttributesDto dto) {
		
		// mail body
		StringBuilder mailBody = createCommonMailBody(distributionType,dto);
		StringBuilder sb = mailBody.append("\n\nEmail Validation results:\n\n* Valid: " + dto.getValid() + "\n* Invalid: " + dto.getInvalid()
		+ "\n* Catch-all: " + dto.getCatchAll() + "\n* Unknown: " + dto.getUnknown() + "\n* Spamtrap: "
		+ dto.getSpamtrap() + "\n* Abuse: " + dto.getAbuse() + "\n* Do not Mail: " + dto.getDoNotMail()
		+ "\n* Credits Remaining: " + dto.getCreditsRemaining());
		
		// mail subject
		String subject = ConstantsUtil.LEADS_FILE_AVAILABLE+getTraitName(dto);
		
		// send email
		sendEmailNotification(subject, sb);

	}

	private void emailBodyPhone(String distributionType,PiiPubSubAttributesDto dto){
		// mail body
		StringBuilder mailBody = createCommonMailBody(distributionType,dto);
		StringBuilder sb = mailBody.append("\n* Scrubbed from DNC: "+dto.getDncRemoved());

		// mail subject
		String subject = ConstantsUtil.LEADS_FILE_AVAILABLE+getTraitName(dto);
		
		// send email
		sendEmailNotification(subject, sb);

	}

	private void emailBodyDirectMail(String distributionType,PiiPubSubAttributesDto dto){
		// mail body
		StringBuilder mailBody = createCommonMailBody(distributionType,dto);
		
		// mail subject
		String subject = ConstantsUtil.LEADS_FILE_AVAILABLE+getTraitName(dto);
		
		// send email
		sendEmailNotification(subject, mailBody);
	}

	private void createContentsForErrorEmail(PiiPubSubAttributesDto dto){
		Entity entity = null;
		StringBuilder sb = new StringBuilder();
		QueryResults<Entity> result = fetchDetailsByJobId(dto.getJobId());
		if (result.hasNext()) {
			LOGGER.info("Result found for fetchDetailsByJobId");
			entity = result.next();
			String filename=entity.getString(ConstantsUtil.FILENAME);
			LOGGER.info("File name is : {}",filename);
			QueryResults<Entity> result1=fetchFileDetailsByFileName(filename);
			if (result1.hasNext()) {
				Entity entity1 = result1.next();

				sb.append("Hello").append( ConstantsUtil.COMMA_DEL).append(ConstantsUtil.NEWLINE_SEPARATOR).append(ConstantsUtil.NEWLINE_SEPARATOR).append(ConstantsUtil.NEWLINE_SEPARATOR).append("Your file ").append(filename) 
				.append(" for the audience ").append(entity1.getString(ConstantsUtil.TRAIT_NAME)).append(" has encountered an error. ")
				.append( " Please log into Logistics for more details and resubmit.");

				sendEmailNotification(ConstantsUtil.LEADS_FILE_AVAILABLE+entity1.getString(ConstantsUtil.TRAIT_NAME), sb);

			}
		}
	}
	private void ErrorEmaiForNullJobId(PiiPubSubAttributesDto dto)
	{
		StringBuilder sb = new StringBuilder();
		LOGGER.info("For Job id is Not valid");
		sb.append("Hello").append( ConstantsUtil.COMMA_DEL).append(ConstantsUtil.NEWLINE_SEPARATOR).append("JobId ").append(dto.getJobId()).append(" is incorrect or is not present in our datastore.")
		.append("Please log into Logistics for more details and resubmit.");
				
		sendEmailNotification("Leads file available for ", sb);

	}



	private void sendEmailNotification(String subject, StringBuilder text){
		try {
			LOGGER.info("Send email notification");
			HttpResponse<String> response = Unirest.post("https://api.mailgun.net/v3/"
					+mailgunDomain+"/messages")
					.basicAuth("api", mailgunApikey)
					.field("from", mailgunFromEmail)
					.field("to", mailgunToEmail)
					.field("subject", subject)
					.field("text", text).asString();

			if(response.getStatus() == 200){
				LOGGER.info("Email sent successfully");
			}else{
				LOGGER.info("Email delivery has failed with response: {},{}",response.getStatus(),response.getStatusText());
			}
		} catch (Exception e) {
			LOGGER.error("FileServiceImpl.sendEmailNotification {}", e.getMessage());
			throw new NIDmpException(
					"FileServiceImpl.sendEmailNotification(): {} , Error Message: {}", e);
		}
	}


	private void updateNiLeadsJobStatsForDirectMail(PiiPubSubAttributesDto dto) {
		// Make entry in Datastore for Jobstats
		KeyFactory keyFactory = datastore.newKeyFactory()
				.setKind(ConstantsUtil.LEADS_JOB_STATS);
		LOGGER.info("Key factory NI Leads Job stats for DirectMail");

		Key key = datastore.allocateId(keyFactory.newKey());
		Entity task = Entity.newBuilder(key)
				.set(ConstantsUtil.JOB_ID_NAME, dto.getJobId())
				.set(ConstantsUtil.STATUS, dto.getStatus())
				.set(ConstantsUtil.OUTPUTBUCKET, dto.getOutputBucket())
				.set(ConstantsUtil.OUTPUTPREFIX, dto.getOutputPrefix())
				.set(ConstantsUtil.OUTPUTPROJECT, dto.getOutputProject())
				.set(ConstantsUtil.OUTPUTRECORDS, dto.getOutputRecords())
				.build();
		datastore.put(task);
		LOGGER.info("NI Leads Job stats Datastore updated for DirectMail");

	}


	private void updateNiLeadsJobStatsForPhone(PiiPubSubAttributesDto dto) {
		// Make entry in Datastore for Jobstats
		KeyFactory keyFactory = datastore.newKeyFactory()
				.setKind(ConstantsUtil.LEADS_JOB_STATS);
		LOGGER.info("Key factory NI Leads Job stats for Phone");

		Key key = datastore.allocateId(keyFactory.newKey());
		Entity task = Entity.newBuilder(key)
				.set(ConstantsUtil.JOB_ID_NAME, dto.getJobId())
				.set(ConstantsUtil.STATUS, dto.getStatus())
				.set(ConstantsUtil.OUTPUTBUCKET, dto.getOutputBucket())
				.set(ConstantsUtil.OUTPUTPREFIX, dto.getOutputPrefix())
				.set(ConstantsUtil.OUTPUTPROJECT, dto.getOutputProject())
				.set(ConstantsUtil.OUTPUTRECORDS, dto.getOutputRecords())
				.set(ConstantsUtil.DNCREMOVED, dto.getDncRemoved())
				
				.build();
		datastore.put(task);
		LOGGER.info("NI Leads Job stats Datastore updated for Phone");

	}


	/**
	 * Update Ni-Leads JobStats
	 * @param dto
	 */
	private void updateNiLeadsJobStats(PiiPubSubAttributesDto dto) {

		// Make entry in Datastore for Jobstats
		KeyFactory keyFactory = datastore.newKeyFactory()
				.setKind(ConstantsUtil.LEADS_JOB_STATS);
		LOGGER.info("Key factory NI Leads Job stats");

		Key key = datastore.allocateId(keyFactory.newKey());
		Entity task = Entity.newBuilder(key)
				.set(ConstantsUtil.CREDITSREMAINING, dto.getCreditsRemaining())
				.set(ConstantsUtil.CATCHALL, dto.getCatchAll())
				.set(ConstantsUtil.DONOT_MAIL, dto.getDoNotMail())
				.set(ConstantsUtil.COUNTVALID_EMAILS, dto.getCountValidEmails())
				.set(ConstantsUtil.COUNTINPUT_RECORDS, dto.getCountInputRecords())
				.set(ConstantsUtil.SPAMTRAP, dto.getSpamtrap())
				.set(ConstantsUtil.ABUSE, dto.getAbuse())
				.set(ConstantsUtil.VALID, dto.getValid())
				.set(ConstantsUtil.INVALID, dto.getInvalid())
				.set(ConstantsUtil.UNKNOWN, dto.getUnknown())

				.set(ConstantsUtil.JOB_ID_NAME, dto.getJobId())
				.set(ConstantsUtil.STATUS, dto.getStatus())
				.set(ConstantsUtil.OUTPUTBUCKET, dto.getOutputBucket())
				.set(ConstantsUtil.OUTPUTPREFIX, dto.getOutputPrefix())
				.set(ConstantsUtil.OUTPUTPROJECT, dto.getOutputProject())
				.build();
		datastore.put(task);
		LOGGER.info("NI Leads Job stats Datastore updated");
	}

	/**
	 * @param attributeMap
	 * @return
	 */
	private PiiPubSubAttributesDto populatePiiPubSubAttributesDto(Map<String, String> attributeMap) {
		PiiPubSubAttributesDto dto = new PiiPubSubAttributesDto();
		if(attributeMap.containsKey(ConstantsUtil.JOB_ID)) {
			dto.setJobId(attributeMap.get(ConstantsUtil.JOB_ID));
		}
		if (attributeMap.containsKey(ConstantsUtil.EXP_STATUS)) {
			dto.setStatus(attributeMap.get(ConstantsUtil.EXP_STATUS));
			LOGGER.info(dto.getStatus());
		}
		if (attributeMap.containsKey(ConstantsUtil.OUTPUT_BUCKET)) {
			dto.setOutputBucket(attributeMap.get(ConstantsUtil.OUTPUT_BUCKET));
		}
		if (attributeMap.containsKey(ConstantsUtil.OUTPUT_PREFIX)) {
			dto.setOutputPrefix(attributeMap.get(ConstantsUtil.OUTPUT_PREFIX));
		}
		// Code changes for comments in CYBG 286 | few new fields added
		if (attributeMap.containsKey(ConstantsUtil.OUTPUT_PROJECT)) {
			dto.setOutputProject(attributeMap.get(ConstantsUtil.OUTPUT_PROJECT));
		}
		if (attributeMap.containsKey(ConstantsUtil.OUTPUT_RECORDS)) {
			dto.setOutputRecords(attributeMap.get(ConstantsUtil.OUTPUT_RECORDS));
		}
		// Code changes for comments in CYBG 321 | few new fields added
		if (attributeMap.containsKey(ConstantsUtil.DNC_REMOVED)) {
			dto.setDncRemoved(attributeMap.get(ConstantsUtil.DNC_REMOVED));
		}
		populatePiiPubSubAttributesForMail(attributeMap, dto);

		
		return dto;
	}



	/**
	 * @param attributeMap
	 * @param dto
	 */
	private void populatePiiPubSubAttributesForMail(Map<String, String> attributeMap, PiiPubSubAttributesDto dto) {
		if (attributeMap.containsKey(ConstantsUtil.CREDITS_REMAINING)) {
			dto.setCreditsRemaining(
					attributeMap.get(ConstantsUtil.CREDITS_REMAINING));
		}
		if (attributeMap.containsKey(ConstantsUtil.SPAMTRAP)) {
			dto.setSpamtrap(
					attributeMap.get(ConstantsUtil.SPAMTRAP));
		}

		if (attributeMap.containsKey(ConstantsUtil.CATCH_ALL)) {
			dto.setCatchAll(
					attributeMap.get(ConstantsUtil.CATCH_ALL));
		}
		if (attributeMap.containsKey(ConstantsUtil.ABUSE)) {
			dto.setAbuse(
					attributeMap.get(ConstantsUtil.ABUSE));
		}
		if (attributeMap.containsKey(ConstantsUtil.VALID)) {
			dto.setValid(
					attributeMap.get(ConstantsUtil.VALID));
		}
		if (attributeMap.containsKey(ConstantsUtil.DO_NOT_MAIL)) {
			dto.setDoNotMail(
					attributeMap.get(ConstantsUtil.DO_NOT_MAIL));
		}
		if (attributeMap.containsKey(ConstantsUtil.INVALID)) {
			dto.setInvalid(
					attributeMap.get(ConstantsUtil.INVALID));
		}
		if (attributeMap.containsKey(ConstantsUtil.UNKNOWN)) {
			dto.setUnknown(
					attributeMap.get(ConstantsUtil.UNKNOWN));
		}
		if (attributeMap.containsKey(ConstantsUtil.COUNT_VALID_EMAILS)) {
			dto.setCountValidEmails(
					attributeMap.get(ConstantsUtil.COUNT_VALID_EMAILS));
		}
		if (attributeMap.containsKey(ConstantsUtil.COUNT_INPUT_RECORDS)) {
			dto.setCountInputRecords(
					attributeMap.get(ConstantsUtil.COUNT_INPUT_RECORDS));
		}
	}

	/**
	 * @param attributeMap
	 * @return
	 */
	private PubSubAttributesDto populatePubSubAttributesDto(Map<String, String> attributeMap) {
		PubSubAttributesDto dto = new PubSubAttributesDto();
		if(attributeMap.containsKey(ConstantsUtil.JOB_ID)) {
			dto.setJobId(attributeMap.get(ConstantsUtil.JOB_ID));
		} 
		if (attributeMap.containsKey(ConstantsUtil.EXP_STATUS)) {
			dto.setStatus(attributeMap.get(ConstantsUtil.EXP_STATUS));
			LOGGER.info(dto.getStatus());
		}
		if (attributeMap.containsKey(ConstantsUtil.EXP_ERROR)) {
			dto.setError(attributeMap.get(ConstantsUtil.EXP_ERROR));
		} else {
			LOGGER.info("Inside Else");
			dto.setError(ConstantsUtil.BLANK_SPACE);
			if (attributeMap.containsKey(ConstantsUtil.BQ_DATASET) && 
					null != attributeMap.get(ConstantsUtil.BQ_DATASET)) {
				dto.setBqDataset(attributeMap.get(ConstantsUtil.BQ_DATASET));
				LOGGER.info(dto.getBqDataset());
			} else {
				dto.setBqDataset(ConstantsUtil.BLANK_SPACE);
			}
			if (attributeMap.containsKey(ConstantsUtil.UPLIFT_URL) && 
					null != attributeMap.get(ConstantsUtil.UPLIFT_URL)) {
				dto.setUpliftPlotLoc(attributeMap.get(ConstantsUtil.UPLIFT_URL));
				LOGGER.info(dto.getUpliftPlotLoc());
			} else {
				dto.setUpliftPlotLoc(ConstantsUtil.BLANK_SPACE);
			}
		}
		return dto;
	}

	/**
	 * Acknowledge message to Pub/Sub 
	 * @param pullResponse
	 * @throws IOException 
	 * @throws Exception
	 */
	private void acknowledgeSubscribedMessage(PullResponse pullResponse) 
			throws IOException 
	{
		//Build an SubscriberStubSettings object that would help in pulling the message
		SubscriberStubSettings subscriberStubSettings = buildSubscriberStubSettingsObj();
		//Create a SubscriberStub which would send the pull request
		try (SubscriberStub subscriber = GrpcSubscriberStub.create(subscriberStubSettings))
		{
			//Fetch pub/sub subscription name from project
			//Define a new list that will contain acknowledgement ID of message
			List<String> ackIds = new ArrayList<>();
			//iterate over message list retrieved in pull response
			for (ReceivedMessage message : pullResponse.getReceivedMessagesList()) {
				//Add message acknowledgement ID in ackIds list
				ackIds.add(message.getAckId());
			}
			// acknowledge received messages
			AcknowledgeRequest acknowledgeRequest =AcknowledgeRequest.newBuilder()
					.setSubscription(setSubscriptionName())
					.addAllAckIds(ackIds)
					.build();
			//send the request to pub/sub to acknowledge the message
			subscriber.acknowledgeCallable().call(acknowledgeRequest);
		} catch(IOException e) {
			LOGGER.error("Exception in acknowledgeSubscribedMessage function: {}",e);
			throw e;
		}
	}

	/**
	 * Acknowledge message to Pub/Sub 
	 * @param pullResponse
	 * @throws IOException 
	 * @throws Exception
	 */
	private void acknowledgeSubscribedMessageForPii(PullResponse pullResponse) 
			throws IOException 
	{
		//Build an SubscriberStubSettings object that would help in pulling the message
		SubscriberStubSettings subscriberStubSettings = buildSubscriberStubSettingsObj();
		//Create a SubscriberStub which would send the pull request
		try (SubscriberStub subscriber = GrpcSubscriberStub.create(subscriberStubSettings))
		{
			//Fetch pub/sub subscription name from project
			//Define a new list that will contain acknowledgement ID of message
			List<String> ackIds = new ArrayList<>();
			//iterate over message list retrieved in pull response
			for (ReceivedMessage message : pullResponse.getReceivedMessagesList()) {
				//Add message acknowledgement ID in ackIds list
				ackIds.add(message.getAckId());
			}
			// acknowledge received messages
			AcknowledgeRequest acknowledgeRequest =AcknowledgeRequest.newBuilder()
					.setSubscription(setSubscriptionForPii())
					.addAllAckIds(ackIds)
					.build();
			//send the request to pub/sub to acknowledge the message
			subscriber.acknowledgeCallable().call(acknowledgeRequest);
		} catch(IOException e) {
			LOGGER.error("Exception in acknowledgeSubscribedMessageForPii function: {}",e);
			throw e;
		}
	}



	@Override
	public byte [] downloadUpliftFile(String fileName) {

		try (ReadChannel reader = storage.reader(inboundBucketUpliftDev, fileName)) {
			StringBuilder sb = readFileInChunks(reader);

			return sb.toString().getBytes();
		} catch(Exception e) {
			LOGGER.error(
					"FileServiceImpl.downloadUpliftFile(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"FileServiceImpl.downloadUpliftFile(): {} , Error MEssage: {}", e);
		}
	}

	/**
	 * This will store Distribution data in DS
	 * @param originalFilename
	 * @param destination
	 * @param inboundRecords
	 */
	private void storeDistributionDataInDS(String originalFilename
			, String destination, String distributionType, String inboundRecords, 
			Long distributionNo, Long startTimeStamp) {

		LOGGER.info("Distribution DS called");
		// Create a Key factory to construct keys associated with this project.
		long dhTimeStamp = Instant.now().toEpochMilli();
		String distributionDate = DateUtility.getFormattedDateString(dhTimeStamp);
		KeyFactory keyFactory = datastore.newKeyFactory()
				.setKind(ConstantsUtil.DISTRIBUTION_HISTORY);
		LOGGER.info(ConstantsUtil.KEY_FACTORY);
		Key key = datastore.allocateId(keyFactory.newKey());
		Entity task = Entity.newBuilder(key)
				.set(ConstantsUtil.DIST_TIMESTAMP, dhTimeStamp)
				.set(ConstantsUtil.DISTRIBUTIONS, distributionNo)
				.set(ConstantsUtil.FILENAME, originalFilename)
				.set(ConstantsUtil.STATUS, ConstantsUtil.BLANK_SPACE)
				.set(ConstantsUtil.INBOUND_CNT, inboundRecords)	
				.set(ConstantsUtil.MATCHED_CNT, ConstantsUtil.BLANK_SPACE)	// UPDATED IN LATER STAGE
				.set(ConstantsUtil.DISTRIBUTION_DATE, distributionDate)
				.set(ConstantsUtil.DESTINATION, destination)
				.set(ConstantsUtil.USERNAME, ConstantsUtil.BLANK_SPACE)	// ADD USERNAME as per LOGGED IN USER
				//	.set(ConstantsUtil.TRAIT_ID, traitId.toString())
				.set(ConstantsUtil.START_TIMESTAMP, startTimeStamp)		// May have to generate new timestamp
				.set(ConstantsUtil.SEQ_CODE, ConstantsUtil.VALIDATEFILE_SEQ_CODE) //file is already VALIDATED
				.set(ConstantsUtil.INBOUND_AUD_FILENAME, ConstantsUtil.BLANK_SPACE) // UPDATED IN LATER STAGE
				.set(ConstantsUtil.DISTRIBUTION_TYPE, distributionType)
				.build();
		datastore.put(task);

	}


	private void updateDistributionHistory(long startTimeStamp, Integer sequenceCode, 
			String status, long distributionNo) {

		Datastore datastore2 =DatastoreOptions.getDefaultInstance().getService();
		LOGGER.info("updateDistributionHistory");

		QueryResults<Entity> result2 = fetchDHByStartTimestamp(
				startTimeStamp);
		while (result2.hasNext())
		{
			LOGGER.info("updateDistributionHistory while sequenceCode: {}", sequenceCode);
			//	Key entityKey = result2.next().getKey();	2	
			Entity entity = result2.next();

			if (distributionNo == entity.getLong(ConstantsUtil.DISTRIBUTIONS)) {
				Key entityKey = entity.getKey();// entity.getString("Filename")  entity.getLong("Distributions")
				entity = Entity.newBuilder(datastore2.get(entityKey))
						.set(ConstantsUtil.SEQ_CODE, sequenceCode) //setting the value of Sequence Code.
						.set(ConstantsUtil.STATUS, setDistributionStatus(sequenceCode, status))
						.build();
				datastore2.put(entity);
				LOGGER.info("updateDistributionHistory put status : {}", status);
			}
		}	
	}

	private void updateDistributionHistoryWithMatchedCnt(long startTimeStamp, Integer sequenceCode, 
			String status, long distributionNo, Integer matchedCnt) {
		LOGGER.info("updateDistributionHistoryWithMatchedCnt");
		Datastore datastore2 =DatastoreOptions.getDefaultInstance().getService();
		status = setDistributionStatus(sequenceCode, status);
		QueryResults<Entity> result2 = fetchDHByStartTimestamp(
				startTimeStamp);
		while (result2.hasNext())
		{
			LOGGER.info("updateDistributionHistory If sequenceCode: {}", sequenceCode);
			Entity entity = result2.next();
			if (distributionNo == entity.getLong(ConstantsUtil.DISTRIBUTIONS)) {
				Key entityKey = entity.getKey();						  
				entity = Entity.newBuilder(datastore2.get(entityKey))
						.set(ConstantsUtil.SEQ_CODE, sequenceCode) //setting the value of Sequence Code.
						.set(ConstantsUtil.STATUS, status)
						.set(ConstantsUtil.MATCHED_CNT, matchedCnt.toString())
						.build();
				datastore2.put(entity);
				LOGGER.info("updateDistributionHistory put status: {}", status);
			}
		}	
	}

	private void updateDistributionHistoryWithS3File(long startTimeStamp, Integer sequenceCode, 
			String status, long distributionNo, String s3file) {
		LOGGER.info("updateDistributionHistoryWithS3File");
		Datastore datastore2 =DatastoreOptions.getDefaultInstance().getService();
		status = setDistributionStatus(sequenceCode, status);
		QueryResults<Entity> result2 = fetchDHByStartTimestamp(
				startTimeStamp);
		while (result2.hasNext())
		{
			LOGGER.info("updateDistributionHistory If sequenceCode: {}", sequenceCode);
			Entity entity = result2.next();
			if (distributionNo == entity.getLong(ConstantsUtil.DISTRIBUTIONS)) {
				Key entityKey = entity.getKey();						  
				entity = Entity.newBuilder(datastore2.get(entityKey))
						.set(ConstantsUtil.SEQ_CODE, sequenceCode) //setting the value of Sequence Code.
						.set(ConstantsUtil.STATUS, status)
						.set(ConstantsUtil.INBOUND_AUD_FILENAME, s3file)
						.build();
				datastore2.put(entity);
				LOGGER.info("updateDistributionHistory put status: {}", status);
			}
		}	
	}


	/**
	 * @param sequenceCode
	 * @return
	 */
	private String setDistributionStatus(Integer sequenceCode
			, String origStatus) {
		String status;
		if (origStatus.contains(ConstantsUtil.ERROR)) {
			return ConstantsUtil.ERROR;
		}
		if ( sequenceCode >= 4 && sequenceCode <= 6) {
			status = "Matched";
		} else if ( sequenceCode == 7) {
			status = "Distributed";
		} else {
			status = "N/A";
		}
		return status;
	}

	private QueryResults<Entity> fetchDHByStartTimestamp(long startTimeStamp) {
		// Build the Query
		Query<Entity> query = Query.newEntityQueryBuilder()
				.setKind(ConstantsUtil.DISTRIBUTION_HISTORY)    //specify the task name - here it is 'Task'                                 
				.setFilter(PropertyFilter.eq(ConstantsUtil.START_TIMESTAMP, startTimeStamp))  //where clause - first parameter should match the column name in datastore.

				.build();
		return datastore.run(query);
	}

	/**
	 * @param distributionNo
	 * @param entity
	 * @return
	 */
	private long setDistributionNo(long distributionNo, Entity entity) {
		if (entity.contains(ConstantsUtil.DISTRIBUTIONS)) {
			distributionNo = entity.getLong(ConstantsUtil.DISTRIBUTIONS);
		}
		return distributionNo;
	}


	private void storeReDistributionDataInDS(String originalFilename
			, String destination, String distributionType, 
			Long distributionNo, Entity entity) {
		LOGGER.info("Re-Distribution DS called");
		// Create a Key factory to construct keys associated with this project.
		long dhTimeStamp = Instant.now().toEpochMilli();
		String distributionDate = DateUtility.getFormattedDateString(dhTimeStamp);
		KeyFactory keyFactory = datastore.newKeyFactory()
				.setKind(ConstantsUtil.DISTRIBUTION_HISTORY);
		LOGGER.info(ConstantsUtil.KEY_FACTORY);
		Key key = datastore.allocateId(keyFactory.newKey());
		Entity task = Entity.newBuilder(key)
				.set(ConstantsUtil.DIST_TIMESTAMP, dhTimeStamp)
				.set(ConstantsUtil.DISTRIBUTIONS, distributionNo)
				.set(ConstantsUtil.FILENAME, originalFilename)
				.set(ConstantsUtil.STATUS, ConstantsUtil.BLANK_SPACE)
				.set(ConstantsUtil.INBOUND_CNT, entity.getString(ConstantsUtil.INBOUND_CNT))
				.set(ConstantsUtil.MATCHED_CNT, entity.getString(ConstantsUtil.MATCHED_CNT))
				.set(ConstantsUtil.DISTRIBUTION_DATE, distributionDate)
				.set(ConstantsUtil.DESTINATION, destination)
				.set(ConstantsUtil.USERNAME, ConstantsUtil.BLANK_SPACE)	// ADD USERNAME as per LOGGED IN USER
				.set(ConstantsUtil.START_TIMESTAMP, entity.getLong(ConstantsUtil.START_TIMESTAMP))		// May have to generate new timestamp
				.set(ConstantsUtil.SEQ_CODE, ConstantsUtil.INTERMEDIATE_FILE_FOR_GCS_SEQ_CODE) //file is already creaTED
				.set(ConstantsUtil.INBOUND_AUD_FILENAME, ConstantsUtil.BLANK_SPACE) // UPDATED IN LATER STAGE
				.set(ConstantsUtil.DISTRIBUTION_TYPE, distributionType)
				.build();
		datastore.put(task);

	}

	/**
	 * Set filename seq code and status
	 * @param startTimeStamp
	 * @param fileName
	 * @param sequenceCode
	 * @param status
	 */
	private void setSequenceCodeInDS(Long startTimeStamp, String fileName, 
			Integer sequenceCode,
			String status) {

		QueryResults<Entity> result = fetchByStartTimestamp(startTimeStamp);
		if(result.hasNext())
		{
			Entity entity = result.next();
			Key entityKey = entity.getKey();
			entity = Entity.newBuilder(datastore.get(entityKey))
					.set(ConstantsUtil.STATUS, status)
					.set(ConstantsUtil.SEQ_CODE, sequenceCode)
					.set(ConstantsUtil.INBOUND_AUD_FILENAME, fileName)
					.build();
			datastore.put(entity);
		}
	}


	@Override
	public void pullSubForNiLeads() {

		LOGGER.info("Inside pullSubForNiLeads Message function");
		//Variable that defines how many message to pull at once
		int numOfMessages = 1;
		//Build an SubscriberStubSettings object that would help in pulling the message

		SubscriberStubSettings subscriberStubSettings = null;
		try {
			subscriberStubSettings = buildSubscriberStubSettingsObj();
		} catch (Exception e) {
			LOGGER.error(
					"FileServiceImpl.pullSub(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"FileServiceImpl.pullSub(): {} , Error MEssage: {}", e);
		}
		//Create a SubscriberStub which would send the pull request
		try (SubscriberStub subscriber = GrpcSubscriberStub.create(subscriberStubSettings))
		{
			//Fetch pub/sub subscription name from project
			String piiSubscriptionName = setSubscriptionForPii();
			//Build a pull request
			LOGGER.info("Pii subscriptionName: {} ", piiSubscriptionName);
			PullRequest pullRequest =PullRequest.newBuilder()
					.setMaxMessages(numOfMessages)
					.setReturnImmediately(true)
					.setSubscription(piiSubscriptionName)
					.build();

			LOGGER.info("Pull Request");
			// Send Synchronous Pull request and get the pull response
			PullResponse pullResponse = subscriber.pullCallable().call(pullRequest);
			LOGGER.info("Pull Response");
			//Get message count in pull response
			int getReceivedMessagesCount = pullResponse.getReceivedMessagesCount();
			LOGGER.info("Pull response data: {} ", getReceivedMessagesCount);
			//Condition will be true if any message retrieved from subscription
			if(getReceivedMessagesCount!=0)
			{
				LOGGER.info("Inside IF: {} ", getReceivedMessagesCount);
				processPiiPullSubscriberData(pullResponse);
			}
		}catch(Exception e){
			LOGGER.error(
					"FileServiceImpl.pullSubForNiLeads (): {}, Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"FileServiceImpl.pullSubForNiLeads (): {}, Error MEssage: {}", e);
		}

	}

	/**
	 * @param dto
	 * @return
	 */
	private QueryResults<Entity> fetchDetailsByJobId(String jobId) {

		LOGGER.info("fetchFileDetailsByJobId jobId: {}", jobId);
		// Fetch existing Datastore entry for a filename
		StructuredQuery<Entity> query = Query.newEntityQueryBuilder()
				.setKind(ConstantsUtil.DISTRIBUTION_HISTORY)
				.setFilter(PropertyFilter.eq(ConstantsUtil.JOB_ID_NAME, jobId))
				.build();
		return datastore.run(query);
	}

	/**
	 * @param dto
	 * @return
	 */
	private QueryResults<Entity> fetchDetailsByJobIdExpFlow(String jobId) {

		LOGGER.info("fetchDetailsByJobIdExpFlow jobId: {}", jobId);
		// Fetch existing Datastore entry for a filename
		StructuredQuery<Entity> query = Query.newEntityQueryBuilder()
				.setKind(ConstantsUtil.EXPANDED_AUD_DIST_HISTORY)
				.setFilter(PropertyFilter.eq(ConstantsUtil.JOB_ID_NAME, jobId))
				.build();
		return datastore.run(query);
	}

	/** 
	 * Find Inbound count for exp aud file in NI leads dist
	 * @param resultCount
	 */
	private String findCountOfInboundRecords(TableResult result) {
		String inboundRecords = null;
		for (FieldValueList row : result.iterateAll()) {
			inboundRecords = (String) row.get(0).getValue();
		}
		return inboundRecords;
	}

}
