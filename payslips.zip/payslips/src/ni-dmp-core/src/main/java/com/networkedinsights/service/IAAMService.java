/**
 * 
 */
package com.networkedinsights.service;

import java.util.List;

import com.networkedinsights.dto.JobStatsDto;
import com.networkedinsights.dto.TraitDto;
import com.networkedinsights.dto.TraitListDto;

/**
 * @author rajvirs
 * created on - 22/02/2019
 * modified on - 06/03/2019
 *
 */
public interface IAAMService {

	/**
	 * This method will create a Trait, for the 
	 * given set of parameters through file upload part.
	 * @param traitInfoList
	 * @return
	 */
	public String createTraitId(List<String> traitInfoList);

	/**
	 * This method will fetch trait list for the
	 * specified folderId and datasourceId.
	 * @param folderId
	 * @param dataSourceId
	 * @return
	 */
	public List<TraitListDto> fetchTraitList(String folderId, String dataSourceId);

	/**
	 * This method will create a Trait, for the
	 * given set of parameters through UI part.
	 * @param traitDtoO
	 * @return
	 */
	public String createTrait(TraitDto traitDto);

	/**
	 * This method will fetch TTL for the 
	 * passed trait Id.
	 * @param traitId
	 * @return
	 */
	public TraitDto fetchTraitById(Integer traitId);

	/**
	 * This method will reload trait list by
	 * calling Adobe API's.
	 * @return
	 */
	public List<TraitListDto> reloadTraitList();

	/**
	 * This method will fetch processed file by Adobe. 
	 * @return
	 */
	public List<String> fetchFileNameList();

	/**
	 * This is a scheduled job which updates records from
	 * Adobe and updates Datastore.
	 */
	public void reloadTraitListFromJob();
	
	/**
	 * This method will reload trait list by
	 * calling Adobe API's when new trait is
	 * created in file upload from Storage flow.
	 * @return
	 */
	public void reloadTraitsFromStorageFlow();

	/**
	 * This method will delete trait from datastore
	 * and adobe audience manager, and keep a track of
	 * deleted trait in DeletedTraits table in datastore.
	 * @param traitId
	 * @param username
	 * @return
	 */
	public Boolean deleteTraitById(Integer traitId,
			String username);

	/**
	 * This method will update trait name, desc
	 * and TTL in both AAM and datastore.
	 * @param traitDto
	 * @param traitId
	 * @return
	 */
	public Boolean updateTrait(TraitDto traitDto,
			Integer traitId);

	/**
	 * This method will fetch JobStats List for a 
	 * particular time frame
	 * @param timestamp
	 * @param isDatastoreEmpty
	 * @return
	 */
	public List<JobStatsDto> fetchJobStatsList(Long timestamp, 
			Boolean isDatastoreEmpty);
	
}
