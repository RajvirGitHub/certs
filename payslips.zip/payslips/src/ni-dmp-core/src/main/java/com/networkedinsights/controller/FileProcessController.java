package com.networkedinsights.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.networkedinsights.dto.FileDetailDto;
import com.networkedinsights.dto.FileTraitDto;
import com.networkedinsights.dto.NiLeadsDto;
import com.networkedinsights.service.IExpansionAudienceService;
import com.networkedinsights.service.IFileService;
import com.networkedinsights.service.INILeadsService;
import com.networkedinsights.util.ConstantsUtil;
 
/**
 * @author rajvirs
 * created on - 17/01/2018
 * modified on - 01/03/2018
 */

@RestController
@RequestMapping("/core/v1")
public class FileProcessController extends AbstractBaseController{
	private static final Logger LOGGER = LoggerFactory.getLogger(FileProcessController.class);
	
	@Autowired
	IFileService fileService;
	
	@Autowired
	INILeadsService niLeadsService;
	
	@Autowired
	IExpansionAudienceService expansionAudienceService;
	
	/**
	 * Upload file to GCS Storage 
	 * @param file
	 * @return
	 */
	@RequestMapping(value = ("/file/upload"), headers = ("content-type=multipart/*"), 
			method = RequestMethod.POST)
    public ResponseEntity<String> uploadMultipartFile(@RequestParam("file") MultipartFile file,
    		@RequestParam(value = "traitId", required = true) Integer traitId,
    		@RequestParam(value = "expansion", required = true) Boolean expansion) {
		String fileName = file.getOriginalFilename();
		fileService.uploadFile(fileName, file, traitId);

		// Storing file details in Datastore, Performing validation on file
		// Then Uploading file on cloud9-airflow project
		fileService.storeValidateUploadFile(fileName, file, traitId, expansion);

		return ResponseEntity.ok("File Uploaded Successfully fileName: " + fileName);
	}
	
	/**
	 * Make an entry in DataStore and call PubSub
	 * @param fileTraitDto
	 * @return
	 */
	@PostMapping(value = "/dataStore_pubsub/{destination}/type/{distributionType}")
	public ResponseEntity<Boolean> makeEntryInDataStoreCallPubSub(
			@RequestBody FileTraitDto fileTraitDto,
			@PathVariable String destination,
			@PathVariable String distributionType) {
		Boolean flag = false;
		LOGGER.info("Pub SUB called");
		if (null != destination && ConstantsUtil.DEST_ADOBE
				.equalsIgnoreCase(destination) && null != fileTraitDto) {
			// Distribute to Adobe
			LOGGER.info("Make an entry in DataStore and call PubSub");
			flag = fileService.makeEntryInDataStoreCallPubSub(
					fileTraitDto, destination, distributionType);
		}
		
		return ResponseEntity.ok(flag);
	}
	
	/**
	 * This method will Parse the file path & get trait Id. If traitId is not found,
	 * Then it will trigger Trait creation( i.e. call Adobe API to create TRAIT)
	 * Then it will validate the file and store the traitId in Datastore.
	 * 
	 * @param fileDetailDto
	 * @return
	 */
	@PostMapping(value = "/file/validate")
	public ResponseEntity<Boolean> validateFile(@RequestBody FileDetailDto
			fileDetailDto) {
		Boolean flag = false;
		if(null != fileDetailDto){
			LOGGER.info(" Validate File ");
			flag =fileService.validateFile(fileDetailDto);
		}
		
		return ResponseEntity.ok(flag);
	}
	/**
	 * Load social Id's in Big Query table.
	 * And set sequence code appropriately.
	 * @param fileDetailDto
	 * @return
	 */
	@PostMapping(value = "/file/load_social_id")
	public ResponseEntity<Boolean> loadSocialIdToFile(@RequestBody FileDetailDto
			fileDetailDto) {
		Boolean flag = false;
		if(null != fileDetailDto){
			LOGGER.info("Load social Id's in BigQuery table");
			flag = fileService.loadSocialIdToFile(fileDetailDto);
		}
		return ResponseEntity.ok(flag);
	}
	
	/**
	 * Big Query join which will sync up social id and adobe uuid.
	 * And set sequence code appropriately.
	 * @param fileDetailDto
	 * @return
	 */
	@PostMapping(value = "/file/adobeuuid")
	public ResponseEntity<Boolean> syncAdobeUUIdWithSocialId(@RequestBody FileDetailDto
			fileDetailDto) {
		Boolean flag = false;
		if(null != fileDetailDto){
			LOGGER.info("Big Query join to sync social id & adobe uuid");

			flag =fileService.syncAdobeUUIdWithSocialId(fileDetailDto);
		}
		return ResponseEntity.ok(flag);
	}
	
	/**
	 * Upload outbound file to gcs.
	 * And set sequence code appropriately.
	 * @param fileDetailDto
	 * @return
	 */
	@PostMapping(value = "/file/upload_outbound_gcs")
	public void uploadOutboundFileGCS(@RequestBody FileDetailDto
			fileDetailDto) {
		
		if(null != fileDetailDto){
			LOGGER.info("Big Query join to sync social id & adobe uuid");

			fileService.uploadOutboundFileGCS(fileDetailDto);
		}
	}
	
	/**
	 * Create Adobe audience file as per Adobe inbound file format (i.e tab separated and
	 * file name as per adobe guidelines) and SAVE the file to intermediate GCS bucket.
	 * And set sequence code appropriately. 
	 * @param fileDetailDto
	 * @return
	 */
	@PostMapping(value = "/file/intermediate_gcs")
	public void createIntermediateFileForGCS(@RequestBody FileDetailDto
			fileDetailDto) {
		if(null != fileDetailDto){
			LOGGER.info("Intermediate inbound FILE creation called");
			fileService.createIntermediateFileForGCS(fileDetailDto);
		}
	}
	
	/**
	 * Upload inbound file as per Adobe inbound file format (i.e tab separated and
	 * file name as per adobe guidelines) in S3 bucket.
	 * And set sequence code appropriately. 
	 * @param fileDetailDto
	 * @return
	 */
	@PostMapping(value = "/file/upload_S3")
	public void uploadInboundFileToS3Bucket(@RequestBody FileDetailDto
			fileDetailDto) {
		if(null != fileDetailDto){
			LOGGER.info("FILE Upload to S3 called");
			fileService.uploadInboundFileToS3(fileDetailDto);
		}
	}
	
	/**
	 * Download NI Audience File from
	 * Google cloud storage.
	 * @param fileName
	 * @param isUI
	 * @return
	 */
	@GetMapping(value = "/file/download/{fileName}/isUI/{isUI}")
	public ResponseEntity<byte[]> downloadInboundAudienceFile(@PathVariable String
			fileName, @PathVariable Boolean isUI) {
		if(null != fileName) {
			LOGGER.info("FILE download from GCS called");
			byte [] downloadInputStream = fileService.downloadInboundFile(fileName, isUI);
			
			return ResponseEntity.ok()
					.contentType(contentType(fileName))
					.header(HttpHeaders.CONTENT_DISPOSITION,"attachment; filename=\"" + fileName + "\"")
					.body(downloadInputStream);	
		
		}
		return null;
	}
	//LOCAL
	@GetMapping(value = "/uplift/{fileName}")
	public ResponseEntity<byte []> downloadFile(@PathVariable String
			fileName) {
		if(null != fileName) {
			LOGGER.info("FILE download from GCS called");
			byte [] downloadInputStream = fileService.downloadUpliftFile(fileName);
			
			return ResponseEntity.ok(downloadInputStream);
					
		}
		return null;
	}

	/**
	 * This method will download file 
	 * from DSA and store it in DMP.
	 * @param fileName
	 * @return
	 */
	@GetMapping(value = "/upliftHtmlFile/{fileName}")
	public ResponseEntity<byte[]> uploadUpliftHtmlFile(
			@PathVariable String fileName) {
		LOGGER.info("Upload Uplift Html file");
		
		byte [] downloadInputStream = fileService.uploadUpliftHtmlFile(fileName);
		LOGGER.info("File sent in bytes");
		return ResponseEntity.ok(downloadInputStream);
		
	}

	/**
	 * Finds the contentType of file
	 * by looking at the extension
	 * @param fileName
	 * @return
	 */
	private MediaType contentType(String fileName) {
		String[] arr = fileName.split("\\.");
		String type = arr[arr.length-1];
		switch(type) {
			case "txt": return MediaType.TEXT_PLAIN;
			case "png": return MediaType.IMAGE_PNG;
			case "jpg": return MediaType.IMAGE_JPEG;
			default: return MediaType.APPLICATION_OCTET_STREAM;
		}
	}
	
	/**
	 * Store file in PII matcher bucket 
	 * and call POST API
	 * @param fileTraitDto
	 * @return
	 */
	@PostMapping(value = "/nileads_distribute/{isExpansion}")
	public ResponseEntity<Boolean> nileadsDistribute(
			@RequestBody NiLeadsDto niLeadsDto,
			@PathVariable Boolean isExpansion) {
		Boolean flag = false;
		String jobIdName = null;
		LOGGER.info("Pub SUB called");
		if (!isExpansion) {
			jobIdName = niLeadsService.processFileToLeadsPlatform(niLeadsDto);
		} else {
			jobIdName = niLeadsService.processExpansionFileToLeadsPlatform(niLeadsDto);
		}  // COMMENTING FOR TESTING |DONOT CHECKIN
		if (null != jobIdName) {
			// Call POST API which will alert NI Leads that
			// file has been uploaded successfully
			LOGGER.info("POST API called");
			flag = niLeadsService.callPostApi(niLeadsDto, 
					isExpansion, jobIdName);
			LOGGER.info("After POST API call");
		}
		
		return ResponseEntity.ok(flag);
	}
	
}