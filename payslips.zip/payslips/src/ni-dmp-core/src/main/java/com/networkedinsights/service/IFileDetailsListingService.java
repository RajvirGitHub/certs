/**
 * 
 */
package com.networkedinsights.service;

import java.util.List;

import com.networkedinsights.dto.FileDetailsListingDto;

/**
 * @author rajvirs
 * created on - 02/04/2019
 * modified on - 02/04/2019
 */
public interface IFileDetailsListingService {

	/**
	 * Fetch file detailList for specified traitId
	 * @param traitId
	 * @return
	 */
	List<FileDetailsListingDto> fileDetailsListing(Integer traitId);

}
