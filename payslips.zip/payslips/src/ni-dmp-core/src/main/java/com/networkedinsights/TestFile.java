/**
 * 
 */
package com.networkedinsights;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TimeZone;
import java.util.TreeMap;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

/**
 * @author rajvirs
 *
 */
public class TestFile {

	/**
	 * @param args
	 */
	static {
		System.out.println("I am the winner");
	}
	// MD5 logic
	private static String md5Encryption(String input) throws NoSuchAlgorithmException 
	{ 
		// Static getInstance method is called with hashing MD5 
		MessageDigest md = MessageDigest.getInstance("MD5"); 
		// digest() method is called to calculate message digest 
		//  of an input digest() return array of byte 
		byte[] messageDigest = md.digest(input.getBytes()); 

		// Convert byte array into signum representation 
		BigInteger no = new BigInteger(1, messageDigest); 
		return no.toString(16);
	}
	private static String toHex(String input) {
		// Convert message digest into hex value  ac28e037559b8b973a78efd829cf37be
		while (input.length() < 32) {
			input = "0" +input;
		} 

		return input;
	} 
	
	public static void main(String[] args) {
		
		try{
			System.out.println(toHex(md5Encryption("Tanya.Jd@Att.Net")));
			
			String ab = "ahahhahah-*.csv";
			ab = ab.replace("-*.csv", "0000.csv");
			System.out.println("ab:"+ab);
			
			 String password = "Tanya.Jd@Att.Net".toLowerCase();

		        MessageDigest md = MessageDigest.getInstance("MD5");
		        byte[] hashInBytes = md.digest(password.getBytes(StandardCharsets.UTF_8));

		        StringBuilder sb = new StringBuilder();
		        for (byte b : hashInBytes) {
		            sb.append(String.format("%02x", b));
		        }
		        System.out.println(sb.toString());
		        
		} catch (Exception e) {
			System.out.println("exception while encryption");
		}
		String email = "";
		String varifyQuery = "SELECT md5 FROM "
				+ "`cloud9-dmp-dev.ni_dmp_views.blacklist_table` WHERE md5 =" +email ;

		Map<Long, String> unsortMap = new HashMap<>();
        unsortMap.put(10l, "z");
        unsortMap.put(5l, "b");
        unsortMap.put(6l, "a");
        unsortMap.put(20l, "c");
        
        Date d1 = new Date();
        //2019-10-07 14:38:57.452394 UTC	2019-10-15 07:19:45.000371 UTC 2019-10-15 07:19:18.811 UTC
        /*d1:Tue Oct 15 12:44:01 IST 2019
        dt:2019-10-15T12:44:01.816+05:30
        now():2019-10-15T07:14:02.077Z
        DateTimeZone.UTC:2019-10-15T07:14:02.217Z*/
        
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSS z");
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        System.out.println(f.format(new Date()));
        
        
        System.out.println("d1:"+d1);
        DateTime dt = new DateTime();
        System.out.println("dt:"+dt);
        System.out.println("now():"+Instant.now());
        System.out.println("DateTimeZone.UTC:"+DateTime.now().toDateTime(DateTimeZone.UTC));

        System.out.println("Unsort Map......");
        printMap(unsortMap);

        System.out.println("\nSorted Map......By Key");
        Map<Long, String> treeMap = new TreeMap<>(
                new Comparator<Long>() {

                    @Override
                    public int compare(Long o1, Long o2) {
                        return o2.compareTo(o1);
                    }

                });
        treeMap.putAll(unsortMap);

        printMap(treeMap);
        System.out.println("\nSorted Map 2......By Key");
	    /* For Java 8, try this lambda */
		Map<Long, String> treeMap2 = new TreeMap<>(
		                (Comparator<Long>) (o1, o2) -> o2.compareTo(o1));
		
        treeMap2.putAll(unsortMap);

        printMap(treeMap2);
		
		
		long seqCode = 3;

		if (seqCode > 0) {
			switch((int)seqCode) {
			case 1: // In Progress File uploaded into NI System
				System.out.println("seQ cODE"+seqCode); 
				break;
			case 2: // File has been successfully validated
				System.out.println("seQ cODE"+seqCode); 
				break;
			case 3: // File has been successfully validated
				System.out.println("seQ cODE"+seqCode); 
				break;
			case 4: // Social IDs matched to Adobe IDs
			case 5: // File created for distribution to Adobe
			case 6: // File created for distribution to Adobe
				/*System.out.println("seQ cODE"+seqCode); 
				break;*/
			default:
				System.out.println("seQ cODE"+seqCode); 
				break;
			}
		}
		//TestFile TestFile = new TestFile();
		MultiValueMap<String, String> m = new LinkedMultiValueMap();
		m.add("", "");
		m.add("1", "www");
		m.add("1", "sds");
		m.add("", "asa");
		Set e = m.entrySet();
		for (Object d: m.keySet()) {
			System.out.println(d.toString());
		}
		for (Entry d: m.entrySet()) {
			System.out.println(d.getKey()+" : "+d.getValue());
		}

		System.out.println("TEST m:"+m);
		System.out.println("TEST:"+TestFile.TestFile());
		Map<String, String> map = new HashMap<>();
		map.put("a", "100");
		map.put("", "200");
		map.put("c", "300");
		map.put("d", "400");
		String x = map.toString();
		System.out.println("Map:"+map);
		System.out.println("Map:"+x);
		List<Integer> l = new ArrayList<>();
		l.add(12);
		l.add(9);
		l.add(19);
		l.add(2);
		
		
		Iterator<Integer> itr = l.iterator();
		while (itr.hasNext()) {
			System.out.println("****Adding");
			//l.remove(12);
			itr.remove();
			l.add(0, 111);
			System.out.println("****Added");
		}
		//Iterator itr = map.

		for (Entry entry: map.entrySet()) {
			System.out.println(entry.getKey()+" : "+entry.getValue());
		}
	}
	private static void printMap(Map<Long, String> map) {
		
		for (Entry entry : map.entrySet()) {
			System.out.println("Key:"+entry.getKey()+ "val:"+entry.getValue());
		}
		
	}
	private static int TestFile() {
		return 100;
	}

}
