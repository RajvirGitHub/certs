/**
 * 
 */
package com.networkedinsights.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.cloud.datastore.Datastore;
import com.google.cloud.datastore.Entity;
import com.google.cloud.datastore.Query;
import com.google.cloud.datastore.QueryResults;
import com.google.cloud.datastore.StructuredQuery;
import com.google.cloud.datastore.StructuredQuery.PropertyFilter;
import com.networkedinsights.dto.FileDetailsListingDto;
import com.networkedinsights.exception.NIDmpException;
import com.networkedinsights.service.IFileDetailsListingService;
import com.networkedinsights.util.ConstantsUtil;
import com.networkedinsights.util.DateUtility;

/**
 * @author rajvirs
 * created on - 04/02/2019
 * modified on - 05/07/2019
 */
@Service
public class FileDetailsListingServiceImpl implements IFileDetailsListingService {
	public static final Logger LOGGER = LoggerFactory.getLogger(FileDetailsListingServiceImpl.class);
	
	@Autowired
	private Datastore datastore;
	
	@Value("${bucketname.inbound.ui}")
	private String bucketnameInboundUi;
	
	@Override
	public List<FileDetailsListingDto> fileDetailsListing(Integer traitId) {
		List<FileDetailsListingDto> fileDetailsList = new ArrayList<>();
		LOGGER.info("fileDetailsListing called");
		try {
		//	List<String> fileNameList  aamServiceImpl fetchFileNameList
			
			StructuredQuery<Entity> query = Query.newEntityQueryBuilder()
					.setKind(ConstantsUtil.TASK)
					.setFilter(PropertyFilter.eq(ConstantsUtil.TRAIT_ID, traitId.toString()))
					.build();
			QueryResults<Entity> results = datastore.run(query);
			
			while (results.hasNext()) {
				Entity result = results.next();
				// Processing on result
				FileDetailsListingDto dto = new FileDetailsListingDto();
				String filePath = result.getString(ConstantsUtil.GCS_FILEPATH);
				
				setIsFromUIAndFileName(dto, filePath);
				populateRecordCountMatchRate(result, dto);
				
				populateStatus(result, dto);
				
				Long startTimestamp = result.getLong(ConstantsUtil.START_TIMESTAMP);
				if(null != startTimestamp && startTimestamp > 0l) {
					dto.setTimestamp(startTimestamp);
					dto.setUploadDate(DateUtility.getFormattedDateString(startTimestamp));
				}
				//   dto.setUploadedBy(uploadedBy);	LEFT commented as this has to be set later

				if (result.contains(ConstantsUtil.EXPANSION_FLOW)
						&& result.getBoolean(ConstantsUtil.EXPANSION_FLOW))
					dto.setExpansion(result.getBoolean(ConstantsUtil.EXPANSION_FLOW)); //CYBG-177
				else 
					dto.setExpansion(false);
	
				setExpansionStatusInDto(result, dto);
				
				// Set Distribution count
				if (result.contains(ConstantsUtil.DISTRIBUTIONS)) {
					
					dto.setDistribution((int)result.getLong(ConstantsUtil.DISTRIBUTIONS));
				} else {
					dto.setDistribution(0);
				}
				
				fileDetailsList.add(dto);
			}
			
			// Sorting list using lambda function Java8 Desc order
			fileDetailsList.sort((FileDetailsListingDto t1, 
					FileDetailsListingDto t2)->t2.getTimestamp().compareTo(t1.getTimestamp()));
			
		} catch (Exception e) {
			LOGGER.error(
					"FileDetailsListingServiceImpl.fileDetailsListing(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"FileDetailsListingServiceImpl.fileDetailsListing(): {} , Error MEssage: {}", e);
		}
		return fileDetailsList;
	}

	/**
	 * @param result
	 * @param dto
	 */
	private void setExpansionStatusInDto(Entity result, FileDetailsListingDto dto) {
		if (ConstantsUtil.ERROR.equalsIgnoreCase(dto.getStatus())) {
			dto.setExpansionStatus(ConstantsUtil.BLANK_SPACE);
		}
		else if (result.contains(ConstantsUtil.EXPANSION_STATUS))
			dto.setExpansionStatus(result.getString(ConstantsUtil.EXPANSION_STATUS)); //CYBG-177 & 194
		else 
			dto.setExpansionStatus(ConstantsUtil.BLANK_SPACE);
	}

	/**
	 * This method will set isFromUI and fileName
	 * @param dto
	 * @param filePath
	 */
	private void setIsFromUIAndFileName(FileDetailsListingDto dto, String filePath) {
		if(null != filePath) {
			// Added code change for CYBG-110
			if(filePath.contains(bucketnameInboundUi)) {
				dto.setIsFromUI(ConstantsUtil.BOOLEAN_TRUE);
			} else {
				dto.setIsFromUI(ConstantsUtil.BOOLEAN_FALSE);
			}
			String [] filePathArr = filePath.split(ConstantsUtil.FORWARD_SLASH);
			if(null != filePathArr && filePathArr.length > 0) {
				dto.setFileName(filePathArr[filePathArr.length - 1]);
			}
		}
	}

	/**
	 * This method sets the Status as per file 
	 * current status from Datastore
	 * @param result
	 * @param dto
	 * @param fileNameList
	 */
	private void populateStatus(Entity result, 
			FileDetailsListingDto dto) {
		long seqCode = result.getLong(ConstantsUtil.SEQ_CODE);
		
		if (seqCode > 0) {
			switch((int)seqCode) {
			case 1: // In Progress File uploaded into NI System
				dto.setStatus(ConstantsUtil.IN_PROGRESS_STATUS); 
				break;
			case 2: // File has been successfully validated
				dto.setStatus(ConstantsUtil.AVAILABLE_STATUS);
				break;
			case 3: // File has been successfully validated
				dto.setStatus(ConstantsUtil.AVAILABLE_STATUS);
				break;
			case 4: 
			case 5: 
			case 6: dto.setStatus(ConstantsUtil.AVAILABLE_STATUS);
				break;	
			case 7: // File distributed to Adobe for processing OR Error at some stage
				if (result.getString(ConstantsUtil.STATUS)
					.contains(ConstantsUtil.INCORRECT_FILE_FORMAT)
					|| result.getString(ConstantsUtil.STATUS)
					.equals(ConstantsUtil.ERROR_VALIDATEFILE_STATUS)) {
					
					dto.setStatus(ConstantsUtil.ERROR);
				} else {
					dto.setStatus(ConstantsUtil.AVAILABLE_STATUS);
				}
				
				break;	
			default:
				break;
			}
		}
		
	}

	/** Set IngestedRecords, matchedRecords and MatchRate
	 * @param result
	 * @param dto
	 */
	private void populateRecordCountMatchRate(Entity result, FileDetailsListingDto dto) {
		String ingestedRecords = result.getString(ConstantsUtil.INBOUND_CNT);
		if(null != ingestedRecords && ingestedRecords.trim().matches(ConstantsUtil.DIGIT_PATTERN_REGEX)) {
			dto.setIngestedRecords(Integer.parseInt(ingestedRecords.trim()));
		}
	}

}
