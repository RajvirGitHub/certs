/**
 * 
 */
package com.networkedinsights.service.impl;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.threeten.bp.Duration;

import com.amazonaws.services.s3.internal.Constants;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.ReadChannel;
import com.google.cloud.RetryOption;
import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.BigQueryOptions;
import com.google.cloud.bigquery.ExtractJobConfiguration;
import com.google.cloud.bigquery.FieldValueList;
import com.google.cloud.bigquery.Job;
import com.google.cloud.bigquery.JobId;
import com.google.cloud.bigquery.JobInfo;
import com.google.cloud.bigquery.QueryJobConfiguration;
import com.google.cloud.bigquery.Table;
import com.google.cloud.bigquery.TableId;
import com.google.cloud.bigquery.TableResult;
import com.google.cloud.datastore.Datastore;
import com.google.cloud.datastore.Entity;
import com.google.cloud.datastore.Key;
import com.google.cloud.datastore.KeyFactory;
import com.google.cloud.datastore.Query;
import com.google.cloud.datastore.QueryResults;
import com.google.cloud.datastore.StructuredQuery;
import com.google.cloud.datastore.StructuredQuery.PropertyFilter;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import com.networkedinsights.dto.DistributionsDto;
import com.networkedinsights.dto.ExpandedAudienceDto;
import com.networkedinsights.exception.BQDatasetException;
import com.networkedinsights.exception.NIDmpException;
import com.networkedinsights.service.IAAMService;
import com.networkedinsights.service.IExpansionAudienceService;
import com.networkedinsights.service.IFileService;
import com.networkedinsights.util.ConstantsUtil;
import com.networkedinsights.util.DateUtility;

/**
 * @author rajvirs
 *
 */
@Service
public class ExpansionAudienceServiceImpl implements IExpansionAudienceService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ExpansionAudienceServiceImpl.class);

	@Autowired
	private Datastore datastore;
	
	@Value("${bucketname.inbound.ui}")
	private String bucketnameInboundUi;
	
	@Value("${pathto.credkey.airflow}")
	private String pathToJsonKey;

	@Value("${project.name}")
	private String projectName;

	@Value("${gcsDataset.name}")
	private String datasetName;

	@Value("${bucketname.intermediate}")
	private String bucketnameIntermediate;
	
	// Environment variable for Prod
	@Value("${airflow.bucket.prod}")
	private String airflowBucketProd;
	
	@Value("${airflow.bucket}")
	private String airflowBucket;

	@Autowired
	private BigQuery bigQuery;
	
	@Autowired
	private IFileService fileService;
	
	@Autowired
	private IAAMService aamServiceImpl;
	
	@Override
	public void storeQntlInfoInDatastore(ExpandedAudienceDto expandedAudienceDto) {

		// Storing Expanded Aud info with selected quantile in DS
		LOGGER.info("ExpansionAudience DS called");
		// Create a Key factory to construct keys associated with this project.
		try {
			// Get Inbound count CYBG 319 |START
			String bqDataset = null;
			QueryResults<Entity> result = fetchFileDetailsByFileName(
					expandedAudienceDto.getFileName());
			if(result.hasNext())
			{
				Entity entity = result.next();
				// Processing on result
				if (entity.contains(ConstantsUtil.BIGQUERY_DATASET) && 
						null != entity.getString(ConstantsUtil.BIGQUERY_DATASET)) {
					LOGGER.info("bqDataset found");
					bqDataset = entity.getString(ConstantsUtil.BIGQUERY_DATASET);
				}
			}
			BigQueryOptions options = getOptions();

			// Insert record in Expanded Aud distribution history

			String queryString = "SELECT Count(DISTINCT twitter_id) FROM "
					+ "`"+bqDataset+"` where qtl <= "
					+expandedAudienceDto.getQuantile()+";";
			TableResult resultCount = fetchExpandedInboundCount(queryString, options.getService());
			LOGGER.info("Inbount count");
			String socialIdCount = findCountOfInboundRecords(resultCount);
			LOGGER.info("Count of Inbound Records:{}", socialIdCount);
			// Get Inbound count |END

			
				KeyFactory keyFactory = datastore.newKeyFactory()
					.setKind(ConstantsUtil.EXPANSION_AUDIENCE);
			LOGGER.info("Key factory");
			Key key = datastore.allocateId(keyFactory.newKey());

			Entity entity = populateExpansionAudienceEntity(
					expandedAudienceDto, key, socialIdCount);
			datastore.put(entity);
		} catch (Exception e) {
			LOGGER.error(
					"ExpansionAudienceServiceImpl.storeQntlInfoInDatastore(): {} , Error Message: {}"
					, e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"ExpansionAudienceServiceImpl.storeQntlInfoInDatastore() : {} , Error Message: {}", e);
		}
	}


	@Override
	public List<ExpandedAudienceDto> fetchExpandedAudienceListing(Integer traitId) {
		List<ExpandedAudienceDto> expandedAudienceList = new ArrayList<>();

		try {
			QueryResults<Entity> results = fetchExpandedAudienceByTraitId(traitId);

			while (results.hasNext()) {
				Entity result = results.next();

				ExpandedAudienceDto dto = new ExpandedAudienceDto();
				populateExpandedAudienceDto(result, dto);

				expandedAudienceList.add(dto);
			}
			
			// Sorting list using lambda function Java8 Desc order
			expandedAudienceList.sort((ExpandedAudienceDto t1, 
					ExpandedAudienceDto t2)->t2.getTimestamp().compareTo(t1.getTimestamp()));
			return expandedAudienceList;

		} catch (Exception e) {
			LOGGER.error(
					"ExpansionAudienceServiceImpl.fetchExpandedAudienceListing() : {} , Error Message: {}"
					, e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"ExpansionAudienceServiceImpl.fetchExpandedAudienceListing() : {} , Error Message: {}", e);
		}
	}

	@Override
	public Long distributeExpandedAudienceIds(String destination, 
			String distributionType, String filename, 
			Long expandedAudListingtimestamp, Integer qtl) {

		String bqDataset = null;
		Long oldTimestamp = null;
		long distributionNo = 1l;
		long distTimestamp = 0l;
		boolean distFlag = true;
		try {

			// Fetch file details by fileName
			LOGGER.info("Distribute Expanded Audience Ids Timestamp: {}", expandedAudListingtimestamp);
			LOGGER.info("Quantile: {}", qtl);
			QueryResults<Entity> result = fetchFileDetailsByFileName(filename);
			if(result.hasNext())
			{
				Entity entity = result.next();
				// Processing on result
				if (entity.contains(ConstantsUtil.BIGQUERY_DATASET) && 
						null != entity.getString(ConstantsUtil.BIGQUERY_DATASET)) {
					LOGGER.info("bqDataset:{}", bqDataset);
					bqDataset = entity.getString(ConstantsUtil.BIGQUERY_DATASET);
				}
				oldTimestamp = entity.getLong(ConstantsUtil.START_TIMESTAMP);

				LOGGER.info("oldTimestamp:{}", oldTimestamp);
			}

			distributionNo = findDistributionNo(expandedAudListingtimestamp, distributionNo);

			// Update Expanded Audience Listing with distribution count
			
			String socialIdCount = updateExpandedAudienceListing(expandedAudListingtimestamp,
					distributionNo);
			
			
			// Check AudDistlist instead
			distFlag = checkAndPerformRedistribution(destination, distributionType, filename,
					expandedAudListingtimestamp, qtl, oldTimestamp, distributionNo);
			
			if (distFlag) {
				// Distribute for 1st time, store record in DS
				if( null == bqDataset) {
					LOGGER.error("Big query Dataset not present in Datastore.");
					throw new BQDatasetException(ConstantsUtil.BLANK_BQDATASET);
				}
				
				 //Insert record in Expanded Aud distribution history

				distTimestamp = storeExpandedAudDistributionInDS(filename, destination, 
						distributionType, socialIdCount, 
						distributionNo, expandedAudListingtimestamp);
					
			}
		} catch (BQDatasetException e) {
        	throw e;
        } catch (Exception e){
			LOGGER.error(
					"ExpansionAudienceServiceImpl.readBigQueryData(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"ExpansionAudienceServiceImpl.readBigQueryData(): {} , Error MEssage: {}", e);
		}
		
        return distTimestamp;
	}
	

	/**
	 * @return
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	private BigQueryOptions getOptions() throws IOException {
		LOGGER.info("before creating options");
		BigQueryOptions options = null;
		options = BigQueryOptions.newBuilder()
				.setProjectId(projectName)
				.setCredentials(GoogleCredentials.fromStream(
						new FileInputStream(pathToJsonKey)))
				.build();
		LOGGER.info("after options");
		return options;
	}

	/**
	 * Fetch result from destination table
	 * @param query
	 * @throws InterruptedException 
	 */
	private TableResult fetchExpandedInboundCount(String 
			queryString, BigQuery bigQuery2) throws InterruptedException {

		QueryJobConfiguration queryConfig = QueryJobConfiguration.newBuilder(queryString)
				// Save the results of the query to a permanent table.
				.setUseLegacySql(false)
				.build();
		JobId jobId = JobId.of(UUID.randomUUID().toString());
		LOGGER.info("Fetching results from Expanded Aud table");
		Job queryJob = bigQuery2.create(JobInfo.newBuilder(
				queryConfig).setJobId(jobId).build());
		queryJob = queryJob.waitFor();
		return queryJob.getQueryResults();
	}


	/**
	 * Find count of Inbound Records
	 * @param resultCount
	 * @return
	 */
	private String findCountOfInboundRecords(TableResult resultCount) {
		String inboundCount = null;
		LOGGER.info("Finding count of InboundRecs");
		for (FieldValueList row : resultCount.iterateAll()) {
			inboundCount = (String) row.get(0).getValue();
			
		}
		return inboundCount;
	}


	/**
	 * To Delete existing table
	 * @param oldTimestamp
	 */
	private void deleteExistingTable(Long oldTimestamp) {
		// ADDED CODE TO Delete existing table | START
		TableId tableId = TableId.of(datasetName,
				ConstantsUtil.DESTINATION_TABLE +"exp_" +oldTimestamp);
		boolean deleted = bigQuery.delete(tableId);
		if(deleted) {
			LOGGER.info("Deleted the table");
		} else {
			LOGGER.info("Table not present");
		}
		// ADDED CODE TO Delete existing table | END
	}


	/**
	 * @param destination
	 * @param distributionType
	 * @param filename
	 * @param expandedAudListingtimestamp
	 * @param qtl
	 * @param oldTimestamp
	 * @param distributionNo
	 * @param distFlag
	 * @return
	 */
	private boolean checkAndPerformRedistribution(String destination, String distributionType, String filename,
			Long expandedAudListingtimestamp, Integer qtl, Long oldTimestamp, long distributionNo) {
		
		boolean localDistFlag = true;
		QueryResults<Entity> expAudResult = fetchDHByStartTimestamp(
				expandedAudListingtimestamp);
		while (expAudResult.hasNext()) {
			// Check if this was earlier processed successfully
			// If yes then simply upload file to S3
			Entity en = expAudResult.next();
			if ((distributionNo-1) == en.getLong(
					ConstantsUtil.DISTRIBUTIONS) && 
					(ConstantsUtil.DEST_ADOBE).equalsIgnoreCase(en.getString(
							ConstantsUtil.DESTINATION)) && ConstantsUtil.FILE_DISTRIBUTED
					.equalsIgnoreCase(en.getString(ConstantsUtil.STATUS))) {

				// Insert record in Expanded Aud RE-distribution history
				long reDistTimestamp = storeExpandedAudReDistributionInDS(filename, destination, 
						distributionType, en,
						distributionNo, expandedAudListingtimestamp);
				
				// Call uploading file to s3 
				// Storing file to S3 bucket and updating Datastore
				String destFileName = ConstantsUtil.NI_INTERMEDIATE + oldTimestamp 
						+ ConstantsUtil.EXP_QTL + qtl+".tsv";
				String inboundAudFileName = fileService.uploadExpandedInboundFileToS3(
						oldTimestamp, destFileName, distributionType);
				
				//Updating Expanded Audience distribution history
				updateExpandedAudDistHist(reDistTimestamp, ConstantsUtil.FILE_DISTRIBUTED,
						ConstantsUtil.UPLOAD_INBOUND_FILE_TO_S3_SEQ_CODE, inboundAudFileName);
				
				localDistFlag = false;
				break;
			}
		}
		return localDistFlag;
	}


	/**
	 * @param expandedAudListingtimestamp
	 * @param distributionNo
	 * @return
	 */
	private long findDistributionNo(Long expandedAudListingtimestamp, long distributionNo) {
		Map<Long, String> map = new HashMap<>();
		QueryResults<Entity> result2 = fetchDHByStartTimestamp(
			expandedAudListingtimestamp);
		while (result2.hasNext())
		{
			Entity entity = result2.next();
			map.put(entity.getLong(ConstantsUtil.DISTRIBUTIONS)
					, entity.getString(ConstantsUtil.DISTRIBUTION_TYPE));
		}

		if (!map.isEmpty()) {
			TreeMap<Long, String> treeMap = new TreeMap<>(
		            (Comparator<Long>) (o1, o2) -> o2.compareTo(o1));
			treeMap.putAll(map);
			// distributionType = treeMap firstEntry getValue
			distributionNo = treeMap.firstKey() + 1l;
		}
		return distributionNo;
	}

	@Override
	public List<DistributionsDto> getDistributionsHistory(Long timestamp) {
		List<DistributionsDto> distributionsDtoList = new ArrayList<>();
		
		try {
			QueryResults<Entity> queryResult = fetchExpAudDistributionsByTimestamp(timestamp);
			
			while (queryResult.hasNext()) {
				Entity entity = queryResult.next();
				DistributionsDto distributionsDto = new DistributionsDto();

				populateDistributionsDto(entity, distributionsDto);

				populateStatus(entity, distributionsDto);
				
				distributionsDtoList.add(distributionsDto);
			}
			
			// Sorting list using Java8 lambda function in Descending order
			distributionsDtoList.sort((DistributionsDto t1, 
					DistributionsDto t2)->t2.getDistributions().compareTo(t1.getDistributions()));
			return distributionsDtoList;
		} catch (Exception e) {
			LOGGER.error(
					"ExpansionAudienceServiceImpl.getDistributionsHistory(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"ExpansionAudienceServiceImpl.getDistributionsHistory(): {} , Error MEssage: {}", e);
		}
	}
	
	/**
	 * fetch Expanded Audience distributions
	 * @param fileName
	 * @return
	 */
	private QueryResults<Entity> fetchExpAudDistributionsByTimestamp(Long timestamp) {
		
		Query<Entity> query = Query.newEntityQueryBuilder()
				.setKind(ConstantsUtil.EXPANDED_AUD_DIST_HISTORY)                                
				.setFilter(PropertyFilter.eq(ConstantsUtil.START_TIMESTAMP, timestamp))
				.build();
		return datastore.run(query);
	}
	
	/**
	 * Populate DistributionsDto object
	 * @param entity
	 * @param distributionsDto
	 */
	private void populateDistributionsDto(Entity entity, DistributionsDto distributionsDto) {
		distributionsDto.setDestination(entity.getString(
				ConstantsUtil.DESTINATION));
		distributionsDto.setDistributionDate(entity.getString(
				ConstantsUtil.DISTRIBUTION_DATE));
		distributionsDto.setFileName(entity.getString(
				ConstantsUtil.FILENAME));
		distributionsDto.setInboundRecords(entity.getString(
				ConstantsUtil.INBOUND_CNT));
		distributionsDto.setMatchedRecords(entity.getString(
				ConstantsUtil.MATCHED_CNT));
		int distributionNo = (int) entity.getLong(
				ConstantsUtil.DISTRIBUTIONS);
		distributionsDto.setDistributions(distributionNo);
		distributionsDto.setDhTimeStamp(entity.getLong(
				ConstantsUtil.DIST_TIMESTAMP));		// Added to keep track of unique records
		
		if (entity.contains(ConstantsUtil.DISTRIBUTION_TYPE)) {
			distributionsDto.setDistributionType(entity.
					getString(ConstantsUtil.DISTRIBUTION_TYPE));
		}
		
		// Setting Adobe Inbound Aud Filename
		if (entity.contains(ConstantsUtil.INBOUND_AUD_FILENAME)) {
			distributionsDto.setAdobeInboundAudFile(entity
					.getString(ConstantsUtil.INBOUND_AUD_FILENAME));
		}
		// Setting jobIdName | Changes for CYBG-310 |
		// fetch job stats for distribution type=email, all_email in ni-leads distribution.
		if (entity.contains(ConstantsUtil.JOB_ID_NAME)) {
			distributionsDto.setJobIdName(entity.
					getString(ConstantsUtil.JOB_ID_NAME));
		}
	}

	/**
	 * This method sets the Status as per file 
	 * current status from Datastore
	 * @param result
	 * @param dto
	 * @param fileNameList
	 */
	private void populateStatus(Entity entity, DistributionsDto 
			distributionsDto) {

		List<String> fileNameList = aamServiceImpl.fetchFileNameList();

		if (ConstantsUtil.FILE_DISTRIBUTED.equalsIgnoreCase(entity.getString(
				ConstantsUtil.STATUS)) && fileNameList.contains(entity.getString(
						ConstantsUtil.INBOUND_AUD_FILENAME))) {
			// File distributed to Adobe for processing OR Error at some stage
			distributionsDto.setStatus(ConstantsUtil.PROCESSING_COMPLETED);

		} else {
			distributionsDto.setStatus(entity.getString(ConstantsUtil.STATUS));
		}
		
		// Match Rate
		String ingestedRecords = entity.getString(ConstantsUtil.INBOUND_CNT);

		String matchedRecords = entity.getString(ConstantsUtil.MATCHED_CNT);

		if(null != ingestedRecords && 
				ingestedRecords.trim().matches(ConstantsUtil.DIGIT_PATTERN_REGEX)
				&& null != matchedRecords && 
				matchedRecords.trim().matches(ConstantsUtil.DIGIT_PATTERN_REGEX)) {

			Integer matchRate = (int)Math.round((Double.parseDouble(matchedRecords.trim())
					/Double.parseDouble(ingestedRecords.trim()))*100);
			distributionsDto.setMatchRate(matchRate + "%");
		}

	}
	
	

	/** 
	 * Find count of Adobeuuids
	 * @param resultCount
	 */
	private Long findCountOfAdobeuuids(TableResult resultCount) {
		Long adobeuuidCount2 = 0l;
		for (FieldValueList row : resultCount.iterateAll()) {
			String adobeuuidCount = (String) row.get(0).getValue();
			adobeuuidCount2 = Long.parseLong(adobeuuidCount);
		}
		return adobeuuidCount2;
	}

	/**
	 * @param expandedAudienceDto
	 * @param timeStampAsId
	 * @param createdDate
	 * @param key
	 * @return
	 */
	private Entity populateExpansionAudienceEntity(
			ExpandedAudienceDto expandedAudienceDto,
			Key key, String socialIdCount) {

		long timeStampAsId = Instant.now().toEpochMilli();
		String createdDate = DateUtility.getFormattedDateString(timeStampAsId);

		Entity entity = Entity.newBuilder(key)
				.set(ConstantsUtil.TIMESTAMP, timeStampAsId)
				.set(ConstantsUtil.DISTRIBUTIONS, ConstantsUtil.ZERO_VAL)	// Will increment on subsequent Distributions initiationfrom UI
				.set(ConstantsUtil.FILENAME, expandedAudienceDto.getFileName())
				.set(ConstantsUtil.STATUS, ConstantsUtil.AVAILABLE_STATUS)
				.set(ConstantsUtil.RECORDS, socialIdCount)	
				.set(ConstantsUtil.CREATED_DATE, createdDate)
				.set(ConstantsUtil.TRAIT_ID, expandedAudienceDto.getTraitId())
				//	.set(ConstantsUtil.START_TIMESTAMP, startTimeStamp)
				.set(ConstantsUtil.SELECTED_QUANTILE, expandedAudienceDto.getQuantile())
				.build();
		LOGGER.info("Entity object set for expansion Aud");
		return entity;
	}

	/**
	 * @param traitId
	 * @return
	 */
	private QueryResults<Entity> fetchExpandedAudienceByTraitId(Integer traitId) {
		StructuredQuery<Entity> query = Query.newEntityQueryBuilder()
				.setKind(ConstantsUtil.EXPANSION_AUDIENCE)
				.setFilter(PropertyFilter.eq(ConstantsUtil.TRAIT_ID, traitId.toString()))
				.build();
		return datastore.run(query);
	}

	/**
	 * @param result
	 * @param dto
	 */
	private void populateExpandedAudienceDto(Entity result, ExpandedAudienceDto dto) {
		dto.setFileName(result.getString(ConstantsUtil.FILENAME));
		dto.setRecords(result.getString(ConstantsUtil.RECORDS));
		dto.setStatus(result.getString(ConstantsUtil.STATUS));
		dto.setCreatedDate(result.getString(ConstantsUtil.CREATED_DATE));
		dto.setQuantile((int)result.getLong(ConstantsUtil.SELECTED_QUANTILE));
		dto.setTimestamp(result.getLong(ConstantsUtil.TIMESTAMP));
		// Set Distribution count
		if (result.contains(ConstantsUtil.DISTRIBUTIONS)) {

			dto.setDistributions((int)result.getLong(ConstantsUtil.DISTRIBUTIONS));
		} else {
			dto.setDistributions(0);
		}
	}

	/**
	 * @param dto
	 * @return
	 */
	private QueryResults<Entity> fetchFileDetailsByFileName(String jobId) {
		String filePath = populateFilePath(jobId);

		LOGGER.info("Filepath: {}", filePath);
		// Fetch existing Datastore entry for a filename
		StructuredQuery<Entity> query = Query.newEntityQueryBuilder()
				.setKind(ConstantsUtil.TASK)
				.setFilter(PropertyFilter.eq(ConstantsUtil.GCS_FILEPATH, filePath))
				.build();
		return datastore.run(query);
	}


	/**
	 * @param jobId
	 * @return
	 */
	private String populateFilePath(String jobId) {
		String filePath = null;
		if(null != jobId && jobId.contains(ConstantsUtil.CSV_EXTN)) {
			filePath = bucketnameInboundUi + ConstantsUtil.FORWARD_SLASH 
					+ jobId;
		} else {
			filePath = bucketnameInboundUi + ConstantsUtil.FORWARD_SLASH 
					+ jobId + ConstantsUtil.CSV_EXTN;
		}
		return filePath;
	}

	/**
	 * Run join query and copy the result in a new table
	 * @param query
	 */
	private TableResult runCopyJoinQueryData(String query, Long
			timestamp, BigQuery bigQuery2) throws InterruptedException
	{
		String tableName = ConstantsUtil.DESTINATION_TABLE+"exp_"+timestamp;
		LOGGER.info("Run join query and copy the result in a new ni_adobe_uuid_sync_ table");
		QueryJobConfiguration queryConfig = QueryJobConfiguration.newBuilder(query)
				// Save the results of the query to a permanent table.
				.setDestinationTable(TableId.of(datasetName, 
						tableName))
				.setAllowLargeResults(true)
				.setUseLegacySql(false)
				.build();
		LOGGER.info("After queryConfig tableName:{}", tableName);
		JobId jobId = JobId.of(UUID.randomUUID().toString());
		LOGGER.info("After jobid");
		Job queryJob = bigQuery2.create(JobInfo.newBuilder(queryConfig).setJobId(jobId).build());
		LOGGER.info("During queryJob");
		queryJob = queryJob.waitFor(
				RetryOption.initialRetryDelay(Duration.ofSeconds(1)),
				RetryOption.totalTimeout(Duration.ofMinutes(3)));
		
		Thread.sleep(40000L);	// Added sleep for 40secs to test if table gets created by then
		LOGGER.info("queryJob.getStatus().getError():{}",queryJob.getStatus().getError());
		LOGGER.info("queryJob.getStatus.getState(): {}", queryJob.getStatus().getState());
		
		// Check the table
		
		 
		 
		// Adding for solving error when table size is huge
		// Wait for the job to complete
		while(!queryJob.isDone()){
			LOGGER.info("Waiting for job to complete");
			Thread.sleep(2000L);
		}
		if (queryJob.getStatus().getError() == null) {
			LOGGER.info("QueryJob Exported Successfully to Table");
		} 
		else {
			LOGGER.info("QueryJob Not Exported to Table");
		}
		////
		
		return queryJob.getQueryResults();
	}
	
	/**
	 * Put the Join Query Result in a CSV file and load this file to GCS bucket
	 * @param table
	 * @throws InterruptedException 
	 */
	private void putResultinGCS2(Table table, String destTableName, 
			Long timestamp) throws InterruptedException
	{
		String bucketUrl = ConstantsUtil.SOURCEURI
				+ bucketnameIntermediate + "/"+destTableName;

		LOGGER.info("bucketUrl and tmstmp: {}", timestamp);

		ExtractJobConfiguration extractConfiguration = ExtractJobConfiguration
				.newBuilder(table.getTableId(), bucketUrl)
				.setPrintHeader(false)
				.setFieldDelimiter("\t")
				//.setFormat("NEWLINE_DELIMITED_JSON") By default it is CSV so commenting
				.build();
		LOGGER.info("extractConfiguration");
		Job job = bigQuery.create(JobInfo.of(extractConfiguration));
		job = job.waitFor();
		LOGGER.info("startedJob job.getStatus():{}",job.getStatus().getError());
		LOGGER.info("startedJob job.isDone():{}",job.isDone());
		// Wait for the job to complete
		while(!job.isDone()){
			LOGGER.info("Waiting for job to complete");
			Thread.sleep(2000L);
		}
		if (job.getStatus().getError() == null) {
			LOGGER.info("Query Result Exported Successfully to GCS");
		} 
		else {
			LOGGER.info("Query Result Not Exported to GCS");
		}

	}
	
	
	/**
	 * This will store Distribution data in DS
	 * @param originalFilename
	 * @param destination
	 * @param inboundRecords
	 */
	private Long storeExpandedAudDistributionInDS(String originalFilename
			, String destination, String distributionType, String inboundRecords, 
			Long distributionNo, Long startTimeStamp) {

		LOGGER.info("Expansion Distribution DS called startTimeStamp: {}",startTimeStamp);
		LOGGER.info("Expansion distributionNo: {}",distributionNo);
		// Create a Key factory to construct keys associated with this project.
		long dhTimeStamp = Instant.now().toEpochMilli();
		String distributionDate = DateUtility.getFormattedDateString(dhTimeStamp);
		KeyFactory keyFactory = datastore.newKeyFactory()
				.setKind(ConstantsUtil.EXPANDED_AUD_DIST_HISTORY);
		LOGGER.info(ConstantsUtil.KEY_FACTORY);
		Key key = datastore.allocateId(keyFactory.newKey());
		Entity task = Entity.newBuilder(key)
				.set(ConstantsUtil.DIST_TIMESTAMP, dhTimeStamp)
				.set(ConstantsUtil.DISTRIBUTIONS, distributionNo)
				.set(ConstantsUtil.FILENAME, originalFilename)
				.set(ConstantsUtil.STATUS, ConstantsUtil.BLANK_SPACE)
				.set(ConstantsUtil.INBOUND_CNT, inboundRecords)	
				.set(ConstantsUtil.MATCHED_CNT, ConstantsUtil.BLANK_SPACE)	// UPDATED IN LATER STAGE
				.set(ConstantsUtil.DISTRIBUTION_DATE, distributionDate)
				.set(ConstantsUtil.DESTINATION, destination)
				.set(ConstantsUtil.START_TIMESTAMP, startTimeStamp)	
				.set(ConstantsUtil.SEQ_CODE, ConstantsUtil.VALIDATEFILE_SEQ_CODE) //file is already VALIDATED
				.set(ConstantsUtil.INBOUND_AUD_FILENAME, ConstantsUtil.BLANK_SPACE) // UPDATED IN LATER STAGE
				.set(ConstantsUtil.DISTRIBUTION_TYPE, distributionType)
				.build();
		datastore.put(task);
		return dhTimeStamp;
	
	}
	
	/**
	 * Fetch result from destination table
	 * @param query
	 */
	private TableResult fetchDestinationTableCount(String query,
			BigQuery bigQuery2) throws InterruptedException
	{
		QueryJobConfiguration queryConfig = QueryJobConfiguration.newBuilder(query)
				// Save the results of the query to a permanent table.
				.setUseLegacySql(false)
				.build();
		JobId jobId = JobId.of(UUID.randomUUID().toString());
		LOGGER.info("Fetching results from destination table");
		Job queryJob = bigQuery2.create(JobInfo.newBuilder(queryConfig).setJobId(jobId).build());
		queryJob = queryJob.waitFor();
		return queryJob.getQueryResults();
	}
	
	/**
	 * fetch DH by starttimestamp
	 * @param startTimeStamp
	 * @return
	 */
	private QueryResults<Entity> fetchDHByStartTimestamp(long startTimeStamp) {
		// Build the Query
		Query<Entity> query = Query.newEntityQueryBuilder()
				.setKind(ConstantsUtil.EXPANDED_AUD_DIST_HISTORY)                               
				.setFilter(PropertyFilter.eq(ConstantsUtil.START_TIMESTAMP, startTimeStamp))
				.build();
		return datastore.run(query);
	}
	
	/**
	 * fetch DH by distribution timestamp
	 * @param startTimeStamp
	 * @return
	 */
	private QueryResults<Entity> fetchDHByDistTimestamp(long startTimeStamp) {
		// Build the Query
		Query<Entity> query = Query.newEntityQueryBuilder()
				.setKind(ConstantsUtil.EXPANDED_AUD_DIST_HISTORY)                               
				.setFilter(PropertyFilter.eq(ConstantsUtil.DIST_TIMESTAMP, startTimeStamp))
				.build();
		return datastore.run(query);
	}
	
	/**
	 * Update Expanded Audience distribution history
	 * @param distTimestamp
	 * @param adobeuuidCount
	 */
	private void updateExpandedAudDistHist(long distTimestamp, String adobeuuidCount) {

		QueryResults<Entity> result = fetchDHByDistTimestamp(
				distTimestamp);
		if (result.hasNext()) {
			LOGGER.info("updateExpandedAudDistHist: {}", distTimestamp);
			Entity entity = result.next();
			Key entityKey = entity.getKey();
			entity = Entity.newBuilder(datastore.get(entityKey))
					.set(ConstantsUtil.STATUS, ConstantsUtil.FILE_IDS_MATCHED)
					.set(ConstantsUtil.SEQ_CODE, ConstantsUtil.OUTBOUND_FILE_FOR_GCS_SEQ_CODE)
					.set(ConstantsUtil.MATCHED_CNT, adobeuuidCount)
					.build();
			datastore.put(entity);
		}
	}

	/**
	 * Update Expanded Audience distribution history
	 * @param distTimestamp
	 * @param status
	 * @param seqCode
	 */
	private void updateExpandedAudDistHist(long distTimestamp, 
			String status, Integer seqCode, String inboundAudFileName) {
		
		QueryResults<Entity> result = fetchDHByDistTimestamp(
				distTimestamp);
		if (result.hasNext()) {
			LOGGER.info("updateExpandedAudDistHist3:{}", distTimestamp);
			Entity entity = result.next();
			Key entityKey = entity.getKey();
			entity = Entity.newBuilder(datastore.get(entityKey))
					.set(ConstantsUtil.STATUS, status)
					.set(ConstantsUtil.SEQ_CODE, seqCode)
					.set(ConstantsUtil.INBOUND_AUD_FILENAME, inboundAudFileName)
					.build();
			datastore.put(entity);
		}
		
	}

	/**
	 * Update expanded Audience listing with distribution count
	 * @param expandedAudListingtimestamp
	 * @param distributionNo
	 */
	private String updateExpandedAudienceListing(Long 
			expandedAudListingtimestamp, long distributionNo) {
		QueryResults<Entity> result = fetchAudListingByTimestamp(
				expandedAudListingtimestamp);
		String inboundCount="";
		if (result.hasNext()) {
		
			LOGGER.info("updating expanded audience listing:{}",expandedAudListingtimestamp);
			LOGGER.info("updating expanded audience listing distNo:{}",distributionNo);
			Entity entity = result.next();
			inboundCount=entity.getString(ConstantsUtil.RECORDS);
			Key entityKey = entity.getKey();
			entity = Entity.newBuilder(datastore.get(entityKey))
					.set(ConstantsUtil.DISTRIBUTIONS, distributionNo)
					.build();
			
			datastore.put(entity);
		}
		return inboundCount;
	}

	/**
	 * Fetch Expanded Audience listing by timestamp
	 * @param expandedAudListingtimestamp
	 * @return
	 */
	private QueryResults<Entity> fetchAudListingByTimestamp(Long expandedAudListingtimestamp) {
		// Build the Query
		Query<Entity> query = Query.newEntityQueryBuilder()
				.setKind(ConstantsUtil.EXPANSION_AUDIENCE)                               
				.setFilter(PropertyFilter.eq(ConstantsUtil.TIMESTAMP, expandedAudListingtimestamp))
				.build();
		return datastore.run(query);
	}


	/**
	 * This will store Distribution data in DS
	 * @param filename
	 * @param destination
	 * @param distributionType
	 * @param en
	 * @param distributionNo
	 * @param expandedAudListingtimestamp
	 * @return
	 */
	private long storeExpandedAudReDistributionInDS(String filename, String destination, String distributionType,
			Entity en, long distributionNo, Long expandedAudListingtimestamp) {

		LOGGER.info("Expansion RE-Distribution DS called");
		// Create a Key factory to construct keys associated with this project.
		long dhTimeStamp = Instant.now().toEpochMilli();
		String distributionDate = DateUtility.getFormattedDateString(dhTimeStamp);
		KeyFactory keyFactory = datastore.newKeyFactory()
				.setKind(ConstantsUtil.EXPANDED_AUD_DIST_HISTORY);
		LOGGER.info(ConstantsUtil.KEY_FACTORY);
		Key key = datastore.allocateId(keyFactory.newKey());
		Entity task = Entity.newBuilder(key)
				.set(ConstantsUtil.DIST_TIMESTAMP, dhTimeStamp)
				.set(ConstantsUtil.DISTRIBUTIONS, distributionNo)
				.set(ConstantsUtil.FILENAME, filename)
				.set(ConstantsUtil.STATUS, ConstantsUtil.BLANK_SPACE)
				.set(ConstantsUtil.INBOUND_CNT, en.getString(ConstantsUtil.INBOUND_CNT))	
				.set(ConstantsUtil.MATCHED_CNT, en.getString(ConstantsUtil.MATCHED_CNT))	// UPDATED IN LATER STAGE
				.set(ConstantsUtil.DISTRIBUTION_DATE, distributionDate)
				.set(ConstantsUtil.DESTINATION, destination)
			//	.set(ConstantsUtil.TRAIT_ID, traitId.toString())
				.set(ConstantsUtil.START_TIMESTAMP, expandedAudListingtimestamp)	
				.set(ConstantsUtil.SEQ_CODE, ConstantsUtil.VALIDATEFILE_SEQ_CODE) //file is already VALIDATED
				.set(ConstantsUtil.INBOUND_AUD_FILENAME, ConstantsUtil.BLANK_SPACE) // UPDATED IN LATER STAGE
				.set(ConstantsUtil.DISTRIBUTION_TYPE, distributionType)
				.build();
		datastore.put(task);
		return dhTimeStamp;
	}


	@Override
	public Long distributeAndCreateTable(String filename, 
			Integer qtl, Long distTimestamp, Long timeoutTmpstp,
			String distributionType) {

		// Distributing (1st time for a qtl) 
		BigQueryOptions options = null;
		String bqDataset = null;
		String traitId = null;
		Long oldTimestamp = null;

		try {
			// To Track multiple calls of same API (after 30s timeout)
			QueryResults<Entity> timeoutResult = fetchTimeoutResultByTimeoutTmpstp(timeoutTmpstp);
			if(timeoutResult.hasNext())
			{
				LOGGER.info("API TRACK TIMEOUT DS: Duplicate request fired");
				return -1l;
				
			} else {
				// Add record in DS to track API timeout
				KeyFactory keyFactory = datastore.newKeyFactory()
						.setKind(ConstantsUtil.API_TRACK_TIMEOUT_DS);
				LOGGER.info("Key factory API TRACK TIMEOUT DS");

				Key key = datastore.allocateId(keyFactory.newKey());
				Entity task = Entity.newBuilder(key)
						.set(ConstantsUtil.TIMEOUT_TMPSTMP, timeoutTmpstp)
						.set(ConstantsUtil.FILENAME, filename)
						.set(ConstantsUtil.SELECTED_QUANTILE, qtl)
						.set(ConstantsUtil.DIST_TIMESTAMP, distTimestamp)
						.build();
				datastore.put(task);
				LOGGER.info("API TRACK TIMEOUT Datastore updated");
			}
			
			
			QueryResults<Entity> result = fetchFileDetailsByFileName(filename);
			if(result.hasNext())
			{
				Entity entity = result.next();
				// Processing on result
				if (entity.contains(ConstantsUtil.BIGQUERY_DATASET) && 
						null != entity.getString(ConstantsUtil.BIGQUERY_DATASET)) {
					LOGGER.info("bqDataset:{}", bqDataset);
					bqDataset = entity.getString(ConstantsUtil.BIGQUERY_DATASET);
				}
				if (entity.contains(ConstantsUtil.TRAIT_ID) && 
						null != entity.getString(ConstantsUtil.TRAIT_ID)) {
					traitId = entity.getString(ConstantsUtil.TRAIT_ID);
				}
				oldTimestamp = entity.getLong(ConstantsUtil.START_TIMESTAMP);

				LOGGER.info("oldTimestamp:{}", +oldTimestamp);
			}

			options = getOptions();
			BigQuery bigQuery2 = options.getService();
			LOGGER.info("bigQuery2");

			// ADDED CODE TO Delete existing table
			deleteExistingTable(oldTimestamp);

			// Make changes here to take table name from Datastore
			LOGGER.info("bigQuery2 queryWithView3");
			// Modified query to include trait Id and delimeter in Select
			String queryWithView3 = "SELECT DISTINCT "
					+ "xref_table.adobe_uuid as auuid, "
					+ "'d_sid=" + traitId+"' as traitIds "
					+ "FROM "
					+ "`"+bqDataset+"` as results "
					+ "JOIN `"+ projectName+ ConstantsUtil.POINT + datasetName
					+ ConstantsUtil.POINT+ "adobe_xref_view` as xref_table "
					+ "ON "
					+ "results.twitter_id = xref_table.twitter_ID "
					+ "WHERE "
					+ "results.qtl <= "+ qtl
					+ ";";	// GROUP BY 1 Limit 3500000

			// This method will copy data to a new table
			LOGGER.info("Before runCopyJoinQueryData");
			runCopyJoinQueryData(queryWithView3, oldTimestamp, bigQuery2);
			LOGGER.info("After runCopyJoinQueryData");
			
			// Calling sleep
			TimeUnit.SECONDS.sleep(30);
			
			distributeFindCountAndStoreInGCS(filename, 
					qtl, distTimestamp, bqDataset, oldTimestamp);
			
			TimeUnit.SECONDS.sleep(7);
			distributeStoreInGCS(qtl, oldTimestamp);
			
			TimeUnit.SECONDS.sleep(15);
			distributeFindCountAndStoreInS3(distributionType, filename, 
					qtl, distTimestamp, oldTimestamp);

		} catch (Exception e) {
			LOGGER.error(
					"ExpansionAudienceServiceImpl.distributeAndCreateTable():{} , Error Message : {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"ExpansionAudienceServiceImpl.distributeAndCreateTable():{} , Error Message : {}", e);
		}
		return distTimestamp;

	}

	@Override
	public Long distributeFindCountAndStoreInGCS(String filename, 
			Integer qtl, Long distTimestamp, 
			String bqDataset, Long oldTimestamp) {

		BigQueryOptions options = null;

		try{

			Thread.sleep(100l);		// Sleep for 100ms
			// Finding matched adobeuuid count
			options = getOptions();

			String countAdobeuuids = "SELECT "
					+ "COUNT( DISTINCT xref_table.adobe_uuid) "
					+ "FROM "
					+ "`"+bqDataset+"` as results "
					+ "JOIN `"+ projectName+ ConstantsUtil.POINT + datasetName
					+ ConstantsUtil.POINT+ "adobe_xref_view` as xref_table "
					+ "ON "
					+ "results.twitter_id = xref_table.twitter_ID "
					+ "WHERE "
					+ "results.qtl <= "+ qtl
					+ ";";
			LOGGER.info("Query for countAdobeuuids:{}",countAdobeuuids);
			//COMMENTED as this gives wrong count
			BigQuery bigQuery2 = options.getService();

			TableResult resultCount = fetchDestinationTableCount(countAdobeuuids, bigQuery2);	// Lets try changing here by using above join query for count

			Long adobeuuidCount = findCountOfAdobeuuids(resultCount);

			//Updating Expanded Audience distribution history
			LOGGER.info("adobeuuidCount:{}",adobeuuidCount);
			updateExpandedAudDistHist(distTimestamp, adobeuuidCount.toString());

		} catch (Exception e) {
			LOGGER.error(
					"ExpansionAudienceServiceImpl.distributeFindCountAndStoreInGCS():{} , Error Message : {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"ExpansionAudienceServiceImpl.distributeFindCountAndStoreInGCS():{} , Error Message : {}", e);
		}
		return oldTimestamp;
	}


	@Override
	public void distributeFindCountAndStoreInS3(String distributionType,
			String filename, Integer qtl, Long distTimestamp, 
			Long oldTimestamp) {

		try {
			// Storing file to S3 bucket and updating Datastore
			String destFileName = ConstantsUtil.NI_INTERMEDIATE + oldTimestamp 
					+ ConstantsUtil.EXP_QTL + qtl+".tsv";
			String inboundAudFileName = fileService.uploadExpandedInboundFileToS3(
					oldTimestamp, destFileName, distributionType);

			//Updating Expanded Audience distribution history
			if (null != inboundAudFileName) {
				updateExpandedAudDistHist(distTimestamp, ConstantsUtil.FILE_DISTRIBUTED,
						ConstantsUtil.UPLOAD_INBOUND_FILE_TO_S3_SEQ_CODE, inboundAudFileName);
			}

			LOGGER.info("ADOBE_UUID file Uploaded successfully.");
		} catch (Exception e) {
			LOGGER.error(
					"ExpansionAudienceServiceImpl.distributeFindCountAndStoreInS3():{} , Error Message : {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"ExpansionAudienceServiceImpl.distributeFindCountAndStoreInS3():{} , Error Message : {}", e);
		}
	}


	@Override
	public void distributeStoreInGCS(Integer qtl, Long oldTimestamp) {
		try {
			
			Table destTable = bigQuery.getTable(datasetName, 
					ConstantsUtil.DESTINATION_TABLE +"exp_" +oldTimestamp);
			
			String destFileName = ConstantsUtil.NI_INTERMEDIATE + oldTimestamp 
					+ ConstantsUtil.EXP_QTL + qtl+".tsv";
			
			LOGGER.info("After getTable");
			putResultinGCS2(destTable, destFileName, oldTimestamp);
			LOGGER.info("After putResultinGCS2");
		} catch (Exception e) {
			LOGGER.error(
					"ExpansionAudienceServiceImpl.distributeStoreInGCS():{} , Error Message : {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"ExpansionAudienceServiceImpl.distributeStoreInGCS():{} , Error Message : {}", e);
		}
	}

	/**
	 * @param dto
	 * @return
	 */
	private QueryResults<Entity> fetchTimeoutResultByTimeoutTmpstp(Long timeoutTmpstp) {

		LOGGER.info("TimeoutTmpstp: {}", timeoutTmpstp);
		// Fetch existing Datastore entry for a filename
		StructuredQuery<Entity> query = Query.newEntityQueryBuilder()
				.setKind(ConstantsUtil.API_TRACK_TIMEOUT_DS)
				.setFilter(PropertyFilter.eq(ConstantsUtil.TIMEOUT_TMPSTMP, timeoutTmpstp))
				.build();
		return datastore.run(query);
	}


	@Override
	public Boolean expandingSeedListFile(String filename, Long timestamp) {

		Storage storage = StorageOptions.getDefaultInstance().getService();
		LOGGER.info("Expanding SeedList File timestamp: {}", timestamp);
		try (ReadChannel reader = storage.reader(bucketnameInboundUi, 
				filename)) {
			// Reading file data from inbound UI bucket
			long startTime = System.currentTimeMillis();

			LOGGER.info("Before readFileInchunks");
			StringBuilder sb = readFileInChunks(reader);

			long endTime = System.currentTimeMillis();
			LOGGER.info("Time taken to read file in ms: {}", (endTime - startTime));
			String stringBuilder2 = sb.toString().trim();

			LOGGER.info("File read successfully");

			// Store the file in Storage of ni dmp project 
			ByteArrayInputStream inputStream = new ByteArrayInputStream(
					stringBuilder2.getBytes(Constants.DEFAULT_ENCODING));

			LOGGER.info("Get airflow storage");
			Storage storageObj = getStorageObj();
			BlobId blobId = null;
			if(projectName.contains("prod")) {
				LOGGER.info("Prod Bucket is:{}", airflowBucketProd);
				blobId = BlobId.of(airflowBucketProd, filename);
			} else {
				LOGGER.info("Dev Bucket is:{}", airflowBucket);
				blobId = BlobId.of(airflowBucket, filename);					
			}

			BlobInfo blobInfo = BlobInfo.newBuilder(blobId).setContentType("text/plain").build();
			LOGGER.info("Test: blobInfo: {}", blobInfo);	
			storageObj.create(blobInfo, inputStream);
			LOGGER.info("Test: File Uploaded to bucket:");
			
			// Update Expansion status once file is uploaded to Exp flow
			QueryResults<Entity> result= fetchByStartTimestamp(timestamp);
			if(result.hasNext())
			{
				Entity entity = result.next();
				Key entityKey = entity.getKey();
				entity = Entity.newBuilder(datastore.get(entityKey))
						.set(ConstantsUtil.EXPANSION_STATUS, ConstantsUtil.EXPANSION_PENDING)
						.set(ConstantsUtil.EXPANSION_FLOW, ConstantsUtil.BOOLEAN_TRUE)
						.build();
				datastore.put(entity);
			}

		} catch (Exception e) {
			LOGGER.error(
					"ExpansionAudienceServiceImpl.expandingSeedListFile():{} , Error Message : {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"ExpansionAudienceServiceImpl.expandingSeedListFile():{} , Error Message : {}", e);
		}
		return true;
	}
	
	/** 
	 * Read files data & append it in StringBuilder obj
	 * @param reader
	 * @return
	 * @throws IOException
	 */
	private StringBuilder readFileInChunks(ReadChannel reader) throws IOException {

		LOGGER.info("Reading File data");
		ByteBuffer byteBuffer = ByteBuffer.allocate(512 * 1024);

		StringBuilder sbObj = new StringBuilder(ConstantsUtil.BLANK_SPACE);
		while (reader.read(byteBuffer) > 0) {
			byteBuffer.flip();
			Charset charset = Charset.forName("US-ASCII");
			CharBuffer charBuffer = charset.decode(byteBuffer);

			sbObj.append(charBuffer);

			byteBuffer.clear(); 
		}
		return sbObj;
	}

	/**
	 * @return
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	private Storage getStorageObj() throws IOException {
		LOGGER.info("getStorageObj called");
		StorageOptions options = StorageOptions.newBuilder()
				.setProjectId(projectName)
				.setCredentials(GoogleCredentials.fromStream(
						new FileInputStream(pathToJsonKey))).build();
		LOGGER.info("StorageOptions: {}", options.getProjectId());
		return options.getService();
	}
	
	/**Fetch Record by startTimestamp
	 * @param timestamp
	 * @return
	 */
	private QueryResults<Entity> fetchByStartTimestamp(long timestamp) {
		// Build the Query
		Query<Entity> query = Query.newEntityQueryBuilder()
				.setKind(ConstantsUtil.TASK)                                 
				.setFilter(PropertyFilter.eq(ConstantsUtil.START_TIMESTAMP, timestamp))
				.build();
		return datastore.run(query);
	}
}
