/**
 * 
 */
package com.networkedinsights.dto;

/**
 * @author rajvirs
 *
 */
public class TraitIdDto {
	private Long sid;

	public Long getSid() {
		return sid;
	}

	public void setSid(Long sid) {
		this.sid = sid;
	}
}
