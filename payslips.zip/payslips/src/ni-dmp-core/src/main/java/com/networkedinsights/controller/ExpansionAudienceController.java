/**
 * 
 */
package com.networkedinsights.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.networkedinsights.dto.DistributionsDto;
import com.networkedinsights.dto.ExpandedAudienceDto;
import com.networkedinsights.service.IExpansionAudienceService;

/**
 * @author rajvirs
 *
 */
@RestController
@RequestMapping("/core/v1")
public class ExpansionAudienceController extends AbstractBaseController {
	
	@Autowired
	private IExpansionAudienceService expansionAudienceService;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ExpansionAudienceController.class);
	
	/**
	 * This method will help in storing
	 * file details and selected quantile value.
	 * @param fileName
	 * @param qtl
	 * @param records
	 */
	@PostMapping(value = "/select_qtl")
	public void storeQtlInfoInDatastore(@RequestBody
			ExpandedAudienceDto expandedAudienceDto) {
		
		LOGGER.info("Storing selected quantile data");
		expansionAudienceService.storeQntlInfoInDatastore(
				expandedAudienceDto);	
	}
	
	/**
	 * To fetch Audience Expansion Listing to be 
	 * displayed on file details page
	 * @param traitId
	 * @return
	 */
	@GetMapping(value = "/expanded_audience_listing/{traitId}")
	public ResponseEntity<List<ExpandedAudienceDto>> fetchExpandedAudienceListing(
			@PathVariable Integer traitId) {
		
		LOGGER.info("Fetching expanded audience listing");
		return ResponseEntity.ok(expansionAudienceService.fetchExpandedAudienceListing(
				traitId));
		
	}

	/**
	 * This method will help in reading
	 * expanded audience data from Bigquery table 
	 * processing the data and uploading final file to S3
	 * @return
	 */
	@GetMapping(value = "/distribute/{destination}/type/{distributionType}/file/{filename}/{timestamp}/{qtl}")
	public ResponseEntity<Long> distributeExpandedAudienceIds(
			@PathVariable String destination,
			@PathVariable String distributionType,
			@PathVariable String filename,
			@PathVariable Long timestamp,
			@PathVariable Integer qtl) {

		LOGGER.info("Big Query join Data");
		return ResponseEntity.ok(expansionAudienceService.distributeExpandedAudienceIds(destination
				, distributionType, filename, timestamp, qtl));	

	}
	
	/**
	 * This method will help in 
	 * Distributing and CreateTable
	 * @return
	 */
	@GetMapping(value = "/distribute_createtable/{filename}/{qtl}/{distTimestamp}/{timeoutTmpstp}/{distributionType}")
	public ResponseEntity<Long> distributeAndCreateTable(
			@PathVariable String filename,
			@PathVariable Integer qtl,
			@PathVariable Long distTimestamp,
			@PathVariable Long timeoutTmpstp,
			@PathVariable String distributionType) {

		LOGGER.info("Distribute and Create Table");
		return ResponseEntity.ok(expansionAudienceService.distributeAndCreateTable(filename, 
				qtl, distTimestamp, timeoutTmpstp, distributionType));	

	}
	
	
	
	/**
	 * This method will help in fetching
	 * Expanded Audience distributions
	 * @param fileName
	 * @return
	 */
	@GetMapping(value = "/exp_aud_distributions/{timestamp}")
	public ResponseEntity<List<DistributionsDto>> getExpAudDistributions(
			@PathVariable Long timestamp) {

		if (null != timestamp) {
			LOGGER.info("Expanded Audience distribution history");
			return ResponseEntity.ok(expansionAudienceService
					.getDistributionsHistory(timestamp));
		}
		return null;
	}
	
	/**
	 * Expanding seed list file
	 * @param filename
	 * @param timestamp
	 * @return
	 */
	@GetMapping(value = "/expansion/{filename}/{timestamp}")
	public ResponseEntity<Boolean> expandingSeedListFile(
			@PathVariable String filename, @PathVariable Long timestamp) {
		
		LOGGER.info("Expanding seed list file");
		// Call service method
		// Storing file details in Datastore, Performing validation on file
		// Then Uploading file on cloud9-airflow project
		return ResponseEntity.ok(expansionAudienceService.
				expandingSeedListFile(filename, timestamp));
	}
	
}
