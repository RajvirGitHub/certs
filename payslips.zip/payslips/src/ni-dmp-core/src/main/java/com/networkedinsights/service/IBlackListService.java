package com.networkedinsights.service;

import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

public interface IBlackListService {

	/**
	 * Fetch count of black listed records
	 * @return
	 */
	public Long fetchAllBlackList();

	/**
	 * Upload Blacklist file and insert records in table
	 * @param file
	 * @param username
	 * @return 
	 */
	public Integer uploadBlackListFile(MultipartFile file, String username)throws IOException;

	/**
	 * Email verification on GBL
	 * @param email
	 * @return
	 */
	public boolean checkEmailInBlacklist(String email);


}
