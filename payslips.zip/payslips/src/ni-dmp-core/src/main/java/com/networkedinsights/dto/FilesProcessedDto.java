/**
 * 
 */
package com.networkedinsights.dto;

/**
 * @author rajvirs
 *
 */
public class FilesProcessedDto {

	private String dataFileName;

	public String getDataFileName() {
		return dataFileName;
	}

	public void setDataFileName(String dataFileName) {
		this.dataFileName = dataFileName;
	}
	
}
