/**
 * 
 */
package com.networkedinsights.exception;

/**
 * @author rajvirs
 * created on - 06/03/2018
 * modified on - 06/03/2018
 *
 */
public class InvalidTraitNameException extends RuntimeException{


	private static final long serialVersionUID = 3754635144382340968L;

	public InvalidTraitNameException(String string) {
		super(string);
	}
}
