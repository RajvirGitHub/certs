/**
 * 
 */
package com.networkedinsights.service.impl;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.LongStream;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.google.cloud.datastore.Batch;
import com.google.cloud.datastore.Datastore;
import com.google.cloud.datastore.Entity;
import com.google.cloud.datastore.Key;
import com.google.cloud.datastore.KeyFactory;
import com.google.cloud.datastore.Query;
import com.google.cloud.datastore.QueryResults;
import com.google.cloud.datastore.StructuredQuery;
import com.google.cloud.datastore.StructuredQuery.PropertyFilter;
import com.google.gson.Gson;
import com.networkedinsights.dto.AAMTokenDto;
import com.networkedinsights.dto.AAMTokenMappingDto;
import com.networkedinsights.dto.AamAwsSecretsDto;
import com.networkedinsights.dto.FilesProcessedDto;
import com.networkedinsights.dto.JobStatsDto;
import com.networkedinsights.dto.TraitDto;
import com.networkedinsights.dto.TraitIdDto;
import com.networkedinsights.dto.TraitListDto;
import com.networkedinsights.exception.InvalidTraitNameException;
import com.networkedinsights.exception.NIDmpException;
import com.networkedinsights.exception.TraitIdNotFoundException;
import com.networkedinsights.service.IAAMService;
import com.networkedinsights.util.ConstantsUtil;
import com.networkedinsights.util.DateUtility;

/**
 * @author rajvirs
 * created on - 22/02/2019
 * modified on - 13/03/2019
 */
@Service
public class AAMServiceImpl implements IAAMService{

	private static final Logger LOGGER = LoggerFactory.getLogger(AAMServiceImpl.class);

	private KeyFactory userKeyFactory;

	@PostConstruct
	public void initializeKeyFactories() {
		LOGGER.info("Initializing key factories");
		userKeyFactory = datastore.newKeyFactory().setKind(ConstantsUtil.TRAITLIST);
	}

	@Value("${aam.endpoint}")
	private String aamEndpoint;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private AAMTokenDto aamTokenDto;

	@Autowired
	private AamAwsSecretsDto secretDto;

	@Autowired
	private Datastore datastore;

	@Value("${aam.folderId}")
	private String folderId;
	
	@Value("${aam.traitType}")
	private String traitType;
	
	@Value("${aam.datasourceId}")
	private String datasourceId;

	private static final String INTEGRATION_CODE = "N/A";

	@Override
	public String createTraitId(List<String> traitInfoList) {

		try{
			//Set token if inactive or not present
			LOGGER.info("Create Trait called");
			validateOrSetToken();

			Integer ttl = ConstantsUtil.DEFAULT_TTL_VALUE;
			if(traitInfoList.get(2).trim().matches("\\d+") &&
					Integer.parseInt(traitInfoList.get(2).trim()) <= ConstantsUtil.MAX_TTL_LIMIT) {

				ttl = Integer.parseInt(traitInfoList.get(2).trim());
				LOGGER.info("TTL set as per file name.");
			}

			HttpHeaders headers = setHttpHeaderForRestCall();

			Map<String, String> map = new HashMap<>();
			map.put(ConstantsUtil.FOLDER_ID_AAM, folderId);
			map.put(ConstantsUtil.TRAIT_NAME_AAM, traitInfoList.get(0));
			map.put(ConstantsUtil.TRAIT_TYPE_AAM, traitType);
			map.put(ConstantsUtil.DATASOURCE_ID_AAM, datasourceId);
			map.put(ConstantsUtil.INTEGRATION_CODE_AAM, INTEGRATION_CODE);
			map.put(ConstantsUtil.TTL_AAM, ttl.toString());
			map.put(ConstantsUtil.DESCRIPTION_AAM, traitInfoList.get(1));

			HttpEntity<?> request = new HttpEntity<>(map, headers);
			URI url = new URI(aamEndpoint + ConstantsUtil.VERSION_V1 
					+ ConstantsUtil.TRAIT_ENDPOINT);
			ResponseEntity<String> response = restTemplate.postForEntity( url, request , String.class );

			Gson gson = new Gson(); 
			TraitDto traitDto = gson.fromJson(response.getBody(), TraitDto.class);
			//Strinng str  gson toJson traitModel

			return traitDto.getSid()+"";

		} catch(InvalidTraitNameException e) {
			throw e;
		} catch(Exception e){
			LOGGER.error(
					"AAMServiceImpl.createTraitId(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"AAMServiceImpl.createTraitId(): {} , Error MEssage: {}", e);
		}
	}

	@Override
	public List<TraitListDto> fetchTraitList(String folderId, String dataSourceId) {
		List<TraitListDto> traitDtoList = new ArrayList<>();
		try{
			//FETCH FROM Datastore
			LOGGER.info("fetchTraitList called:{}", Instant.now());
			traitDtoList = fetchFromDatastore();

			if(CollectionUtils.isEmpty(traitDtoList)) {
				// Datastore is blank
				// Call Adobe API to get trait list
				traitDtoList = fetchTraitsFromAdobe();

				// Store trait list in Datastore
				LOGGER.info("Before inserting records in Datastore:{}", Instant.now());
				upsertTraitInDatastore(traitDtoList);
				LOGGER.info("After inserting records in Datastore:{}", Instant.now());
			}
			LOGGER.info("fetchTraitList returned:{}", Instant.now());
			return traitDtoList;
		} catch(Exception e){

			LOGGER.error(
					"AAMServiceImpl.fetchTraitList(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"AAMServiceImpl.fetchTraitList(): {} , Error MEssage: {}", e);
		}
	}

	@Override
	public String createTrait(TraitDto traitDto) {
		List<String> infoList = new ArrayList<>();
		try {

			String traitId = null;
			if(null != traitDto){
				validateTraitName(traitDto.getName());
				infoList.add(traitDto.getName());
				infoList.add(traitDto.getDescription());
				if(null != traitDto.getTtl()) {
					infoList.add(traitDto.getTtl().toString());
				} else {
					// Setting it to default value since TTL was blank or null.
					infoList.add(ConstantsUtil.DEFAULT_TTL_VALUE.toString());	
				}
				traitId = createTraitId(infoList);

				// Update Datastore with new traitId and Username
		    	
				addTraitIdUserInDatastore(traitDto, traitId);

			}
			return traitId;

		} catch(InvalidTraitNameException e1) {
			throw e1;
		} catch (Exception e) {
			LOGGER.error(
					"AAMServiceImpl.createTrait(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"AAMServiceImpl.createTrait(): {} , Error MEssage: {}", e);
		}
	}

	@Override
	public TraitDto fetchTraitById(Integer traitId) {
		try {
			//Set token if inactive or not present
			validateOrSetToken();
			// Logic to call Fetch TraitList API of AAM
			HttpHeaders headers = setHttpHeaderForRestCall();

			HttpEntity<String> entity = new HttpEntity<>(ConstantsUtil.PARAMETERS, headers);

			UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(aamEndpoint
					+ ConstantsUtil.VERSION_V1 + ConstantsUtil.TRAIT_ENDPOINT + traitId);
			ResponseEntity<String> responseEntity = restTemplate.exchange(
					uriBuilder.toUriString(),
					HttpMethod.GET,
					entity,
					String.class
					);

			Gson gson = new Gson(); 
			return gson.fromJson(responseEntity.getBody(), TraitDto.class);
		} catch (HttpClientErrorException e1) {
			throw new TraitIdNotFoundException(ConstantsUtil.TRAITID_NOTFOUND);
		} catch (Exception e) {
			LOGGER.error(
					"AAMServiceImpl.fetchTraitById(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"AAMServiceImpl.fetchTraitById(): {} , Error MEssage: {}", e);
		}

	}

	/**
	 * Reloads Traits from Adobe and update Datastore. 
	 * It will show deleted records from Adobe since Datastore
	 * is only updated. 
	 */
	@Override
	public List<TraitListDto> reloadTraitList() {
		List<TraitListDto> list = new ArrayList<>();
		// Call Adobe API to get trait list
		try {
			list = fetchTraitsFromAdobe();

			// Store trait list in Datastore
			LOGGER.info("Before inserting records in Datastore:{}", Instant.now());
			upsertTraitInDatastore(list);
			LOGGER.info("After inserting records in Datastore:{}", Instant.now());
			//FETCH FROM Datastore
			return fetchFromDatastore();
		} catch (Exception e) {
			LOGGER.error(
					"AAMServiceImpl.reloadTraitList(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"AAMServiceImpl.reloadTraitList(): {} , Error MEssage: {}", e);
		}
		
	}

	@Override
	public void reloadTraitListFromJob() {
		List<TraitListDto> list = new ArrayList<>();
		try {
			LOGGER.info("Job: Reloading TraitList from Job: {}", Instant.now());
			// Fetch and Delete from datastore
		    Batch batch = datastore.newBatch();
		    StructuredQuery<Key> query = Query.newKeyQueryBuilder()
		        .setKind(ConstantsUtil.TRAITLIST).build();
		    for (QueryResults<Key> keys = datastore.run(query); keys.hasNext(); ) {
		    	batch.delete(keys.next());
		    }
		    batch.submit();
			// Fetch latest records from Adobe
		    list = fetchTraitsFromAdobe();

			// Upload in Datastore
		    LOGGER.info("Job: Before inserting records in Datastore:{}", Instant.now());
			upsertTraitInDatastore(list);
			LOGGER.info("Job: After inserting records in Datastore:{}", Instant.now());
			
		} catch (Exception e) {
			LOGGER.error(
					"AAMServiceImpl.reloadTraitListFromJob(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"AAMServiceImpl.reloadTraitListFromJob(): {} , Error MEssage: {}", e);
		}
		
	}

	@Override
	public List<String> fetchFileNameList() {
		try {
			//Set token if inactive or not present
			validateOrSetToken();
			// Logic to call Fetch TraitList API of AAM
			HttpHeaders headers = setHttpHeaderForRestCall();

			HttpEntity<String> entity = new HttpEntity<>(ConstantsUtil.PARAMETERS, headers);

			UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(aamEndpoint
					+ ConstantsUtil.VERSION_V1 + "/datasources/"
					+ datasourceId + "/history/inbound" );
			ResponseEntity<String> responseEntity = restTemplate.exchange(
					uriBuilder.toUriString(),
					HttpMethod.GET,
					entity,
					String.class
					);

			Gson gson = new Gson();
			List<String> fileNameList = new ArrayList<>();
			FilesProcessedDto[] array = gson.fromJson(responseEntity.getBody(), FilesProcessedDto[].class);
			List<FilesProcessedDto> list = Arrays.asList(array);
			if (!CollectionUtils.isEmpty(list)) {
				list.forEach(obj -> 
					fileNameList.add(obj.getDataFileName())
				);
			}
			return fileNameList;
		} catch (HttpClientErrorException e1) {
			throw new TraitIdNotFoundException(ConstantsUtil.TRAITID_NOTFOUND);
		} catch (Exception e) {
			LOGGER.error(
					"AAMServiceImpl.fetchFileNameList(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"AAMServiceImpl.fetchFileNameList(): {} , Error MEssage: {}", e);
		}
	}

	@Override
	public void reloadTraitsFromStorageFlow() {
		List<TraitListDto> list = new ArrayList<>();
		try {
			// Call Adobe API to get updated trait list
			list = fetchTraitsFromAdobe();
			// Store updated trait list in Datastore
			upsertTraitInDatastore(list);

		} catch (Exception e) {
			LOGGER.error(
					"AAMServiceImpl.reloadTraitsFromStorageFlow(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"AAMServiceImpl.reloadTraitsFromStorageFlow(): {} , Error MEssage: {}", e);
		}
	}
	
	/** This method validates if token is present and live 
	 *  if token is not present or expired it creates a new token
	 *  and sets it in singleton object
	 * @throws URISyntaxException 
	 * @throws Exception
	 */
	private void validateOrSetToken() throws URISyntaxException {
		if(null != aamTokenDto.getToken() &&
				aamTokenDto.getToken().length() > 0
				&& null != aamTokenDto.getLocalDateTime()) {
			// Token present, Check whether it is alive
			LocalDateTime time = aamTokenDto.getLocalDateTime();
			time = time.plusSeconds(ConstantsUtil.ADD_SECONDS);
			if(LocalDateTime.now().isAfter(time)) {
				// Token Expired: Call Oauth service
				LOGGER.info("Token Expired: Oauth service called");
				aamAuthentication();
			}

		} else {
			//No Token present: CALL TOKEN CREATION API
			LOGGER.info("No Token present: TOKEN CREATION API called");
			aamAuthentication();
		}
	}

	/**
	 * This method helps in making a connection with Adobe
	 * Audience Manager. It sets access token in Singleton class
	 * so that it can be used for subsequent calls.
	 * @throws URISyntaxException
	 */
	private void aamAuthentication() throws URISyntaxException {

		HttpHeaders headers = new HttpHeaders();

		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

		headers.set(ConstantsUtil.AUTHORIZATION_AAM,
				ConstantsUtil.BASIC_AAM + encodeAuthHeader());

		MultiValueMap<String, String> map= new LinkedMultiValueMap<>();
		map.add(ConstantsUtil.GRANT_TYPE_AAM, "password");
		map.add(ConstantsUtil.USERNAME_AAM, secretDto.getAamUsername());
		map.add(ConstantsUtil.PAWRD_AAM, secretDto.getAamPassword());

		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(map, headers);

		URI url = new URI(aamEndpoint + "/oauth/token");
		ResponseEntity<String> response = restTemplate.postForEntity( url, request , String.class );

		Gson gson = new Gson(); 

		AAMTokenMappingDto traitModel = gson.fromJson(response.getBody(), AAMTokenMappingDto.class);
		aamTokenDto.setToken(traitModel.getAccessToken());
		aamTokenDto.setLocalDateTime(LocalDateTime.now());

	}

	/** Base64 Encoding clientId & secret key
	 * 
	 * @return
	 */
	private String encodeAuthHeader() { //throws Unsupported Encoding exception
		String temp = secretDto.getAamAuthClientId()
				.concat(":").concat(secretDto.getAamAuthSecretkey());
		// Encode and return

		return Base64.getEncoder().encodeToString(temp.getBytes(StandardCharsets.UTF_8));
	}

	/**
	 * This method validates the Trait Name for special character 
	 * and length validations.
	 * @param name
	 * @throws UnsupportedEncodingException
	 */
	private void validateTraitName(String name) throws UnsupportedEncodingException {

		byte[] byteArr = name.getBytes("US-ASCII");	// Convert String to byte array
		// primitive byte array to List using LongStream Java 8
		List<Long> list = LongStream.range(0, byteArr.length).map(i 
				-> byteArr[(int) i]).boxed().collect(Collectors.toList());
		if( name.trim().length() > 255 || name.trim().length() < 1) {
			LOGGER.error("***** Trait Name should be of 0 to 255 characters *****");
			throw new InvalidTraitNameException(ConstantsUtil.INCORRECT_TRAIT_NAME);
		} else if(name.contains("-") || name.contains("|") 
				|| name.contains("\t") || list.contains(63l)){
			// This checks for Special characters namely: hyphen, pipe, tab and dash 
			LOGGER.error("***** Trait Name with special character *****");
			throw new InvalidTraitNameException(
					ConstantsUtil.INCORRECT_TRAIT_NAME);
		}
	}

	/** Sets HttpHeaders for Rest API call
	 * @return
	 */
	private HttpHeaders setHttpHeaderForRestCall() {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		httpHeaders.set(ConstantsUtil.AUTHORIZATION_AAM, 
				ConstantsUtil.BEARER_AAM + aamTokenDto.getToken());
		return httpHeaders;
	}

	/**Fetch Trait List from Datastore
	 * @param traitDtoList
	 */
	private List<TraitListDto> fetchFromDatastore() {
		
		Map<String, String> updatedByList = getUpdatedByMapList();
		List<TraitListDto> traitDtoList = new ArrayList<>();
		StructuredQuery<Entity> query = Query.newEntityQueryBuilder()
				.setKind(ConstantsUtil.TRAITLIST)
				//.setFilter(PropertyFilter.eq(ConstantsUtil.TRAIT_ID, traitId.toString()))
				.build();
		QueryResults<Entity> results = datastore.run(query);
		
		while (results.hasNext()) {
			Entity result = results.next();
			// Processing on result
			TraitListDto traitListDto = new TraitListDto();
			populateTraitListDtoObj(traitListDto, result);

			// Update username field
			if(null != updatedByList.get(traitListDto.getSid().toString()))
				traitListDto.setUpdatedBy(updatedByList.get(traitListDto.getSid().toString()));
			traitDtoList.add(traitListDto);
		}
		
		// Sorting Datastore list by Updated Time
		traitDtoList.sort((TraitListDto t1, 
				TraitListDto t2)->t2.getUpdateTime().compareTo(t1.getUpdateTime()));
		
		return traitDtoList;
	}

	/**
	 * Fetches Traits from Adobe
	 * @return
	 * @throws URISyntaxException
	 */
	private List<TraitListDto> fetchTraitsFromAdobe() throws URISyntaxException {
		List<TraitListDto> traitDtoList;
		Map<String, String> updatedByMap = getUpdatedByMapList();
		//Set token if inactive or not present
		validateOrSetToken();
		// Logic to call Fetch TraitList API of AAM
		HttpHeaders headers = setHttpHeaderForRestCall();

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(aamEndpoint 
				+ ConstantsUtil.VERSION_V1 + ConstantsUtil.TRAIT_ENDPOINT)
				.queryParam("folderId", folderId)
				.queryParam("dataSourceId", datasourceId);

		HttpEntity<String> entity = new HttpEntity<>("parameter", headers);

		ResponseEntity<String> response = restTemplate.exchange(builder.toUriString(), 
				HttpMethod.GET, entity, String.class);

		Gson gson = new Gson(); 

		TraitIdDto[] traitDto = gson.fromJson(response.getBody(), TraitIdDto[].class);
		List<TraitIdDto> traitIdDtoList =  Arrays.asList(traitDto);

		StringBuilder traitList = new StringBuilder();
		if(!CollectionUtils.isEmpty(traitIdDtoList)) {
			traitIdDtoList.forEach(obj -> 

			traitList.append(obj.getSid()).append(","));
		}

		// CALL REST API TO FETCH TRAIT LIST WITH TTL
		UriComponentsBuilder builder2 = UriComponentsBuilder.fromHttpUrl(aamEndpoint 
				+ ConstantsUtil.VERSION_V1 + ConstantsUtil.TRAIT_ENDPOINT
				+ traitList.substring(0, traitList.length()-1));
		HttpEntity<String> entity2 = new HttpEntity<>("parameter", setHttpHeaderForRestCall());

		ResponseEntity<String> response2 = restTemplate.exchange(builder2.toUriString(), 
				HttpMethod.GET, entity2, String.class);

		Gson gson2 = new Gson(); 
		if(response2.getBody().contains("[{")) {
			// Multiple traits in Adobe
			TraitListDto[] traitDto2 = gson2.fromJson(response2.getBody(), TraitListDto[].class);
			traitDtoList =  Arrays.asList(traitDto2);
		} else {
			// Single trait in Adobe
			TraitListDto traitDtoObj = gson2.fromJson(response2.getBody(), TraitListDto.class);
			traitDtoList = new ArrayList<>();
			traitDtoList.add(traitDtoObj);
		}

		if(!CollectionUtils.isEmpty(traitDtoList)) {
			traitDtoList.forEach(obj -> {

				obj.setCreatedDate(DateUtility.getFormattedDateString(
						obj.getCreateTime()));
				obj.setUpdatedDate(DateUtility.getFormattedDateString(
						obj.getUpdateTime()));
				// Update username field
				if(null != updatedByMap.get(obj.getSid().toString()))
					obj.setUpdatedBy(obj.getSid().toString());
				
			});
		}

		// Sorting Datastore list by Updated Time Desc order
		traitDtoList.sort((TraitListDto t1, 
				TraitListDto t2)->t2.getUpdateTime().compareTo(t1.getUpdateTime()));
		
		return traitDtoList;
	}

	/**
	 * Store all Traits in Datastore
	 * @param traitDtoList
	 * @return
	 */
	private Batch.Response upsertTraitInDatastore(List<TraitListDto> traitDtoList) {
		Batch batch = datastore.newBatch();
		for (TraitListDto obj : traitDtoList) {
			batch.put(createTraitEntity(obj));
		}

		return batch.submit();
	}

	/**
	 * Set Trait Entity to add in Batch
	 * @param obj
	 * @return
	 */
	private Entity createTraitEntity(TraitListDto obj) {
		Key key = userKeyFactory.newKey(obj.getSid());
		return Entity.newBuilder(key)
				.set(ConstantsUtil.TRAIT_ID, obj.getSid())
				.set(ConstantsUtil.TRAIT_NAME, obj.getName())
				.set(ConstantsUtil.TRAIT_DESC, obj.getDescription())
				.set(ConstantsUtil.TTL, obj.getTtl())
				.set(ConstantsUtil.CREATED_DATE, obj.getCreatedDate())
				.set(ConstantsUtil.LAST_REFRESHED, obj.getUpdatedDate())
				.set(ConstantsUtil.LAST_REFRESHED_TIME, obj.getUpdateTime())
				.build();
	}

	/** 
	 * To add TraitId and user in Datastore
	 * @param traitDto
	 * @param traitId
	 */
	private void addTraitIdUserInDatastore(TraitDto traitDto, String traitId) {
		
		String user = "";
		if(null != traitDto.getUserName()) {
			user = getTrimUsername(traitDto.getUserName(), user);
		}
		
		addInTraitUserMappingDatastore(traitId, user, user);
	}

	/**
	 * @param traitId
	 * @param keyFactory
	 * @param user
	 */
	private void addInTraitUserMappingDatastore(String traitId, 
			String createdBy, String updatedBy) {
		KeyFactory keyFactory = datastore.newKeyFactory()
				.setKind(ConstantsUtil.TRAITUSERMAP);
		LOGGER.info("Key factory Trait User map");
		
		Key key = datastore.allocateId(keyFactory.newKey());
		Entity task = Entity.newBuilder(key)
				.set(ConstantsUtil.TRAIT_ID, traitId) //setting the value of Sequence Code.
				.set(ConstantsUtil.CREATED_BY, createdBy)
				.set(ConstantsUtil.UPDATED_BY, updatedBy)
				.build();
		datastore.put(task);
		LOGGER.info("Trait User added in Datastore");
	}

	/**
	 * This method helps to pull the username
	 * from incoming username detail string.
	 * @param traitDto
	 * @param user
	 * @return
	 */
	private String getTrimUsername(String traitDtoUserName, String user) {
		String [] username = traitDtoUserName.split(":");
		if (null != username && username.length > 1) {
			user = username[1];
		}
		return user;
	}
	
	/**
	 * Fetch updatedBy list for storing as UserName
	 * @return
	 */
	private Map<String, String> getUpdatedByMapList()
	{
		Map<String, String> updatedByMap= new HashMap<>();
		// Build the Query
		Query<Entity> query = Query.newEntityQueryBuilder()
				.setKind(ConstantsUtil.TRAITUSERMAP)                              
				.build();
		QueryResults<Entity> result= datastore.run(query);
		while (result.hasNext()) 
		{
			Key entityKey = result.next().getKey();
			Entity retrieved = datastore.get(entityKey);
			
			updatedByMap.put(retrieved.getString(ConstantsUtil.TRAIT_ID),
					retrieved.getString(ConstantsUtil.UPDATED_BY));
		}
		return updatedByMap; 
	}

	@Override
	public Boolean deleteTraitById(Integer traitId,
			String username) {
		boolean flag = false;
		try {
			// Fetch trait by id
			// Delete trait from Datastore

			TraitListDto traitDto = fetchTraitByIdFromDatastore(traitId);
			LOGGER.info("Trait details fetched by id and deleted from Datastore");

			// Add this trait info in DeletedTrait
			addDeletedTraitInDatastore(traitDto, traitId
					, username);
			LOGGER.info("Trait details added in DeletedTrait in Datastore");
			// Delete trait from Adobe Audience Manager
			//Set token if inactive or not present
			validateOrSetToken();
			HttpHeaders headers = setHttpHeaderForRestCall();

			HttpEntity<String> entity = new HttpEntity<>(ConstantsUtil.PARAMETERS, headers);

			UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(aamEndpoint
					+ ConstantsUtil.VERSION_V1 + ConstantsUtil.TRAIT_ENDPOINT + traitId);
			restTemplate.exchange(
					uriBuilder.toUriString(),
					HttpMethod.DELETE,
					entity,
					String.class
					);
			LOGGER.info("Trait deleted from Adobe audience manager");


			flag = true;

		} catch (Exception e) {
			LOGGER.error(
					"AAMServiceImpl.deleteTraitById(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"AAMServiceImpl.deleteTraitById(): {} , Error MEssage: {}", e);
		}
		return flag; 
	}
	

	/** 
	 * To add TraitId and user in Datastore
	 * @param traitDto
	 * @param traitId
	 */
	private void addDeletedTraitInDatastore(TraitListDto traitDto, 
			Integer traitId, String currentUser) {
		KeyFactory keyFactory = datastore.newKeyFactory()
				.setKind(ConstantsUtil.DELETEDTRAIT);
		LOGGER.info("Storing Deleted trait");
		String user = "";
		if(null != currentUser) {
			user = getTrimUsername(currentUser, user);
		}

		Key key = datastore.allocateId(keyFactory.newKey());
		Entity task = Entity.newBuilder(key)
				.set(ConstantsUtil.TRAIT_ID, traitId) //setting the value of Sequence Code.
				.set(ConstantsUtil.TRAIT_NAME, traitDto.getName())
				.set(ConstantsUtil.TRAIT_DESC, traitDto.getDescription())
				.set(ConstantsUtil.TTL, traitDto.getTtl())
				.set(ConstantsUtil.CREATED_BY, getCreatedByForTraitId(traitId))
				.set(ConstantsUtil.UPDATED_BY, user)
				.set(ConstantsUtil.CREATED_DATE, traitDto.getCreatedDate())
				.set(ConstantsUtil.LAST_REFRESHED_TIME, Instant.now()+"")
				.build();
		datastore.put(task);
		LOGGER.info("Trait User added in Datastore");
	}
	
	/**Fetch Trait List from Datastore
	 * @param traitDtoList
	 */
	private TraitListDto fetchTraitByIdFromDatastore(Integer traitId) {

		QueryResults<Entity> results = getTraitListDetailsById(traitId);
		TraitListDto traitListDto = new TraitListDto();
		Key key = null;
		while (results.hasNext()) {
			Entity result = results.next();
			// Processing on result
			key = result.getKey();
			populateTraitListDtoObj(traitListDto, result);

		}
		if (null != key) {
			datastore.delete(key);	// Delete from Datastore
		}
		return traitListDto;
	}

	/**
	 * Populate trait list dto
	 * @param traitListDto
	 * @param result
	 */
	private void populateTraitListDtoObj(TraitListDto traitListDto, Entity result) {
		traitListDto.setSid(result.getLong(ConstantsUtil.TRAIT_ID));
		traitListDto.setName(result.getString(ConstantsUtil.TRAIT_NAME));
		traitListDto.setDescription(result.getString(ConstantsUtil.TRAIT_DESC));
		Integer ttl = (int)result.getLong(ConstantsUtil.TTL);
		traitListDto.setTtl(ttl);
		traitListDto.setUpdatedDate(result.getString(ConstantsUtil.LAST_REFRESHED));
		traitListDto.setCreatedDate(result.getString(ConstantsUtil.CREATED_DATE));
		traitListDto.setUpdateTime(result.getLong(ConstantsUtil.LAST_REFRESHED_TIME));	// Added for sorting
	}
	
	/**
	 * Fetch updatedBy list for storing as UserName
	 * @param traitId
	 * @return
	 */
	private String getCreatedByForTraitId(Integer traitId)
	{
		String createdByMap= "";
		// Build the Query
		QueryResults<Entity> result = getTraitDetailsById(traitId);
		while (result.hasNext()) 
		{
			Entity entity = result.next();

			createdByMap = entity.getString(ConstantsUtil.CREATED_BY);
		}
		return createdByMap; 
	}

	/**
	 * To get TraitDetails By Id
	 * @param traitId
	 * @return
	 */
	private QueryResults<Entity> getTraitDetailsById(Integer traitId) {
		Query<Entity> query = Query.newEntityQueryBuilder()
				.setKind(ConstantsUtil.TRAITUSERMAP)  
				.setFilter(PropertyFilter.eq(ConstantsUtil.TRAIT_ID, traitId.toString()))
				.build();
		return datastore.run(query);
	}

	@Override
	public Boolean updateTrait(TraitDto traitDto,
			Integer traitId) {
		boolean flag = false;
		try {

			if(null != traitId && null != traitDto){
				validateTraitName(traitDto.getName());

				LOGGER.info("Create Trait called");
				validateOrSetToken();

				HttpHeaders headers = setHttpHeaderForRestCall();

				Map<String, String> map = new HashMap<>();
				map.put(ConstantsUtil.FOLDER_ID_AAM, folderId);
				map.put(ConstantsUtil.TRAIT_NAME_AAM, traitDto.getName());
				map.put(ConstantsUtil.TRAIT_TYPE_AAM, traitType);
				map.put(ConstantsUtil.DATASOURCE_ID_AAM, datasourceId);
				map.put(ConstantsUtil.TTL_AAM, traitDto.getTtl().toString());
				map.put(ConstantsUtil.DESCRIPTION_AAM, traitDto.getDescription());

				HttpEntity<?> request = new HttpEntity<>(map, headers);
				URI url = new URI(aamEndpoint + ConstantsUtil.VERSION_V1 
						+ ConstantsUtil.TRAIT_ENDPOINT + traitId);
				restTemplate.put(url, request);

				LOGGER.info("Trait updated from Adobe audience manager");

				// Update Datastore with new trait details
				updateTraitDetailsInDatastore(traitDto, traitId);
				
				// Update Datastore with UpdatedBy user.
				updateUpdatedByInDatastore(traitDto.getUserName()
						, traitId);
				// Ask Jyoti to pass UpdatedBy field for this. TraitUserMapping
				
				flag = true;
			}
			return flag;

		} catch(InvalidTraitNameException e1) {
			throw e1;
		} catch (Exception e) {
			LOGGER.error(
					"AAMServiceImpl.updateTrait(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"AAMServiceImpl.updateTrait(): {} , Error MEssage: {}", e);
		}
	}
	
	/**
	 * Fetch updatedBy list for storing as UserName
	 * @param traitDto
	 * @param traitId
	 * @return
	 */
	private void updateTraitDetailsInDatastore(TraitDto traitDto
			, Integer traitId) {
		
		QueryResults<Entity> result = getTraitListDetailsById(traitId);
		
		if(result.hasNext())
		{
			Long time = Instant.now().toEpochMilli();
			String date = DateUtility.getFormattedDateString(time);
			Entity entity = result.next();
			Key entityKey = entity.getKey();
			entity = Entity.newBuilder(datastore.get(entityKey))
					.set(ConstantsUtil.TRAIT_NAME, traitDto.getName())
					.set(ConstantsUtil.TRAIT_DESC, traitDto.getDescription())
					.set(ConstantsUtil.TTL, traitDto.getTtl())
					.set(ConstantsUtil.LAST_REFRESHED_TIME, time)
					.set(ConstantsUtil.LAST_REFRESHED, date)
					.build();
			datastore.put(entity);
		}
	}

	/**
	 * To fetch Trait List Details By Id
	 * @param traitId
	 * @return
	 */
	private QueryResults<Entity> getTraitListDetailsById(Integer traitId) {
		StructuredQuery<Entity> query = Query.newEntityQueryBuilder()
				.setKind(ConstantsUtil.TRAITLIST)  
				.setFilter(PropertyFilter.eq(ConstantsUtil.TRAIT_ID, traitId))
				.build();
		return datastore.run(query);
	}
	
	/** 
	 * To update Trait User mapping datastore
	 * @param traitDto
	 * @param traitId
	 */
	private void updateUpdatedByInDatastore(String username, Integer traitId) {

		LOGGER.info("To update Trait User mapping datastore");
		QueryResults<Entity> result = getTraitDetailsById(traitId);
		String user = "";
		if(null != username) {
			user = getTrimUsername(username, user);
		}
		if(result.hasNext()) {
			LOGGER.info("Updating in Trait User mapping datastore");
			Entity entity = result.next();
			Key entityKey = entity.getKey();
			entity = Entity.newBuilder(datastore.get(entityKey))
					.set(ConstantsUtil.UPDATED_BY, user)
					.build();
			datastore.put(entity);
		} else {
			// Creating a new record in Datastore
			LOGGER.info("Adding in Trait User mapping datastore");
			addInTraitUserMappingDatastore(traitId.toString(), 
					ConstantsUtil.OFFLINE_CREATED, user);
		}

	}

	@Override
	public List<JobStatsDto> fetchJobStatsList(Long timestamp, 
			Boolean isDatastoreEmpty) {
		try {
			//Set token if inactive or not present
			validateOrSetToken();
			// Logic to call Fetch TraitList API of AAM
			HttpHeaders headers = setHttpHeaderForRestCall();

			HttpEntity<String> entity = new HttpEntity<>(ConstantsUtil.PARAMETERS, headers);
			long startTimestamp = timestamp - 8*60*60*1000;
			if (isDatastoreEmpty) {
				startTimestamp = timestamp - (long)90*24*60*60*1000;
			}
			LOGGER.info("JobStats StartTimestamp: {}", startTimestamp);
			LOGGER.info("JobStats EndTimestamp: {}", timestamp);
			LOGGER.info("JobStats current time Instant.now(): {}", Instant.now());
			LOGGER.info("JobStats Instant.now().toEpochMilli(): {}", Instant.now().toEpochMilli());
			LOGGER.info("JobStats LocalDateTime.now(): {}", LocalDateTime.now());
			ZoneOffset offset = ZoneOffset.of("+05:30");
			LOGGER.info("JobStats LocalDateTime.now().toEpochSecond: {}", LocalDateTime.now().toEpochSecond(offset));
			UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(aamEndpoint
					+ ConstantsUtil.VERSION_V1 + "/datasources/"
					+ datasourceId + "/history/inbound?startDate="+startTimestamp+"&endDate="+timestamp );
			ResponseEntity<String> responseEntity = restTemplate.exchange(
					uriBuilder.toUriString(),
					HttpMethod.GET,
					entity,
					String.class
					);
			Gson gson = new Gson();
			JobStatsDto[] array = gson.fromJson(responseEntity.getBody(), JobStatsDto[].class);
			List<JobStatsDto> list = Arrays.asList(array);
			LOGGER.info("JobStats List size: {}", list.size());
			return list;
		} catch (HttpClientErrorException e1) {
			throw new TraitIdNotFoundException(ConstantsUtil.TRAITID_NOTFOUND);
		} catch (Exception e) {
			LOGGER.error(
					"AAMServiceImpl.fetchJobStatsList(): {} , Error MEssage: {}",
					e.getClass().getName(), e.getMessage());
			throw new NIDmpException(
					"AAMServiceImpl.fetchJobStatsList(): {} , Error MEssage: {}", e);
		}
	}
}
