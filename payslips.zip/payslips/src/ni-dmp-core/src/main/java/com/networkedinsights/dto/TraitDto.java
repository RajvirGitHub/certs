/**
 * 
 */
package com.networkedinsights.dto;

/**
 * @author rajvirs
 * created on - 21/02/2019
 * modified on - 21/02/2019
 */
public class TraitDto {

	private Long createTime;
	private Long updateTime;
	private Long sid; // TRAITID
	private String traitType;
	private String name;
	private String description;
	private String [] permissions;
	private Integer pid;
	private Integer crUID;
	private Integer upUID;
	private Integer ttl;
	private String integrationCode;
	private Integer traitRuleVersion;
	private Integer type;
	private String backfillStatus;
	private Integer folderId;
	private Integer dataSourceId;
	private String userName;
	
	public Long getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Long createTime) {
		this.createTime = createTime;
	}
	public Long getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Long updateTime) {
		this.updateTime = updateTime;
	}
	public Long getSid() {
		return sid;
	}
	public void setSid(Long sid) {
		this.sid = sid;
	}
	public String getTraitType() {
		return traitType;
	}
	public void setTraitType(String traitType) {
		this.traitType = traitType;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String[] getPermissions() {
		return permissions;
	}
	public void setPermissions(String[] permissions) {
		this.permissions = permissions;
	}
	public Integer getPid() {
		return pid;
	}
	public void setPid(Integer pid) {
		this.pid = pid;
	}
	public Integer getCrUID() {
		return crUID;
	}
	public void setCrUID(Integer crUID) {
		this.crUID = crUID;
	}
	public Integer getUpUID() {
		return upUID;
	}
	public void setUpUID(Integer upUID) {
		this.upUID = upUID;
	}
	public Integer getTtl() {
		return ttl;
	}
	public void setTtl(Integer ttl) {
		this.ttl = ttl;
	}
	public String getIntegrationCode() {
		return integrationCode;
	}
	public void setIntegrationCode(String integrationCode) {
		this.integrationCode = integrationCode;
	}
	public Integer getTraitRuleVersion() {
		return traitRuleVersion;
	}
	public void setTraitRuleVersion(Integer traitRuleVersion) {
		this.traitRuleVersion = traitRuleVersion;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public String getBackfillStatus() {
		return backfillStatus;
	}
	public void setBackfillStatus(String backfillStatus) {
		this.backfillStatus = backfillStatus;
	}
	public Integer getFolderId() {
		return folderId;
	}
	public void setFolderId(Integer folderId) {
		this.folderId = folderId;
	}
	public Integer getDataSourceId() {
		return dataSourceId;
	}
	public void setDataSourceId(Integer dataSourceId) {
		this.dataSourceId = dataSourceId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}

}
