package com.networkedinsights.service;

import java.io.ByteArrayOutputStream;

import org.springframework.web.multipart.MultipartFile;

import com.networkedinsights.dto.FileDetailDto;
import com.networkedinsights.dto.FileTraitDto;
import com.networkedinsights.dto.PubSubAttributesDto;

/**
 * @author rajvirs
 * created on - 17/01/2019
 * modified on - 01/03/2019
 */
public interface IFileService {
	
	/**
	 * Uploads audience file to GCS.
	 * @param keyName
	 * @param file
	 */
	public void uploadFile(String keyName, MultipartFile file,
			Integer traitId);
	
	/**
	 * Validates the file from GCS
	 * @param fileDetailDto
	 * @return
	 */
	public Boolean validateFile(FileDetailDto
			fileDetailDto);
	/**
	 * Load social Id's in Big Query table.
	 * And set sequence code appropriately.
	 * @param fileDetailDto
	 * @return
	 */
	public Boolean loadSocialIdToFile(FileDetailDto
			fileDetailDto);
	/**
	 * Big Query join which will sync up social id and adobe uuid.
	 * And set sequence code appropriately.
	 * @param fileDetailDto
	 * @return
	 */
	public Boolean syncAdobeUUIdWithSocialId(FileDetailDto
			fileDetailDto);

	/**
	 * Upload outbound file to gcs.
	 * And set sequence code appropriately.
	 * @param fileDetailDto
	 * @return
	 */
	public Boolean uploadOutboundFileGCS(FileDetailDto fileDetailDto);
	
	/**
	 * Create Adobe audience file as per Adobe inbound file format (i.e tab separated and
	 * file name as per adobe guidelines) and SAVE the file to intermediate GCS bucket.
	 * And set sequence code appropriately. 
	 * @param fileDetailDto
	 * @return
	 */
	public void createIntermediateFileForGCS(FileDetailDto fileDetailDto);
	
	/**
	 * Upload inbound file as per Adobe inbound file format (i.e tab separated and
	 * file name as per adobe guidelines) in S3 bucket.
	 * And set sequence code appropriately. 
	 * @param fileDetailDto
	 * @return
	 */
	public void uploadInboundFileToS3(FileDetailDto fileDetailDto);

	/**
	 * Makes an entry in DataStore and calls PubSub
	 * @param fileTraitDto
	 * @return
	 */
	public Boolean makeEntryInDataStoreCallPubSub(FileTraitDto 
			fileTraitDto, String destination, String distributionType);

	public ByteArrayOutputStream inboundFileDownloadFromS3Bucket(String keyname);

	/**
	 * Download inbound file from GCS
	 * @param fileName
	 * @param isUI
	 * @return
	 */
	public byte [] downloadInboundFile(String fileName, Boolean isUI);

	/**
	 * Storing file details in Datastore
	 * Perform validation on file
	 * Upload file on cloud9-airflow project
	 * @param fileName
	 * @param file
	 * @param traitId
	 */
	public Boolean storeValidateUploadFile(String fileName, 
			MultipartFile file, Integer traitId, Boolean expansion);

	/**
	 * This method will store file data from
	 * Audience Expansion flow
	 * @param pubSubDataDto
	 */
	public void pushSubscriberPubSubData(PubSubAttributesDto pubSubDataDto,
			Long tmstp);

	/**
	 * This method will get google verification
	 * file and send it to Pub/Sub subscriber
	 * @param fileName
	 * @return
	 */
	public byte[] getHtmlFile(String fileName);

	/**
	 * This method will download uplift html file from DSA 
	 * and upload it to DMP project
	 * @param fileName
	 * @return
	 */
	public byte [] uploadUpliftHtmlFile(String fileName);

	/**
	 * This method checks for Pull Subscriber
	 * message and update it in Datastore
	 * @return
	 */
	public String pullSub();	

	/**
	 * This method will download uplift html file from DSA 
	 * @param fileName
	 * @return
	 */
	public byte [] downloadUpliftFile(String fileName);

	/**
	 * Upload inbound file as per Adobe inbound file format (i.e tab separated and
	 * file name as per adobe guidelines) in S3 bucket for expansion flow.
	 * And set sequence code appropriately. 
	 * @param timestamp
	 * @param destFileName
	 * @param distributionType
	 */
	public String uploadExpandedInboundFileToS3(Long timestamp, 
			String destFileName, String distributionType);

	/**
	 * This method checks for Pii matcher Pull Subscriber
	 * message and update it in Datastore
	 * @return
	 */
	public void pullSubForNiLeads();
}