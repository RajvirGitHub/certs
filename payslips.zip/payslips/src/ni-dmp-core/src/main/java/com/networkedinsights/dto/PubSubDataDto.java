/**
 * 
 */
package com.networkedinsights.dto;

/**
 * @author rajvirs
 *
 */
public class PubSubDataDto {

	private PubSubAttributesDto attributes;

	public PubSubAttributesDto getAttributes() {
		return attributes;
	}

	public void setAttributes(PubSubAttributesDto attributes) {
		this.attributes = attributes;
	}
	
}
