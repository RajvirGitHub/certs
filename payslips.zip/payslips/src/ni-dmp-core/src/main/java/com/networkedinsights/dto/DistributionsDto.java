/**
 * 
 */
package com.networkedinsights.dto;

/**
 * @author rajvirs
 * created on - 13/08/2019
 * modified on - 13/08/2019
 */
public class DistributionsDto {

	private String fileName;
	private String destination;
	private String status; 	// (distribution status)
	private String inboundRecords; 
	private String matchedRecords; 
	private String matchRate;		// (calculation)
	private String distributionDate;	// (created Date)
	private Integer distributions;	// Distribution Number
	private String distributionType;
	private String adobeInboundAudFile;
	private String jobIdName;	// added for CYBG 310 
	
	private Long dhTimeStamp;
	
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getInboundRecords() {
		return inboundRecords;
	}
	public void setInboundRecords(String inboundRecords) {
		this.inboundRecords = inboundRecords;
	}
	public String getMatchedRecords() {
		return matchedRecords;
	}
	public void setMatchedRecords(String matchedRecords) {
		this.matchedRecords = matchedRecords;
	}
	public String getMatchRate() {
		return matchRate;
	}
	public void setMatchRate(String matchRate) {
		this.matchRate = matchRate;
	}
	public String getDistributionDate() {
		return distributionDate;
	}
	public void setDistributionDate(String distributionDate) {
		this.distributionDate = distributionDate;
	}
	public Long getDhTimeStamp() {
		return dhTimeStamp;
	}
	public void setDhTimeStamp(Long dhTimeStamp) {
		this.dhTimeStamp = dhTimeStamp;
	}
	public Integer getDistributions() {
		return distributions;
	}
	public void setDistributions(Integer distributions) {
		this.distributions = distributions;
	}
	public String getDistributionType() {
		return distributionType;
	}
	public void setDistributionType(String distributionType) {
		this.distributionType = distributionType;
	}
	public String getAdobeInboundAudFile() {
		return adobeInboundAudFile;
	}
	public void setAdobeInboundAudFile(String adobeInboundAudFile) {
		this.adobeInboundAudFile = adobeInboundAudFile;
	}
	public String getJobIdName() {
		return jobIdName;
	}
	public void setJobIdName(String jobIdName) {
		this.jobIdName = jobIdName;
	}
	
}
