/**
 * 
 */
package com.networkedinsights.dto;

import java.time.LocalDateTime;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


/**
 * @author rajvirs
 * created on - 21/02/2019
 * modified on - 21/02/2019
 */
// Made this class as a singleton bean in order to 
// access the token for Adobe APIs
@Scope(value = "singleton")
@Component
public class AAMTokenDto {
	
	private String accessToken;
	private LocalDateTime localDateTime;

	public String getToken() {
		return accessToken;
	}
	public void setToken(String accessToken) {
		this.accessToken = accessToken;
	}
	public LocalDateTime getLocalDateTime() {
		return localDateTime;
	}
	public void setLocalDateTime(LocalDateTime localDateTime) {
		this.localDateTime = localDateTime;
	}
	
}
