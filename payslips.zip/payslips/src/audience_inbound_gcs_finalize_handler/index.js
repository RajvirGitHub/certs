'use strict';
const {Datastore} = require('@google-cloud/datastore');

// Creates a client
const datastore = new Datastore();
// [END datastore_build_service]

// [START datastore_add_entity]
function addTask(filePath,starttimestamp) {
  const taskKey = datastore.key('Task');
  const entity = {
    key: taskKey,
    data: [
      {
        name: 'GCSFilePath',
        value: filePath,
      },
      {
        name: 'StartTimeStamp',
        value: starttimestamp,
      },
	  {
        name: 'EndTimeStamp',
        value: '',
      },	  
      {
        name: 'Status',
        value: 'in progress',
      },
      {
        name: 'FeedbackMsg',
        value: '',
      },
	  {
        name: 'Username',
        value: '',
      },
	  {
        name: 'SequenceCode',
        value: 1,
      },
	  {
        name: 'TraitId',
        value: '',
      },
	  {
        name: 'TraitName',
        value: '',
      },
	  {
        name: 'TraitDesc',
        value: '',
      },
	  {
        name: 'TTL',
        value: '',
      },
	  {
        name: 'IntegrationCode',
        value: '',
      },
	  {
        name: 'InboundCnt',
        value: '',
      },
	  {
        name: 'InboundAudienceFileName',
        value: '',
      },
    ],
  };

  try {
    datastore.save(entity);
    console.log(`Task ${taskKey.id} created successfully.`);
  } catch (err) {
    console.error('ERROR:', err);
  }
}
exports.helloGCS = (event, callback) => {
  var starttimestamp = (new Date).getTime();
  const {PubSub} = require('@google-cloud/pubsub');
  const file = event.data;
  const bucket = file.bucket;
  const fileName = file.name;
  console.log(`  Bucket: ${file.bucket}`);
  console.log(`  File: ${file.name}`);
  const filePath = bucket + "/" + fileName;
  console.log("file path: "+filePath);

  //check whether file name conains .
  if(fileName.includes(".")) {
  addTask(filePath,starttimestamp);
  
  // Creates a client
  const pubsub = new PubSub();
  const topicName = 'ni-dmp-audience-topic';
  const data = JSON.stringify(
  { 
  filepath: filePath,
  starttimestamp: starttimestamp
  }
  );
  // Publishes the message as a string, e.g. "Hello, world!" or JSON.stringify(someObject)
  const dataBuffer = Buffer.from(data);
  const messageId = pubsub.topic(topicName).publish(dataBuffer);
  console.log("Message published");
  }
  else
  {
    console.log(`${filePath} not a file.`);
  }
    callback();
};
