package com.networkedinsights;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NiDmpFileTransferApplication {

	public static void main(String[] args) {
		SpringApplication.run(NiDmpFileTransferApplication.class, args);
	}

}
