/**
 * 
 */
package com.networkedinsights.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.networkedinsights.dto.FileTransferDto;
import com.networkedinsights.service.INiDmpFileTransferService;

/**
 * @author shivanid
 *
 */
@RestController
@RequestMapping("/core/v1")
public class NiDmpFileTransferController {
	
	@Autowired
	private INiDmpFileTransferService fileTransferService;
	
	@RequestMapping(value="/file-transfer", method={ RequestMethod.GET, RequestMethod.POST })
	public ResponseEntity<String> fileTransferGcsToS3(@RequestBody 
			FileTransferDto dto) {
		
		String processString = fileTransferService.fileTransferGcsToS3(dto);
		
		return ResponseEntity.ok(processString);
	}
	
}
