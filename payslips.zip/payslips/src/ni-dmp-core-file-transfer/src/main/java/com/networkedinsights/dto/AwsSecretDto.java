/**
 * 
 */
package com.networkedinsights.dto;

import org.springframework.stereotype.Component;

import com.google.gson.annotations.SerializedName;

/**
 * @author shivanid
 *
 */
@Component
public class AwsSecretDto {
	
	@SerializedName("aws_access_keyid")
	private String awsAccessKeyid;		
	@SerializedName("aws_secret_accesskey")
	private String awsSecretAccesskey;
	
	public String getAwsAccessKeyid() {
		return awsAccessKeyid;
	}
	public void setAwsAccessKeyid(String awsAccessKeyid) {
		this.awsAccessKeyid = awsAccessKeyid;
	}
	public String getAwsSecretAccesskey() {
		return awsSecretAccesskey;
	}
	public void setAwsSecretAccesskey(String awsSecretAccesskey) {
		this.awsSecretAccesskey = awsSecretAccesskey;
	}
	
	
}
