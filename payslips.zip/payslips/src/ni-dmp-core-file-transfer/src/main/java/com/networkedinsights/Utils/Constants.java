package com.networkedinsights.utils;
/**
 * @author shivanid
 *
 */
public final class Constants {
	//Hide the constructor
	private Constants(){} 
	// Path of command.sh file
	public static String SHFILEPATH="//opt//ni-dmp-service-file-transfer//command.sh";
	// Host name of Amazon S3 bucket
	public static String HOST="s3.us-east-1.amazonaws.com";
	// String constant defined for Failed result
	public static String RESULTFAILED="Failed";
	// String constant defined for Success result
	public static String RESULTSUCCESS="Success";
}
