package com.networkedinsights.service.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.networkedinsights.dto.AwsSecretDto;
import com.networkedinsights.dto.FileTransferDto;
import com.networkedinsights.service.INiDmpFileTransferService;
import com.networkedinsights.utils.Constants;

/**
 * @author shivanid
 *
 */
@Service
public class NiDmpFileTransferServiceImpl implements INiDmpFileTransferService{

	//Creating Logger object.
	public static final Logger LOGGER = LoggerFactory.getLogger(NiDmpFileTransferServiceImpl.class);
    @Value("${secrets.file.path}")
	private String secretsFilePath;
    /**
     * Function to Transfer file from GCS to S3.
     * @param fileTransferDto
     */
	@Override
	public String fileTransferGcsToS3(FileTransferDto fileTransferDto) {
		String result=Constants.RESULTFAILED;
		//Checking secret file availability.
		if(null != secretsFilePath) {
			File file = new File(secretsFilePath);
			try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
				LOGGER.info("Reading the File");
				StringBuilder json = new StringBuilder("");
				String line = null;
				while((line = reader.readLine()) != null){
					json.append(line);
				}
				AwsSecretDto dto = new Gson().fromJson(json.toString(), AwsSecretDto.class);
				LOGGER.info("SecretDto object populated ");
				//Getting S3 credentials.
				String aws_access_key_id =dto.getAwsAccessKeyid();
				String aws_secret_access_key =dto.getAwsSecretAccesskey();
				String host= Constants.HOST;								
				
				File shfile = new File(Constants.SHFILEPATH);				
				//Create the file
				if (shfile.createNewFile())
				{				  
				    LOGGER.info("Shell File is created!");
				} else {
				    LOGGER.info("Shell file already exists.");
				    LOGGER.info("Deleting File");
				    shfile.delete();
				    if(shfile.exists()){
				    LOGGER.info("File not deleted");
				    return result;
				    }
				    else{
				    LOGGER.info("File deleted");
				    }
				}
				//checking for null value for srcFilePath and destFilePath.
				if(null != fileTransferDto.getSrcFilePath() && null!= fileTransferDto.getDestFilePath()){
					// command.sh having gsutil command accepting srcFilePath and destFilePath to transfer file from GCS to S3.
					String shfileContent = "#!/bin/bash\n"
							+ "cd ~\n"
							+ "touch logs\n"
							+ "touch .boto\n"
							+ "echo [Credentials] >> ~/.boto\n"
							+ "echo aws_access_key_id = "+aws_access_key_id+" >> ~/.boto\n"
							+ "echo aws_secret_access_key = "+aws_secret_access_key+" >> ~/.boto\n"
							+ "echo [s3] >> ~/.boto\n"
							+ "echo host = "+host+" >> ~/.boto\n"
							+ "echo use-sigv4 = True >> ~/.boto\n"
							+ "gsutil cp -r "+fileTransferDto.getSrcFilePath()+" "+fileTransferDto.getDestFilePath()+"";
					//Write Content into command.sh
					FileWriter shfilewriter = new FileWriter(shfile);
					shfilewriter.write(shfileContent);
					shfilewriter.close();
					LOGGER.info("Shell File is created!");
					//Creating Process object.
					Process process;				
				    String[] cmd = { "sh", Constants.SHFILEPATH};
				    process = Runtime.getRuntime().exec(cmd); 
				    int exitVal= process.waitFor();
				    //Get the response from shell file (command.sh) whether success of failure
				    if(0!=exitVal) {
					    LOGGER.info("value: "+exitVal);
					    LOGGER.info("process failed");
					    InputStream errorStream = process.getErrorStream();
					    int countofindex = 0;
					    String errormessage="";
					    while ((countofindex = errorStream.read()) != -1) {					    	
					    	errormessage+= Character.toString((char)countofindex);
					    }
					    LOGGER.info(errormessage);
				    } else {
					    result = Constants.RESULTSUCCESS;
					    LOGGER.info("process completed");
				    }
				} else {
					LOGGER.info("srcFilePath and destFilePath Null");
				}
			    } catch (IOException e) {			     
				    LOGGER.error("IOException():{}, Error Message: {}", e);
			    } catch (InterruptedException e) {
				    LOGGER.error("InterruptedException():{}, Error Message: {}", e);						  
			    }				
	 		      catch(Exception e) {
	 			    LOGGER.error("S3Config.secretDto():{}, Error MEssage: {}", e);
	 		    }
		  }
		  return result;
	}
	
}

