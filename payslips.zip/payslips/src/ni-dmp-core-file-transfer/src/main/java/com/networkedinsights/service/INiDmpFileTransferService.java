/**
 * 
 */
package com.networkedinsights.service;

import com.networkedinsights.dto.FileTransferDto;

/**
 * @author shivanid
 *
 */
public interface INiDmpFileTransferService {

	/**
	 * 
	 * @param srcFilePath
	 * @param destFilePath
	 * @return
	 */
	public String fileTransferGcsToS3(FileTransferDto dto);

}
